// Client-facing proposal view. Designed to feel polished — this is what the
// prospect sees when they click the link in their email.

"use client";

import { useState } from "react";
import type { ProposalJSON } from "@/lib/sales/proposal-schema";

type Competitor = {
  id: string;
  name: string;
  url: string | null;
  strengths: string[];
  weaknesses: string[];
  whyOutperforming: string | null;
  innovat3Angle: string | null;
};

export function ProposalView({
  proposal,
  mockupImageUrl,
  currentSiteUrl,
  currentSiteHref,
  competitors,
}: {
  proposal: ProposalJSON;
  mockupImageUrl: string | null;
  currentSiteUrl: string | null;
  currentSiteHref: string | null;
  competitors: Competitor[];
}) {
  const p = proposal;
  const [contactOpen, setContactOpen] = useState(false);

  return (
    <main style={{
      minHeight: "100vh",
      background: "linear-gradient(180deg, #0b0e14 0%, #0b0e14 360px, #f8fafc 360px, #f8fafc 100%)",
      fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      color: "#0f172a",
      paddingBottom: 80,
    }}>
      {/* HEADER (dark) */}
      <div style={{ maxWidth: 1080, margin: "0 auto", padding: "32px 24px 80px", color: "white" }}>
        <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: "0.18em", color: "#a78bfa", textTransform: "uppercase", marginBottom: 14 }}>
          A proposal from INNOVAT3 Solutions
        </div>
        <h1 style={{ fontSize: "clamp(28px, 4vw, 44px)", lineHeight: 1.15, fontWeight: 800, margin: "0 0 16px", maxWidth: 820 }}>
          {p.pitch.headline}
        </h1>
        <div style={{ fontSize: 15, color: "#cbd5e1", maxWidth: 720, lineHeight: 1.6 }}>
          Prepared for <strong style={{ color: "white" }}>{p.client.businessName}</strong>
          {p.client.location ? <> · {p.client.location}</> : null}
        </div>
      </div>

      {/* SIDE-BY-SIDE: current vs. mockup */}
      <div style={{ maxWidth: 1080, margin: "-56px auto 0", padding: "0 24px" }}>
        <div style={{ background: "white", borderRadius: 18, padding: 28, boxShadow: "0 30px 60px -28px rgba(15,23,42,0.45)" }}>
          <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: "0.14em", color: "#94a3b8", textTransform: "uppercase", marginBottom: 18 }}>
            Today → with INNOVAT3
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
            <FrameCard
              label={currentSiteHref ? "Your site today" : "No website today"}
              imageUrl={currentSiteUrl}
              href={currentSiteHref}
              empty={!currentSiteHref}
              variant="thumbnail"
            />
            <FrameCard
              label="Your new site"
              imageUrl={mockupImageUrl}
              href={null}
              highlight
              variant="scroll"
            />
          </div>
          <div style={{ marginTop: 14, fontSize: 12, color: "#64748b", textAlign: "center" }}>
            Scroll the new mockup to see the full design — it&apos;s built specifically for your business.
          </div>
        </div>
      </div>

      {/* SITUATION */}
      <Section title="The opportunity we see">
        <p style={{ fontSize: 17, lineHeight: 1.65, margin: 0, color: "#1e293b" }}>{p.situation.summary}</p>

        {p.situation.painPoints.length > 0 && (
          <div style={{ marginTop: 28 }}>
            <Subhead>Where you&apos;re losing today</Subhead>
            <BulletList items={p.situation.painPoints} color="#dc2626" />
          </div>
        )}

        {p.situation.opportunities.length > 0 && (
          <div style={{ marginTop: 24 }}>
            <Subhead>What&apos;s possible</Subhead>
            <BulletList items={p.situation.opportunities} color="#059669" />
          </div>
        )}
      </Section>

      {/* COMPETITORS */}
      {competitors.length > 0 && (
        <Section title="The competition — and where you can win">
          <div style={{ display: "grid", gap: 16 }}>
            {competitors.map((c) => (
              <div key={c.id} style={{ border: "1px solid #e2e8f0", borderRadius: 14, padding: 20, background: "white" }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 8, marginBottom: 10 }}>
                  <div style={{ fontWeight: 800, fontSize: 17 }}>{c.name}</div>
                  {c.url && (
                    <a href={c.url} target="_blank" rel="noopener noreferrer" style={{ fontSize: 12, color: "#6366f1", textDecoration: "none", fontWeight: 600 }}>
                      {prettyHost(c.url)} ↗
                    </a>
                  )}
                </div>
                {c.whyOutperforming && (
                  <p style={{ margin: "0 0 14px", fontSize: 14, lineHeight: 1.6, color: "#334155" }}>{c.whyOutperforming}</p>
                )}
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 14 }}>
                  {c.strengths.length > 0 && (
                    <div>
                      <div style={miniHeadStyle}>What they do well</div>
                      <ul style={miniListStyle}>
                        {c.strengths.map((s, i) => <li key={i} style={{ fontSize: 13, color: "#334155", marginBottom: 4 }}>{s}</li>)}
                      </ul>
                    </div>
                  )}
                  {c.weaknesses.length > 0 && (
                    <div>
                      <div style={miniHeadStyle}>Where they're weak</div>
                      <ul style={miniListStyle}>
                        {c.weaknesses.map((w, i) => <li key={i} style={{ fontSize: 13, color: "#334155", marginBottom: 4 }}>{w}</li>)}
                      </ul>
                    </div>
                  )}
                </div>
                {c.innovat3Angle && (
                  <div style={{ background: "#f5f3ff", border: "1px solid #ddd6fe", borderRadius: 10, padding: "10px 14px", fontSize: 13, color: "#4c1d95", lineHeight: 1.5 }}>
                    <strong>How we close the gap:</strong> {c.innovat3Angle}
                  </div>
                )}
              </div>
            ))}
          </div>
        </Section>
      )}

      {/* VALUE PILLARS */}
      <Section title="What you'll get">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 14 }}>
          {p.pitch.valuePillars.map((v, i) => (
            <div key={i} style={{ background: "white", border: "1px solid #e2e8f0", borderRadius: 12, padding: 18 }}>
              <div style={{ width: 28, height: 28, borderRadius: 8, background: "linear-gradient(135deg, #4318ff, #7c3aed)", color: "white", display: "grid", placeItems: "center", fontSize: 13, fontWeight: 800, marginBottom: 10 }}>
                {i + 1}
              </div>
              <div style={{ fontSize: 14, lineHeight: 1.55, color: "#1e293b" }}>{v}</div>
            </div>
          ))}
        </div>
      </Section>

      {/* BUNDLE — specific prices intentionally hidden in client-facing view.
          Rep discusses price on the call. We anchor with "starting at $800". */}
      <Section title="Recommended package">
        <div style={{ background: "linear-gradient(135deg, #f5f3ff, #ede9fe)", border: "1.5px solid #c4b5fd", borderRadius: 16, padding: 24 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 16, marginBottom: 14 }}>
            <div>
              <div style={{ fontSize: 11, fontWeight: 800, color: "#7c3aed", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 4 }}>
                Recommended for {p.client.businessName}
              </div>
              <div style={{ fontSize: 26, fontWeight: 800, color: "#0f172a" }}>{p.recommendedBundle.name}</div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontSize: 11, fontWeight: 800, color: "#7c3aed", textTransform: "uppercase", letterSpacing: "0.1em" }}>
                Starting at
              </div>
              <div style={{ fontSize: 24, fontWeight: 800, color: "#4318ff", lineHeight: 1.1 }}>$800</div>
              <div style={{ fontSize: 11, color: "#7c3aed", fontWeight: 600, marginTop: 2 }}>
                for a single landing page
              </div>
            </div>
          </div>
          <p style={{ fontSize: 14, lineHeight: 1.6, color: "#1e293b", margin: "0 0 14px" }}>{p.recommendedBundle.rationale}</p>
          <div style={{ fontSize: 12, color: "#5b21b6", fontStyle: "italic" }}>
            Final pricing depends on the scope we agree on — we&apos;ll walk you through it on the call.
          </div>
        </div>

        <div style={{ marginTop: 24 }}>
          <Subhead>What&apos;s included</Subhead>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 12 }}>
            {p.recommendedServices.map((s, i) => (
              <div key={i} style={{ background: "white", border: "1px solid #e2e8f0", borderRadius: 10, padding: 14 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                  <div style={{ fontWeight: 700, fontSize: 14 }}>{s.name}</div>
                  <span style={{ fontSize: 10, fontWeight: 800, padding: "2px 8px", borderRadius: 999, background: s.tier === "primary" ? "#fee2e2" : s.tier === "secondary" ? "#fef3c7" : "#f1f5f9", color: s.tier === "primary" ? "#991b1b" : s.tier === "secondary" ? "#92400e" : "#64748b", textTransform: "uppercase", letterSpacing: "0.04em" }}>
                    {s.tier.replace("_", " ")}
                  </span>
                </div>
                <div style={{ fontSize: 13, color: "#334155", lineHeight: 1.5 }}>{s.rationale}</div>
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* ROI */}
      <Section title="What this means for your business">
        <div style={{ background: "#f0fdf4", border: "1px solid #bbf7d0", borderRadius: 14, padding: 22, color: "#166534", fontSize: 15, lineHeight: 1.65 }}>
          {p.pitch.roiProjection}
        </div>
      </Section>

      {/* CTA */}
      <Section title="Next steps">
        <div style={{ background: "white", border: "1px solid #e2e8f0", borderRadius: 16, padding: 28, textAlign: "center" }}>
          <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 8 }}>Ready to move forward?</div>
          <p style={{ fontSize: 14, color: "#64748b", margin: "0 0 20px" }}>Book a 30-minute call to walk through the proposal and answer any questions.</p>
          <button
            onClick={() => setContactOpen(true)}
            style={{
              display: "inline-block", padding: "14px 28px", borderRadius: 12, border: "none",
              background: "linear-gradient(135deg, #4318ff, #7c3aed)", color: "white",
              fontSize: 15, fontWeight: 800, cursor: "pointer",
              boxShadow: "0 12px 28px -8px rgba(67,24,255,0.5)",
            }}
          >
            Book a call →
          </button>

          {p.pitch.nextSteps.length > 1 && (
            <ol style={{ margin: "32px auto 0", padding: 0, listStyle: "none", maxWidth: 480, textAlign: "left" }}>
              {p.pitch.nextSteps.map((step, i) => (
                <li key={i} style={{ display: "flex", gap: 14, padding: "12px 0", borderBottom: i < p.pitch.nextSteps.length - 1 ? "1px solid #f1f5f9" : "none" }}>
                  <span style={{ width: 24, height: 24, borderRadius: 999, background: "#4318ff", color: "white", display: "grid", placeItems: "center", fontSize: 12, fontWeight: 800, flexShrink: 0 }}>{i + 1}</span>
                  <span style={{ fontSize: 14, color: "#334155", lineHeight: 1.55 }}>{step}</span>
                </li>
              ))}
            </ol>
          )}
        </div>
      </Section>

      <div style={{ maxWidth: 1080, margin: "40px auto 0", padding: "24px", textAlign: "center", fontSize: 12, color: "#94a3b8" }}>
        Prepared by INNOVAT3 Solutions · This proposal was tailored specifically for {p.client.businessName}.
      </div>

      {contactOpen && (
        <div onClick={(e) => { if (e.target === e.currentTarget) setContactOpen(false); }}
          style={{ position: "fixed", inset: 0, background: "rgba(15,23,42,0.6)", display: "grid", placeItems: "center", padding: 20, zIndex: 1000 }}>
          <div style={{ background: "white", borderRadius: 16, padding: 28, maxWidth: 460, width: "100%" }}>
            <div style={{ fontSize: 20, fontWeight: 800, marginBottom: 8 }}>Let&apos;s talk</div>
            <p style={{ fontSize: 14, color: "#475569", lineHeight: 1.6, marginBottom: 16 }}>
              Reply to the email this proposal came in, or reach us directly:
            </p>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              <a href="mailto:hello@innovat3solutions.com" style={contactBtn}>hello@innovat3solutions.com</a>
            </div>
            <button onClick={() => setContactOpen(false)} style={{ marginTop: 18, background: "transparent", border: "none", color: "#64748b", cursor: "pointer", fontSize: 13 }}>
              Close
            </button>
          </div>
        </div>
      )}
    </main>
  );
}

function FrameCard({
  label, imageUrl, href, empty, highlight, variant = "thumbnail",
}: {
  label: string;
  imageUrl: string | null;
  href: string | null;
  empty?: boolean;
  highlight?: boolean;
  /** "thumbnail" = fitted 16:10 preview (current site). "scroll" = fixed-height
   * window with internal vertical scroll for tall full-page mockups. */
  variant?: "thumbnail" | "scroll";
}) {
  const isScroll = variant === "scroll";
  return (
    <div style={{
      background: highlight ? "linear-gradient(135deg, #faf5ff, #f5f3ff)" : "#f8fafc",
      border: `1px solid ${highlight ? "#c4b5fd" : "#e2e8f0"}`,
      borderRadius: 12, overflow: "hidden", position: "relative",
    }}>
      <div style={{ padding: "10px 14px", fontSize: 11, fontWeight: 800, color: highlight ? "#7c3aed" : "#64748b", letterSpacing: "0.08em", textTransform: "uppercase", borderBottom: `1px solid ${highlight ? "#ddd6fe" : "#e2e8f0"}`, display: "flex", alignItems: "center", gap: 6 }}>
        <span style={{ display: "inline-flex", gap: 4 }}>
          <span style={{ width: 8, height: 8, borderRadius: 999, background: "#ef4444" }} />
          <span style={{ width: 8, height: 8, borderRadius: 999, background: "#eab308" }} />
          <span style={{ width: 8, height: 8, borderRadius: 999, background: "#22c55e" }} />
        </span>
        <span style={{ marginLeft: 8 }}>{label}</span>
      </div>
      {isScroll ? (
        // Tall scrollable preview — fixed height, internal y-scroll, image
        // displays at full natural height so the prospect can drag through it.
        <div style={{ position: "relative", height: 520, background: "#0f172a", overflow: "hidden" }}>
          <div style={{ height: "100%", overflowY: "auto", overflowX: "hidden" }}>
            {empty ? (
              <div style={{ color: "#64748b", fontSize: 13, textAlign: "center", padding: 24 }}>
                You don&apos;t have a website yet — that&apos;s about to change.
              </div>
            ) : imageUrl ? (
              <img src={imageUrl} alt={label} style={{ width: "100%", height: "auto", display: "block" }} />
            ) : (
              <div style={{ color: "#64748b", fontSize: 13, padding: 24 }}>—</div>
            )}
          </div>
          {/* Scroll-affordance gradient at the bottom edge */}
          <div style={{
            position: "absolute", left: 0, right: 0, bottom: 0, height: 48,
            background: "linear-gradient(180deg, rgba(15,23,42,0), rgba(15,23,42,0.55))",
            pointerEvents: "none",
          }} />
          <div style={{
            position: "absolute", left: 0, right: 0, bottom: 8, textAlign: "center",
            fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.85)",
            letterSpacing: "0.08em", textTransform: "uppercase",
            textShadow: "0 1px 4px rgba(0,0,0,0.6)",
            pointerEvents: "none",
          }}>
            Scroll to explore ↓
          </div>
        </div>
      ) : (
        <div style={{ aspectRatio: "16/10", background: "#0f172a", display: "grid", placeItems: "center", overflow: "hidden" }}>
          {empty ? (
            <div style={{ color: "#64748b", fontSize: 13, textAlign: "center", padding: 24 }}>
              You don&apos;t have a website yet — that&apos;s about to change.
            </div>
          ) : imageUrl ? (
            href ? (
              <a href={href} target="_blank" rel="noopener noreferrer" style={{ display: "block", width: "100%", height: "100%" }}>
                <img src={imageUrl} alt={label} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
              </a>
            ) : (
              <img src={imageUrl} alt={label} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
            )
          ) : (
            <div style={{ color: "#64748b", fontSize: 13 }}>—</div>
          )}
        </div>
      )}
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section style={{ maxWidth: 1080, margin: "60px auto 0", padding: "0 24px" }}>
      <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: "0.16em", color: "#94a3b8", textTransform: "uppercase", marginBottom: 18 }}>
        {title}
      </div>
      {children}
    </section>
  );
}

function Subhead({ children }: { children: React.ReactNode }) {
  return (
    <div style={{ fontSize: 12, fontWeight: 800, color: "#475569", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 10 }}>
      {children}
    </div>
  );
}

function BulletList({ items, color }: { items: string[]; color: string }) {
  return (
    <ul style={{ margin: 0, padding: 0, listStyle: "none", display: "flex", flexDirection: "column", gap: 8 }}>
      {items.map((item, i) => (
        <li key={i} style={{ display: "flex", gap: 10, fontSize: 14, lineHeight: 1.55, color: "#334155" }}>
          <span style={{ width: 6, height: 6, borderRadius: "50%", background: color, marginTop: 8, flexShrink: 0 }} />
          <span>{item}</span>
        </li>
      ))}
    </ul>
  );
}
const miniHeadStyle: React.CSSProperties = { fontSize: 11, fontWeight: 800, color: "#64748b", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 6 };
const miniListStyle: React.CSSProperties = { margin: 0, padding: "0 0 0 16px" };
const contactBtn: React.CSSProperties = {
  display: "block", padding: "12px 16px", borderRadius: 10, background: "#f8fafc",
  border: "1px solid #e2e8f0", color: "#0f172a", textDecoration: "none", fontSize: 14, fontWeight: 600,
  textAlign: "center",
};

function prettyHost(url: string): string {
  try { return new URL(url).hostname.replace(/^www\./, ""); }
  catch { return url; }
}
