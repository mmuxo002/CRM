// Public proposal viewer.
//
// No auth — anyone with the token sees the proposal. Records a view on every
// load (with hashed IP for unique-view counting) and bumps Proposal.viewCount.

import { notFound } from "next/navigation";
import { headers } from "next/headers";
import { createHash } from "node:crypto";
import { db } from "@/lib/db";
import type { ProposalJSON } from "@/lib/sales/proposal-schema";
import { ProposalView } from "./ProposalView";

export const dynamic = "force-dynamic";

export default async function PublicProposalPage(
  { params }: { params: Promise<{ token: string }> },
) {
  const { token } = await params;

  const proposal = await db.proposal.findUnique({
    where: { token },
    include: { competitors: true, lead: true },
  });
  if (!proposal) notFound();

  // Don't show in-progress or failed proposals to clients.
  const viewableStatuses = new Set(["ready", "sent", "viewed", "scheduled"]);
  if (!viewableStatuses.has(proposal.status)) {
    return (
      <main style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: 24, fontFamily: "-apple-system, BlinkMacSystemFont, sans-serif", background: "#f8fafc" }}>
        <div style={{ maxWidth: 420, textAlign: "center", color: "#475569" }}>
          <div style={{ fontSize: 22, fontWeight: 800, color: "#0f172a", marginBottom: 8 }}>Almost ready</div>
          <p>This proposal is still being prepared. Please check back in a minute or two.</p>
        </div>
      </main>
    );
  }

  // Record the view (best-effort — never block render on this).
  void recordView(proposal.id, proposal.firstViewedAt);

  const copy = proposal.proposalJson
    ? (JSON.parse(proposal.proposalJson) as ProposalJSON)
    : null;

  if (!copy) notFound();

  return (
    <ProposalView
      proposal={copy}
      mockupImageUrl={proposal.mockupImageUrl}
      currentSiteUrl={proposal.currentSiteUrl}
      currentSiteHref={proposal.lead.website}
      competitors={proposal.competitors.map((c) => ({
        id: c.id,
        name: c.name,
        url: c.url,
        strengths: safeArr(c.strengths),
        weaknesses: safeArr(c.weaknesses),
        whyOutperforming: c.whyOutperforming,
        innovat3Angle: c.innovat3Angle,
      }))}
    />
  );
}

async function recordView(proposalId: string, firstViewedAt: Date | null): Promise<void> {
  try {
    const h = await headers();
    const fwd = h.get("x-forwarded-for") || "";
    const ip = fwd.split(",")[0]?.trim() || "unknown";
    const userAgent = h.get("user-agent") || null;
    const referrer = h.get("referer") || null;
    const ipHash = createHash("sha256").update(ip).digest("hex").slice(0, 16);

    await db.$transaction([
      db.proposalView.create({
        data: { proposalId, ipHash, userAgent, referrer },
      }),
      db.proposal.update({
        where: { id: proposalId },
        data: {
          viewCount: { increment: 1 },
          lastViewedAt: new Date(),
          firstViewedAt: firstViewedAt ?? new Date(),
          status: firstViewedAt ? undefined : "viewed",
        },
      }),
    ]);
  } catch (err) {
    console.error("[proposal-view] record failed", err);
  }
}

function safeArr(s: string | null): string[] {
  if (!s) return [];
  try { return JSON.parse(s) as string[]; } catch { return []; }
}
