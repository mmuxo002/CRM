import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";

export async function POST(req: Request) {
  await requireSession();
  const { companyId, name, email, phone, title, isPrimary } = await req.json();
  if (!name) return NextResponse.json({ error: "name required" }, { status: 400 });
  if (isPrimary && companyId) {
    await db.contact.updateMany({ where: { companyId }, data: { isPrimary: false } });
  }
  const contact = await db.contact.create({
    data: { name, email: email || null, phone: phone || null, title: title || null, isPrimary: !!isPrimary, companyId: companyId || null },
  });
  return NextResponse.json({ ok: true, contact });
}
