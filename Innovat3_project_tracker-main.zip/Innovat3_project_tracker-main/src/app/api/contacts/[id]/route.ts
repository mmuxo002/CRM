import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  await requireSession();
  const { id } = await params;
  const contact = await db.contact.findUnique({ where: { id } });
  if (!contact) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const body = await req.json();
  const data: Record<string, unknown> = {};
  if (typeof body.name === "string") data.name = body.name;
  if ("email" in body) data.email = body.email || null;
  if ("phone" in body) data.phone = body.phone || null;
  if ("title" in body) data.title = body.title || null;
  if (typeof body.isPrimary === "boolean") {
    if (body.isPrimary && contact.companyId) {
      await db.contact.updateMany({ where: { companyId: contact.companyId, NOT: { id } }, data: { isPrimary: false } });
    }
    data.isPrimary = body.isPrimary;
  }

  await db.contact.update({ where: { id }, data });
  return NextResponse.json({ ok: true });
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  await requireSession();
  const { id } = await params;
  await db.contact.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
