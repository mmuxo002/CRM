import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";

const VALID_STATUS = new Set(["BACKLOG", "RESEARCH", "IN_PROGRESS", "REVIEW", "DONE", "BLOCKED"]);
const VALID_PRIORITY = new Set(["LOW", "MEDIUM", "HIGH"]);

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { user } = await requireSession();
  const { id } = await params;
  const task = await db.task.findUnique({ where: { id } });
  if (!task) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (user.role !== "ADMIN") {
    const userTeam = user.role === "APPS_DEV" ? "APPS" : user.role === "CRM_DEV" ? "CRM" : "SALES";
    if (task.teamId !== userTeam) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const body = await req.json();
  const data: Record<string, unknown> = {};
  if (typeof body.title === "string") data.title = body.title;
  if ("description" in body) data.description = body.description || null;
  if (typeof body.status === "string" && VALID_STATUS.has(body.status)) data.status = body.status;
  if (typeof body.priority === "string" && VALID_PRIORITY.has(body.priority)) data.priority = body.priority;
  if ("assignedTo" in body) data.assignedTo = body.assignedTo || null;
  if ("dueDate" in body) data.dueDate = body.dueDate ? new Date(body.dueDate) : null;
  if ("platformTag" in body) data.platformTag = body.platformTag || null;
  if (typeof body.progress === "number") data.progress = body.progress;

  const prev = task.status;
  await db.task.update({ where: { id }, data });
  if (data.status && data.status !== prev) {
    await db.activity.create({
      data: {
        kind: "TASK",
        title: `${task.title} · ${prev} → ${data.status}`,
        teamId: task.teamId,
        actorId: user.id,
        projectId: task.projectId,
      },
    });
  }
  return NextResponse.json({ ok: true });
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { user } = await requireSession();
  const { id } = await params;
  const task = await db.task.findUnique({ where: { id } });
  if (!task) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (user.role !== "ADMIN") {
    const userTeam = user.role === "APPS_DEV" ? "APPS" : user.role === "CRM_DEV" ? "CRM" : "SALES";
    if (task.teamId !== userTeam) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }
  await db.task.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
