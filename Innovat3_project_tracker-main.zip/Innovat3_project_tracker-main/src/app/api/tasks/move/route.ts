import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";

const VALID = new Set(["BACKLOG", "RESEARCH", "IN_PROGRESS", "REVIEW", "DONE", "BLOCKED"]);

export async function POST(req: Request) {
  const { user } = await requireSession();
  const { id, toColumn } = await req.json();
  if (!id || !VALID.has(toColumn)) return NextResponse.json({ error: "Invalid" }, { status: 400 });

  const task = await db.task.findUnique({ where: { id }, include: { project: true } });
  if (!task) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (user.role !== "ADMIN") {
    const userTeam = user.role === "APPS_DEV" ? "APPS" : user.role === "CRM_DEV" ? "CRM" : "SALES";
    if (task.teamId !== userTeam) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }
  const prev = task.status;
  await db.task.update({ where: { id }, data: { status: toColumn } });
  if (prev !== toColumn) {
    await db.activity.create({
      data: {
        kind: "TASK",
        title: `${task.title} · ${prev.replace("_", " ")} → ${toColumn.replace("_", " ")}`,
        body: task.project ? `Project: ${task.project.name}` : undefined,
        teamId: task.teamId,
        actorId: user.id,
        projectId: task.projectId,
      },
    });
  }
  return NextResponse.json({ ok: true });
}
