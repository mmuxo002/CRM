import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";

export async function POST(req: Request) {
  const { user } = await requireSession();
  const body = await req.json();
  const { projectId, title, description, assignedTo, dueDate, priority, status, platformTag } = body;
  if (!projectId || !title) return NextResponse.json({ error: "projectId and title required" }, { status: 400 });

  const project = await db.project.findUnique({ where: { id: projectId } });
  if (!project) return NextResponse.json({ error: "Invalid project" }, { status: 400 });

  const task = await db.task.create({
    data: {
      title,
      description: description || null,
      projectId,
      teamId: project.teamId === "GLOBAL" ? "APPS" : project.teamId,
      assignedTo: assignedTo || null,
      dueDate: dueDate ? new Date(dueDate) : null,
      priority: priority || "MEDIUM",
      platformTag: platformTag || null,
      status: status || "BACKLOG",
    },
  });
  return NextResponse.json({ ok: true, id: task.id });
}
