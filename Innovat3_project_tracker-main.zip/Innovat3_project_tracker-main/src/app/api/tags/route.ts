import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";

export async function POST(req: Request) {
  await requireSession();
  const { projectId, label, color } = await req.json();
  if (!projectId || !label) return NextResponse.json({ error: "projectId and label required" }, { status: 400 });
  const tag = await db.tag.create({ data: { projectId, label, color: color || "#4318ff" } });
  return NextResponse.json({ ok: true, tag });
}

export async function DELETE(req: Request) {
  await requireSession();
  const { id } = await req.json();
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  await db.tag.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
