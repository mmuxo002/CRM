// Cooldown release — runs hourly via Vercel Cron (see vercel.json).
// Any LeadClaim with no agent activity for COOLDOWN_DAYS (15) flips back to the open
// pool. Research (persona, outreaches, brief, notes) stays attached to the Lead.
// History is preserved: the LeadClaim row stays, just with releasedAt + releaseReason set.
//
// Security: Vercel Cron sends `Authorization: Bearer <CRON_SECRET>`. Setting CRON_SECRET
// in env gates the route; without it, only local invocations should reach here.

import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { COOLDOWN_DAYS, releaseClaim } from "@/lib/sales/claim-pool";

export const dynamic = "force-dynamic";

function authorized(req: Request): boolean {
  const secret = process.env.CRON_SECRET;
  if (!secret) return process.env.NODE_ENV !== "production";
  const header = req.headers.get("authorization") ?? "";
  return header === `Bearer ${secret}`;
}

async function run() {
  const cutoff = new Date(Date.now() - COOLDOWN_DAYS * 24 * 60 * 60 * 1000);
  const stale = await db.leadClaim.findMany({
    where: { releasedAt: null, lastActivityAt: { lt: cutoff } },
    select: { id: true, leadId: true },
  });

  for (const claim of stale) {
    await releaseClaim({ claimId: claim.id, reason: "COOLDOWN_EXPIRED" });
  }

  return { released: stale.length, cutoff: cutoff.toISOString() };
}

export async function GET(req: Request) {
  if (!authorized(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  return NextResponse.json({ ok: true, ...(await run()) });
}

export async function POST(req: Request) {
  if (!authorized(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  return NextResponse.json({ ok: true, ...(await run()) });
}
