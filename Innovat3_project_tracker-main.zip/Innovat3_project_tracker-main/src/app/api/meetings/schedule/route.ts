import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";

export const dynamic = "force-dynamic";

const VALID_RECURRENCE = new Set(["NONE", "DAILY", "WEEKLY", "BIWEEKLY", "MONTHLY"]);
const VALID_KIND = new Set(["INTERNAL_CALL", "CLIENT_STANDUP"]);

export async function POST(req: Request) {
  const { user } = await requireSession();
  const {
    title,
    startIso,
    durationMinutes,
    attendeeIds,
    notes,
    teamId,
    kind,
    projectId,
    taskIds,
    includeClient,
    recurrence,
    recurrenceUntilIso,
  } = await req.json();

  if (!title || !startIso) {
    return NextResponse.json({ error: "title and startIso required" }, { status: 400 });
  }
  const meetingKind = VALID_KIND.has(kind) ? kind : "INTERNAL_CALL";
  const recur = VALID_RECURRENCE.has(recurrence) ? recurrence : "NONE";

  const project = projectId
    ? await db.project.findUnique({ where: { id: projectId }, include: { company: { include: { contacts: true } } } })
    : null;
  if (projectId && !project) return NextResponse.json({ error: "Project not found" }, { status: 404 });

  const attendees = Array.isArray(attendeeIds) && attendeeIds.length
    ? await db.user.findMany({ where: { id: { in: attendeeIds } }, select: { id: true, name: true, email: true } })
    : [];

  const tasks = Array.isArray(taskIds) && taskIds.length && projectId
    ? await db.task.findMany({ where: { id: { in: taskIds }, projectId }, select: { title: true } })
    : [];

  const meeting = await db.meeting.create({
    data: {
      title,
      kind: meetingKind,
      startAt: new Date(startIso),
      durationMinutes: durationMinutes || 30,
      notes: notes || null,
      teamId: teamId || "APPS",
      recurrence: recur,
      recurrenceUntil: recur !== "NONE" && recurrenceUntilIso ? new Date(recurrenceUntilIso) : null,
      includeClient: meetingKind === "CLIENT_STANDUP" && Boolean(includeClient),
      ownerId: user.id,
      projectId: project?.id ?? null,
      attendees: attendees.length ? { connect: attendees.map((a) => ({ id: a.id })) } : undefined,
    },
    include: { attendees: { select: { id: true, name: true, email: true, image: true } }, owner: true, project: { include: { company: true } } },
  });

  if (project) {
    const attendeeSummary = attendees.map((a) => a.name || a.email).filter(Boolean).join(", ");
    const client = project.company?.contacts?.find((c) => c.isPrimary) || project.company?.contacts?.[0] || null;
    const taskBullet = tasks.length ? tasks.map((t) => `• ${t.title}`).join("\n") : null;
    const recurLabel = recur === "NONE" ? null : recur === "BIWEEKLY" ? "every 2 weeks" : recur.toLowerCase();

    await db.activity.create({
      data: {
        kind: "MEETING",
        title: `${meetingKind === "CLIENT_STANDUP" ? "Client stand-up" : "Internal call"} scheduled: ${title}`,
        body: [
          `Project: ${project.company?.name ? `${project.company.name} · ` : ""}${project.name}`,
          `When: ${new Date(startIso).toLocaleString()} (${durationMinutes || 30} min)${recurLabel ? ` · repeats ${recurLabel}` : ""}`,
          attendeeSummary ? `Developers: ${attendeeSummary}` : null,
          meetingKind === "CLIENT_STANDUP" && includeClient && client ? `Client: ${client.name}${client.email ? ` <${client.email}>` : ""}` : null,
          meetingKind === "INTERNAL_CALL" ? `Client: not invited (internal only)` : null,
          taskBullet ? `Tasks to discuss:\n${taskBullet}` : null,
          notes ? `Notes: ${notes}` : null,
        ].filter(Boolean).join("\n"),
        teamId: teamId || "APPS",
        actorId: user.id,
        projectId: project.id,
      },
    });
  }

  return NextResponse.json({ meeting });
}
