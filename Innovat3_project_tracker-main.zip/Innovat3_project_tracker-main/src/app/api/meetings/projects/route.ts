import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  await requireSession();
  const url = new URL(req.url);
  const team = url.searchParams.get("team") || "APPS";
  const id = url.searchParams.get("id");

  if (id) {
    const project = await db.project.findUnique({
      where: { id },
      include: {
        company: { include: { contacts: true } },
        owner: { select: { id: true, name: true, email: true, image: true } },
        tasks: {
          where: { status: { not: "DONE" } },
          orderBy: { createdAt: "desc" },
          select: { id: true, title: true, status: true, priority: true, dueDate: true },
        },
      },
    });
    if (!project) return NextResponse.json({ error: "Not found" }, { status: 404 });
    const primary = project.company?.contacts?.find((c) => c.isPrimary) || project.company?.contacts?.[0] || null;
    return NextResponse.json({
      id: project.id,
      name: project.name,
      companyName: project.company?.name || null,
      client: primary ? { id: primary.id, name: primary.name, email: primary.email, phone: primary.phone } : null,
      owner: project.owner,
      tasks: project.tasks.map((t) => ({ ...t, dueDate: t.dueDate?.toISOString() ?? null })),
    });
  }

  const projects = await db.project.findMany({
    where: { teamId: team },
    include: { company: { select: { name: true } } },
    orderBy: { updatedAt: "desc" },
    take: 100,
  });
  return NextResponse.json(projects.map((p) => ({ id: p.id, name: p.name, companyName: p.company?.name || null })));
}
