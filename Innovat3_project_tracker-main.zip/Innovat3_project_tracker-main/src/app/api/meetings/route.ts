import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";
import { expandRecurrence } from "@/lib/meetings";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  await requireSession();
  const url = new URL(req.url);
  const fromIso = url.searchParams.get("from");
  const toIso = url.searchParams.get("to");
  const team = url.searchParams.get("team");
  const projectId = url.searchParams.get("projectId");

  const windowStart = fromIso ? new Date(fromIso) : new Date(Date.now() - 7 * 86400000);
  const windowEnd = toIso ? new Date(toIso) : new Date(Date.now() + 60 * 86400000);

  const meetings = await db.meeting.findMany({
    where: {
      ...(team ? { teamId: team } : {}),
      ...(projectId ? { projectId } : {}),
      // Either non-recurring inside window, or recurring whose first instance is before window end
      OR: [
        { recurrence: "NONE", startAt: { gte: windowStart, lte: windowEnd } },
        { recurrence: { not: "NONE" }, startAt: { lte: windowEnd } },
      ],
    },
    include: {
      owner: { select: { id: true, name: true, email: true, image: true } },
      attendees: { select: { id: true, name: true, email: true, image: true } },
      project: { select: { id: true, name: true, company: { select: { name: true } } } },
    },
    orderBy: { startAt: "asc" },
  });

  const expanded = meetings.flatMap((m) => {
    const slots = expandRecurrence(
      { id: m.id, startAt: m.startAt, recurrence: m.recurrence, recurrenceUntil: m.recurrenceUntil },
      windowStart,
      windowEnd,
    );
    return slots.map((s) => ({
      id: m.id,
      occurrenceId: `${m.id}@${s.occurrenceStart.toISOString()}`,
      title: m.title,
      kind: m.kind,
      teamId: m.teamId,
      durationMinutes: m.durationMinutes,
      notes: m.notes,
      startAt: s.occurrenceStart.toISOString(),
      isRecurring: s.isRecurring,
      recurrence: m.recurrence,
      recurrenceUntil: m.recurrenceUntil?.toISOString() ?? null,
      includeClient: m.includeClient,
      owner: m.owner,
      attendees: m.attendees,
      project: m.project ? { id: m.project.id, name: m.project.name, companyName: m.project.company?.name ?? null } : null,
    }));
  });

  expanded.sort((a, b) => a.startAt.localeCompare(b.startAt));
  return NextResponse.json(expanded);
}
