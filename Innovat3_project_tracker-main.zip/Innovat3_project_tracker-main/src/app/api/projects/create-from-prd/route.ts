import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const { user } = await requireSession();
  const { name, prd, projectManagerId, teamId } = await req.json();

  if (!name || typeof name !== "string") {
    return NextResponse.json({ error: "name required" }, { status: 400 });
  }
  if (!prd || typeof prd !== "string") {
    return NextResponse.json({ error: "prd required" }, { status: 400 });
  }

  const project = await db.project.create({
    data: {
      name,
      prd,
      teamId: teamId || "APPS",
      stage: "APPS_DEV",
      ownerId: user.id,
      projectManagerId: projectManagerId || null,
    },
  });

  const file = await db.fileAsset.create({
    data: {
      name: `${name} — PRD.md`,
      format: "MD",
      url: `/api/prd/${project.id}`,
      sizeBytes: Buffer.byteLength(prd, "utf8"),
      isLink: false,
      projectId: project.id,
      uploadedBy: user.id,
    },
  });

  await db.activity.create({
    data: {
      kind: "SYSTEM",
      title: `Project "${name}" created from PRD`,
      body: projectManagerId ? `Assigned to project manager.` : undefined,
      teamId: teamId || "APPS",
      actorId: user.id,
      projectId: project.id,
    },
  });

  return NextResponse.json({ project, file });
}
