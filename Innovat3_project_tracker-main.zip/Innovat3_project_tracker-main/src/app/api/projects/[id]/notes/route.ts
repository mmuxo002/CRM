import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  await requireSession();
  const { id } = await params;

  const [projectComments, taskComments] = await Promise.all([
    db.comment.findMany({
      where: { projectId: id, taskId: null },
      include: { author: { select: { id: true, name: true, image: true } } },
      orderBy: { createdAt: "asc" },
    }),
    db.comment.findMany({
      where: { task: { projectId: id }, taskId: { not: null } },
      include: {
        author: { select: { id: true, name: true, image: true } },
        task: { select: { id: true, title: true } },
      },
      orderBy: { createdAt: "asc" },
    }),
  ]);

  const notes = [
    ...projectComments.map((c) => ({
      id: c.id,
      body: c.body,
      createdAt: c.createdAt.toISOString(),
      author: c.author,
      kind: "project" as const,
      task: null,
    })),
    ...taskComments.map((c) => ({
      id: c.id,
      body: c.body,
      createdAt: c.createdAt.toISOString(),
      author: c.author,
      kind: "task" as const,
      task: c.task ? { id: c.task.id, title: c.task.title } : null,
    })),
  ].sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

  return NextResponse.json({ notes });
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { user } = await requireSession();
  const { id } = await params;
  const { body } = await req.json();
  if (!body?.trim()) return NextResponse.json({ error: "body required" }, { status: 400 });

  const comment = await db.comment.create({
    data: { body: body.trim(), authorId: user.id, projectId: id },
    include: { author: { select: { id: true, name: true, image: true } } },
  });

  await db.activity.create({
    data: { kind: "NOTE", title: "Added a project note", body: body.trim().slice(0, 100), teamId: "GLOBAL", actorId: user.id, projectId: id },
  });

  return NextResponse.json({
    ok: true,
    note: { id: comment.id, body: comment.body, createdAt: comment.createdAt.toISOString(), author: comment.author, kind: "project", task: null },
  });
}
