import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { user } = await requireSession();
  const { id } = await params;

  const project = await db.project.findUnique({ where: { id } });
  if (!project) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (user.role !== "ADMIN") {
    const userTeam = user.role === "APPS_DEV" ? "APPS" : user.role === "CRM_DEV" ? "CRM" : "SALES";
    if (project.teamId !== userTeam && project.teamId !== "GLOBAL") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }
  }

  const body = await req.json();
  const data: Record<string, unknown> = {};

  if (typeof body.name === "string") data.name = body.name;
  if (typeof body.description === "string") data.description = body.description;
  if (typeof body.serviceType === "string" || body.serviceType === null) data.serviceType = body.serviceType;
  if (typeof body.mrr === "number") data.mrr = body.mrr;
  if (typeof body.progress === "number") data.progress = body.progress;
  if (typeof body.priority === "string") data.priority = body.priority;
  if (typeof body.stage === "string") data.stage = body.stage;
  if ("dueDate" in body) data.dueDate = body.dueDate ? new Date(body.dueDate) : null;
  if ("onboardedAt" in body) {
    const d = body.onboardedAt ? new Date(body.onboardedAt) : null;
    data.onboardedAt = d;
    data.onboarded = !!d;
  }
  if ("companyId" in body) data.companyId = body.companyId || null;

  await db.project.update({ where: { id }, data });
  return NextResponse.json({ ok: true });
}
