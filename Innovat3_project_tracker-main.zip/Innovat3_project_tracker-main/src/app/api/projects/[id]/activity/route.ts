import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  await requireSession();
  const { id } = await params;
  const activities = await db.activity.findMany({
    where: { projectId: id },
    include: { actor: { select: { id: true, name: true, image: true } } },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json({
    activities: activities.map((a) => ({
      id: a.id,
      kind: a.kind,
      title: a.title,
      body: a.body,
      createdAt: a.createdAt.toISOString(),
      actor: a.actor,
    })),
  });
}
