import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";

const VALID_STAGES = new Set(["SALES", "APPS_DEV", "CRM_DEV", "QA", "LIVE"]);

export async function POST(req: Request) {
  const { user } = await requireSession();
  if (user.role !== "ADMIN") return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { id, toColumn } = await req.json();
  if (!id || !VALID_STAGES.has(toColumn)) return NextResponse.json({ error: "Invalid payload" }, { status: 400 });

  const teamMap: Record<string, string> = { SALES: "SALES", APPS_DEV: "APPS", CRM_DEV: "CRM", QA: "GLOBAL", LIVE: "GLOBAL" };
  const updated = await db.project.update({ where: { id }, data: { stage: toColumn, teamId: teamMap[toColumn] } });
  await db.activity.create({ data: { kind: "SYSTEM", title: `Project moved to ${toColumn}`, body: updated.name, teamId: updated.teamId, actorId: user.id, projectId: updated.id } });
  return NextResponse.json({ ok: true });
}
