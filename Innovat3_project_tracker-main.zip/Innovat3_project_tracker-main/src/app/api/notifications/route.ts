import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";
import { parseAccess } from "@/lib/departments";
import type { Prisma } from "@prisma/client";

export const dynamic = "force-dynamic";

const DEPT_TO_TEAMS: Record<string, string[]> = {
  development: ["APPS"],
  crm: ["CRM"],
  sales: ["SALES"],
  marketing: ["GLOBAL"],
};

export async function GET() {
  const { user } = await requireSession();
  const isAdmin = user.role === "ADMIN";

  let where: Prisma.ActivityWhereInput;

  if (isAdmin) {
    where = {};
  } else {
    const access = parseAccess(user.accessDepartments);
    const allowedTeams = access === "all"
      ? ["APPS", "CRM", "SALES", "GLOBAL"]
      : Array.from(access).flatMap((id) => DEPT_TO_TEAMS[id] ?? []);

    const [ownedProjects, managedProjects, assignedLeads, assignedTasks] = await Promise.all([
      db.project.findMany({ where: { ownerId: user.id }, select: { id: true } }),
      db.project.findMany({ where: { projectManagerId: user.id }, select: { id: true } }),
      db.lead.findMany({ where: { assignedTo: user.id }, select: { id: true } }),
      db.task.findMany({ where: { assignedTo: user.id }, select: { projectId: true } }),
    ]);

    const projectIds = Array.from(new Set([
      ...ownedProjects.map((p) => p.id),
      ...managedProjects.map((p) => p.id),
      ...assignedTasks.map((t) => t.projectId),
    ]));
    const leadIds = assignedLeads.map((l) => l.id);

    const orClauses: Prisma.ActivityWhereInput[] = [{ actorId: user.id }];
    if (allowedTeams.length > 0) orClauses.push({ teamId: { in: allowedTeams } });
    if (projectIds.length > 0) orClauses.push({ projectId: { in: projectIds } });
    if (leadIds.length > 0) orClauses.push({ leadId: { in: leadIds } });

    where = { OR: orClauses };
  }

  const activities = await db.activity.findMany({
    where,
    include: {
      actor: { select: { id: true, name: true, image: true } },
      project: { select: { id: true, name: true, teamId: true, company: { select: { name: true } } } },
      lead: { select: { id: true, name: true } },
    },
    orderBy: { createdAt: "desc" },
    take: 30,
  });

  return NextResponse.json(
    activities.map((a) => ({
      id: a.id,
      kind: a.kind,
      title: a.title,
      body: a.body,
      teamId: a.teamId,
      createdAt: a.createdAt,
      actor: a.actor ? { id: a.actor.id, name: a.actor.name, image: a.actor.image } : null,
      project: a.project ? { id: a.project.id, name: a.project.name, teamId: a.project.teamId, companyName: a.project.company?.name ?? null } : null,
      lead: a.lead ? { id: a.lead.id, name: a.lead.name } : null,
    }))
  );
}
