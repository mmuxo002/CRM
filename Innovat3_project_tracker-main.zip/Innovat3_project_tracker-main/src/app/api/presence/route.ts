import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";

export const dynamic = "force-dynamic";

const ACTIVE_MIN = 5;
const AWAY_MIN = 60;

function statusFor(lastSeenAt: Date | null): "active" | "away" | "offline" {
  if (!lastSeenAt) return "offline";
  const diffMin = (Date.now() - lastSeenAt.getTime()) / 60000;
  if (diffMin <= ACTIVE_MIN) return "active";
  if (diffMin <= AWAY_MIN) return "away";
  return "offline";
}

export async function POST() {
  const { user } = await requireSession();
  await db.user.update({ where: { id: user.id }, data: { lastSeenAt: new Date() } });
  return NextResponse.json({ ok: true });
}

export async function GET(request: Request) {
  await requireSession();
  const { searchParams } = new URL(request.url);
  const department = searchParams.get("department"); // e.g. "development", "crm", "sales", "marketing"

  const users = await db.user.findMany({
    where: { isActive: true },
    select: { id: true, name: true, email: true, image: true, role: true, lastSeenAt: true, accessDepartments: true },
    orderBy: [{ lastSeenAt: "desc" }, { name: "asc" }],
  });

  const filtered = department
    ? users.filter((u) => {
        const ad = u.accessDepartments?.trim();
        if (!ad || ad === "all") return true;
        return ad.split(",").map((s) => s.trim()).includes(department);
      })
    : users;

  return NextResponse.json(
    filtered.map((u) => ({
      id: u.id,
      name: u.name,
      email: u.email,
      image: u.image,
      role: u.role,
      status: statusFor(u.lastSeenAt),
    }))
  );
}
