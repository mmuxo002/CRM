import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/rbac";

export async function GET() {
  await requireAdmin();
  const invoices = await db.invoice.findMany({
    include: { project: { select: { id: true, name: true } }, company: { select: { id: true, name: true } } },
    orderBy: { dueDate: "asc" },
  });
  return NextResponse.json({ invoices });
}

export async function POST(req: Request) {
  await requireAdmin();
  const body = await req.json();
  const { description, amount, dueDate, projectId, companyId, status } = body;
  if (!amount || !dueDate) return NextResponse.json({ error: "amount and dueDate required" }, { status: 400 });

  const count = await db.invoice.count();
  const number = `INV-${String(count + 1).padStart(4, "0")}`;

  const invoice = await db.invoice.create({
    data: {
      number,
      description: description || null,
      amount: Number(amount),
      status: status || "DRAFT",
      dueDate: new Date(dueDate),
      projectId: projectId || null,
      companyId: companyId || null,
    },
    include: { project: { select: { id: true, name: true } }, company: { select: { id: true, name: true } } },
  });
  return NextResponse.json({ ok: true, invoice });
}
