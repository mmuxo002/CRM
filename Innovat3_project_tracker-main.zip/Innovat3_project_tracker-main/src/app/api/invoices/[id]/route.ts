import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/rbac";

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  await requireAdmin();
  const { id } = await params;
  const body = await req.json();
  const data: Record<string, unknown> = {};

  if (typeof body.description === "string" || body.description === null) data.description = body.description;
  if (typeof body.amount === "number") data.amount = body.amount;
  if (typeof body.status === "string") {
    data.status = body.status;
    if (body.status === "PAID" && !body.paidAt) data.paidAt = new Date();
  }
  if ("dueDate" in body) data.dueDate = body.dueDate ? new Date(body.dueDate) : undefined;
  if ("paidAt" in body) data.paidAt = body.paidAt ? new Date(body.paidAt) : null;
  if ("projectId" in body) data.projectId = body.projectId || null;
  if ("companyId" in body) data.companyId = body.companyId || null;

  await db.invoice.update({ where: { id }, data });
  return NextResponse.json({ ok: true });
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  await requireAdmin();
  const { id } = await params;
  await db.invoice.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
