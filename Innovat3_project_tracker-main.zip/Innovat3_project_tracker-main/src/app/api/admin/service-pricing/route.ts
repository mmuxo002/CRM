import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/rbac";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

const SERVICE_TYPES = new Set([
  "WEBSITE_BUILD", "FORM_INTEGRATION", "CRM_INTEGRATION", "AUTOMATION",
  "VOICE_AI", "LEAD_NURTURING", "EMAIL_MARKETING", "OTHER",
]);

// GET — returns currently-active pricing row per serviceType.
export async function GET() {
  await requireAdmin();
  const rows = await db.servicePricing.findMany({
    where: { effectiveTo: null },
    orderBy: { serviceType: "asc" },
    include: { updatedBy: { select: { id: true, name: true, email: true } } },
  });
  return NextResponse.json({ ok: true, rows });
}

// POST / PATCH — both upsert: version the existing row for this serviceType and create a new one.
// Body: { serviceType, label, onboardingFee, monthlyFee, cost }
async function upsertPricing(req: Request) {
  const { user } = await requireAdmin();
  const body = await req.json().catch(() => ({}));
  const serviceType = typeof body.serviceType === "string" ? body.serviceType.trim().toUpperCase() : "";
  if (!SERVICE_TYPES.has(serviceType)) {
    return NextResponse.json({ error: `serviceType must be one of: ${Array.from(SERVICE_TYPES).join(", ")}` }, { status: 400 });
  }
  const label = typeof body.label === "string" && body.label.trim() ? body.label.trim() : serviceType;
  const onboardingFee = Number(body.onboardingFee);
  const monthlyFee = Number(body.monthlyFee);
  const cost = Number(body.cost);
  for (const [k, v] of Object.entries({ onboardingFee, monthlyFee, cost })) {
    if (!Number.isFinite(v) || v < 0) return NextResponse.json({ error: `${k} must be a non-negative number` }, { status: 400 });
  }

  const now = new Date();
  const active = await db.servicePricing.findFirst({ where: { serviceType, effectiveTo: null } });
  const created = await db.$transaction(async (tx) => {
    if (active) {
      await tx.servicePricing.update({ where: { id: active.id }, data: { effectiveTo: now } });
    }
    return tx.servicePricing.create({
      data: { serviceType, label, onboardingFee, monthlyFee, cost, effectiveFrom: now, updatedById: user.id },
    });
  });
  return NextResponse.json({ ok: true, pricing: created });
}

export const POST = upsertPricing;
export const PATCH = upsertPricing;
