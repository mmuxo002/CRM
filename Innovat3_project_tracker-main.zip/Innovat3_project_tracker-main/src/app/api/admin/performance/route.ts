import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/rbac";
import { db } from "@/lib/db";
import { parseAccess } from "@/lib/departments";
import { commissionTotalsForUsers, defaultPeriod, thisMonthCST, thisWeekCST, timesheetForUsers } from "@/lib/sales/timesheet";

export const dynamic = "force-dynamic";

// Sales reps = active users whose access includes the sales department
// (role=SALES or any role with "sales" in accessDepartments). "all" counts.
function isSalesRep(u: { role: string; accessDepartments: string; isActive: boolean }): boolean {
  if (!u.isActive) return false;
  if (u.role === "SALES") return true;
  const access = parseAccess(u.accessDepartments);
  if (access === "all") return u.role !== "ADMIN"; // don't list admins with blanket access
  return access.has("sales");
}

export async function GET(request: Request) {
  await requireAdmin();
  const { searchParams } = new URL(request.url);
  const period = defaultPeriod(searchParams);

  const users = await db.user.findMany({
    where: { isActive: true },
    select: { id: true, name: true, email: true, image: true, role: true, accessDepartments: true, isActive: true, lastSeenAt: true },
    orderBy: [{ name: "asc" }],
  });
  const reps = users.filter(isSalesRep);
  const repIds = reps.map((u) => u.id);

  const [hours, commissions] = await Promise.all([
    timesheetForUsers(repIds, period),
    commissionTotalsForUsers(repIds, period),
  ]);

  const rows = reps.map((u) => {
    const h = hours.get(u.id)!;
    const c = commissions.get(u.id)!;
    return {
      id: u.id,
      name: u.name,
      email: u.email,
      image: u.image,
      role: u.role,
      lastSeenAt: u.lastSeenAt,
      hours: h,
      commissions: c,
    };
  });

  const totals = rows.reduce(
    (acc, r) => {
      acc.workMs += r.hours.workMs;
      acc.breakMs += r.hours.breakMs;
      acc.sessionCount += r.hours.sessionCount;
      acc.commissionTotal += r.commissions.commissionTotal;
      acc.paidTotal += r.commissions.paidTotal;
      acc.pendingTotal += r.commissions.pendingTotal;
      acc.onboardingTotal += r.commissions.onboardingTotal;
      acc.commissionCount += r.commissions.count;
      return acc;
    },
    { workMs: 0, breakMs: 0, sessionCount: 0, commissionTotal: 0, paidTotal: 0, pendingTotal: 0, onboardingTotal: 0, commissionCount: 0 },
  );

  return NextResponse.json({
    ok: true,
    period,
    thisWeek: thisWeekCST(),
    thisMonth: thisMonthCST(),
    rows,
    totals,
  });
}
