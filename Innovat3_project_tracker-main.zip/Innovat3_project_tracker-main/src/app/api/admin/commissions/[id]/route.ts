import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/rbac";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

const STATUSES = new Set(["PENDING", "PAID", "VOID"]);

// PATCH /api/admin/commissions/[id]
// Body: { status?: "PENDING" | "PAID" | "VOID", notes?: string }
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  await requireAdmin();
  const { id } = await params;
  const body = await req.json().catch(() => ({}));
  const data: Record<string, unknown> = {};

  if (typeof body.status === "string") {
    if (!STATUSES.has(body.status)) return NextResponse.json({ error: "Invalid status" }, { status: 400 });
    data.status = body.status;
    data.paidAt = body.status === "PAID" ? new Date() : null;
  }
  if (typeof body.notes === "string") data.notes = body.notes.trim() || null;

  if (Object.keys(data).length === 0) return NextResponse.json({ error: "No fields to update" }, { status: 400 });

  const updated = await db.commission.update({ where: { id }, data });
  return NextResponse.json({ ok: true, commission: updated });
}
