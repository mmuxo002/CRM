import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/rbac";
import { db } from "@/lib/db";
import type { Prisma } from "@prisma/client";
import { cstMonthKey, cstWeekKey } from "@/lib/sales/cst";

export const dynamic = "force-dynamic";

const STATUSES = new Set(["PENDING", "PAID", "VOID"]);

// GET /api/admin/commissions?userId=&status=&weekOf=&monthOf=
export async function GET(request: Request) {
  await requireAdmin();
  const { searchParams } = new URL(request.url);
  const userId = searchParams.get("userId") || undefined;
  const status = searchParams.get("status") || undefined;
  const weekOf = searchParams.get("weekOf") || undefined;
  const monthOf = searchParams.get("monthOf") || undefined;

  const where: Prisma.CommissionWhereInput = {};
  if (userId) where.userId = userId;
  if (status && STATUSES.has(status)) where.status = status;
  if (weekOf) where.weekOfCST = weekOf;
  else if (monthOf) where.monthOfCST = monthOf;

  const commissions = await db.commission.findMany({
    where,
    orderBy: { earnedAt: "desc" },
    include: {
      user: { select: { id: true, name: true, email: true, image: true } },
      contact: { select: { id: true, name: true, email: true } },
      lead: { select: { id: true, name: true, source: true } },
      project: { select: { id: true, name: true, serviceType: true, company: { select: { name: true } } } },
    },
    take: 500,
  });

  const totals = commissions.reduce(
    (acc, c) => {
      acc.commissionTotal += c.commissionAmount;
      acc.onboardingTotal += c.onboardingAmount;
      if (c.status === "PAID") acc.paidTotal += c.commissionAmount;
      if (c.status === "PENDING") acc.pendingTotal += c.commissionAmount;
      return acc;
    },
    { commissionTotal: 0, onboardingTotal: 0, paidTotal: 0, pendingTotal: 0 },
  );

  return NextResponse.json({
    ok: true,
    thisWeek: cstWeekKey(),
    thisMonth: cstMonthKey(),
    filter: { userId, status, weekOf, monthOf },
    totals,
    commissions,
  });
}
