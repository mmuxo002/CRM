import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/rbac";
import { db } from "@/lib/db";
import { parseAccess } from "@/lib/departments";
import { cstDateKey, cstWeekKey } from "@/lib/sales/cst";
import { computeState } from "@/lib/sales/time";

export const dynamic = "force-dynamic";

// GET /api/admin/timesheets?weekOf=YYYY-Www
// Returns every sales-access user with their full week-of-day sessions + intervals
// so the admin can audit everyone at once, split by person.
export async function GET(request: Request) {
  await requireAdmin();

  const { searchParams } = new URL(request.url);
  const weekOf = searchParams.get("weekOf") || cstWeekKey();

  const users = await db.user.findMany({
    where: { isActive: true },
    select: {
      id: true, name: true, email: true, image: true, role: true,
      accessDepartments: true, isActive: true, lastSeenAt: true,
    },
    orderBy: [{ name: "asc" }],
  });

  // Everyone who has sales in scope (SALES role, full-access, or sales department access)
  const salesUsers = users.filter((u) => {
    if (!u.isActive) return false;
    if (u.role === "SALES") return true;
    const access = parseAccess(u.accessDepartments);
    if (access === "all") return true; // admins with full access included (Juan)
    return access.has("sales");
  });

  const userIds = salesUsers.map((u) => u.id);
  if (userIds.length === 0) {
    return NextResponse.json({
      ok: true, weekOf, todayCST: cstDateKey(), reps: [],
    });
  }

  // Pull a wide window, filter by CST week in JS (SQLite has no week fn).
  const since = new Date();
  since.setUTCDate(since.getUTCDate() - 14);
  const sessions = await db.workSession.findMany({
    where: { userId: { in: userIds }, startedAt: { gte: since } },
    orderBy: { startedAt: "desc" },
    include: { intervals: { orderBy: { startedAt: "asc" } } },
  });

  const byUser = new Map<string, typeof sessions>();
  for (const s of sessions) {
    if (cstWeekKey(s.startedAt) !== weekOf) continue;
    const list = byUser.get(s.userId) ?? [];
    list.push(s);
    byUser.set(s.userId, list);
  }

  const reps = salesUsers.map((u) => {
    const sess = byUser.get(u.id) ?? [];
    const states = sess.map((s) => computeState(s));
    const totals = states.reduce(
      (acc, st) => {
        acc.workMs += st.totals.workMs;
        acc.breakMs += st.totals.breakMs;
        acc.breakCount += st.totals.breakCount;
        return acc;
      },
      { workMs: 0, breakMs: 0, breakCount: 0 },
    );
    return {
      id: u.id,
      name: u.name,
      email: u.email,
      image: u.image,
      role: u.role,
      lastSeenAt: u.lastSeenAt ? u.lastSeenAt.toISOString() : null,
      totals,
      states,
    };
  });

  // Sort by hours worked desc, but Juan (full-access admin) pinned last since he
  // asked to see "my salespeople" first; ties broken by name for stability.
  reps.sort((a, b) => {
    if (b.totals.workMs !== a.totals.workMs) return b.totals.workMs - a.totals.workMs;
    return (a.name || "").localeCompare(b.name || "");
  });

  return NextResponse.json({
    ok: true,
    weekOf,
    todayCST: cstDateKey(),
    reps,
  });
}
