import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { db } from "@/lib/db";
import bcrypt from "bcryptjs";

function generateTempPassword(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789abcdefghijkmnpqrstuvwxyz";
  let out = "";
  for (let i = 0; i < 12; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out + "!";
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if ((session?.user as any)?.role !== "ADMIN") {
    return NextResponse.json({ error: "Admin only" }, { status: 403 });
  }
  const { id } = await params;

  const body = await req.json().catch(() => ({}));
  const custom = typeof body.tempPassword === "string" ? body.tempPassword.trim() : "";
  if (custom && custom.length < 8) {
    return NextResponse.json({ error: "Temporary password must be at least 8 characters" }, { status: 400 });
  }

  const target = await db.user.findUnique({ where: { id }, select: { id: true, email: true } });
  if (!target) return NextResponse.json({ error: "User not found" }, { status: 404 });

  const tempPassword = custom || generateTempPassword();
  const passwordHash = await bcrypt.hash(tempPassword, 10);
  await db.user.update({
    where: { id },
    data: { passwordHash, mustResetPassword: true },
  });

  return NextResponse.json({ ok: true, tempPassword });
}
