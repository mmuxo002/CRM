import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { db } from "@/lib/db";

const DEPT_IDS = new Set(["development", "crm", "sales", "marketing", "all"]);
const ROLES = new Set(["USER", "APPS_DEV", "CRM_DEV", "SALES", "ADMIN"]);
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if ((session?.user as any)?.role !== "ADMIN") return NextResponse.json({ error: "Admin only" }, { status: 403 });
  const { id } = await params;
  const body = await req.json();
  const data: Record<string, unknown> = {};

  if (typeof body.name === "string") {
    const trimmed = body.name.trim();
    if (!trimmed) return NextResponse.json({ error: "Name cannot be empty" }, { status: 400 });
    data.name = trimmed;
  }

  if (typeof body.email === "string") {
    const email = body.email.trim().toLowerCase();
    if (!EMAIL_RE.test(email)) return NextResponse.json({ error: "Invalid email format" }, { status: 400 });
    const clash = await db.user.findFirst({ where: { email, NOT: { id } }, select: { id: true } });
    if (clash) return NextResponse.json({ error: "Another user already uses that email" }, { status: 409 });
    data.email = email;
  }

  if (body.image === null || typeof body.image === "string") {
    const img = body.image === null ? null : body.image.trim();
    data.image = img === "" ? null : img;
  }

  if (typeof body.title === "string") data.title = body.title.trim() || null;

  if (typeof body.role === "string") {
    if (!ROLES.has(body.role)) return NextResponse.json({ error: "Invalid role" }, { status: 400 });
    data.role = body.role;
  }

  if (typeof body.accessDepartments === "string") {
    const parts = body.accessDepartments === ""
      ? []
      : body.accessDepartments.split(",").map((s: string) => s.trim()).filter(Boolean);
    const invalid = parts.find((p: string) => !DEPT_IDS.has(p));
    if (invalid) return NextResponse.json({ error: `Unknown department: ${invalid}` }, { status: 400 });
    data.accessDepartments = parts.includes("all") ? "all" : parts.join(",");
  }

  if (typeof body.isActive === "boolean") data.isActive = body.isActive;

  if (Object.keys(data).length === 0) return NextResponse.json({ error: "No fields" }, { status: 400 });

  try {
    const user = await db.user.update({ where: { id }, data });
    return NextResponse.json({ ok: true, user });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Update failed";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if ((session?.user as any)?.role !== "ADMIN") return NextResponse.json({ error: "Admin only" }, { status: 403 });
  const { id } = await params;
  await db.user.update({ where: { id }, data: { isActive: false } });
  return NextResponse.json({ ok: true });
}
