import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { db } from "@/lib/db";
import bcrypt from "bcryptjs";

const DEPT_IDS = new Set(["development", "crm", "sales", "marketing", "all"]);

function generateTempPassword(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789abcdefghijkmnpqrstuvwxyz";
  let out = "";
  for (let i = 0; i < 12; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out + "!";
}

export async function POST(req: Request) {
  const session = await auth();
  if (!session) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  if ((session.user as any)?.role !== "ADMIN") return NextResponse.json({ error: "Admin only" }, { status: 403 });
  const inviterId = (session.user as any)?.id as string;

  const body = (await req.json()) as { name?: string; email?: string; role?: string; departments?: string[]; title?: string };
  const name = body.name?.trim();
  const email = body.email?.trim().toLowerCase();
  const role = body.role || "USER";
  const title = body.title?.trim() || null;
  const depts = (body.departments || []).filter((d) => DEPT_IDS.has(d));
  if (!name || !email) return NextResponse.json({ error: "Name and email are required" }, { status: 400 });

  const existing = await db.user.findUnique({ where: { email } });
  if (existing) return NextResponse.json({ error: "A user with that email already exists" }, { status: 409 });

  const accessDepartments = depts.length === 0 ? "" : depts.includes("all") ? "all" : depts.join(",");
  const tempPassword = generateTempPassword();
  const passwordHash = await bcrypt.hash(tempPassword, 10);

  const user = await db.user.create({
    data: {
      name, email, title, role,
      teamId: depts.includes("development") || depts.includes("all") ? "APPS" : depts.includes("crm") ? "CRM" : depts.includes("sales") ? "SALES" : "GLOBAL",
      passwordHash, mustResetPassword: true, accessDepartments, isActive: true,
      invitedById: inviterId, invitedAt: new Date(),
    },
  });

  return NextResponse.json({ ok: true, user: { id: user.id, email: user.email, name: user.name }, tempPassword });
}
