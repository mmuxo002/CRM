import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/rbac";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

// GET — returns the currently-active rate (effectiveTo null) plus history (most recent 20).
export async function GET() {
  await requireAdmin();
  const active = await db.commissionRate.findFirst({
    where: { effectiveTo: null },
    orderBy: { effectiveFrom: "desc" },
    include: { updatedBy: { select: { id: true, name: true, email: true } } },
  });
  const history = await db.commissionRate.findMany({
    orderBy: { effectiveFrom: "desc" },
    take: 20,
    include: { updatedBy: { select: { id: true, name: true, email: true } } },
  });
  return NextResponse.json({ ok: true, active, history });
}

// PATCH — sets a new active rate, versioning the previous one.
// Body: { rate: number (0..1), note?: string, basis?: string }
export async function PATCH(req: Request) {
  const { user } = await requireAdmin();
  const body = await req.json().catch(() => ({}));
  const rateNum = Number(body?.rate);
  if (!Number.isFinite(rateNum) || rateNum < 0 || rateNum > 1) {
    return NextResponse.json({ error: "rate must be between 0 and 1 (e.g. 0.2 = 20%)" }, { status: 400 });
  }
  const note = typeof body.note === "string" ? body.note.trim() || null : null;
  const basis = typeof body.basis === "string" && body.basis.trim() ? body.basis.trim() : "ONBOARDING";

  const now = new Date();
  const active = await db.commissionRate.findFirst({ where: { effectiveTo: null } });
  const created = await db.$transaction(async (tx) => {
    if (active) {
      await tx.commissionRate.update({ where: { id: active.id }, data: { effectiveTo: now } });
    }
    return tx.commissionRate.create({
      data: { rate: rateNum, basis, note, effectiveFrom: now, updatedById: user.id },
    });
  });
  return NextResponse.json({ ok: true, rate: created });
}
