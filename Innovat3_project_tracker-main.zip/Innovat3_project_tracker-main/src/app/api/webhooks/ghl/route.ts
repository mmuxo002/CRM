// ╔══════════════════════════════════════════════════════════════════════════╗
// ║                                                                          ║
// ║   ⚠️  PHASE 2 — NOT YET IMPLEMENTED                                       ║
// ║                                                                          ║
// ║   This is a stub. The real GHL booking webhook receiver lives here once  ║
// ║   the team configures the GoHighLevel side. Implementation instructions  ║
// ║   below — DELETE THIS COMMENT BLOCK once the route is built and tested.  ║
// ║                                                                          ║
// ╚══════════════════════════════════════════════════════════════════════════╝
//
// ─────────────────────────────────────────────────────────────────────────────
// WHAT THIS WEBHOOK DOES
// ─────────────────────────────────────────────────────────────────────────────
// Fires when a prospect books a call through our GHL scheduling link
// (https://go.innovat3solutions.com/meet-with-jc). On receipt:
//
//   1. Verify the request is actually from GHL (shared-secret header check).
//   2. Find the matching IntroOffer — preferred: by `utm_content` token in the
//      booking URL params; fallback: by `email` matching IntroOffer.sentToEmail.
//   3. Flip IntroOffer.status → "redeemed", set redeemedAt = now.
//   4. Flip the Lead's status → "READY_TO_CALL" (or keep their existing status
//      if it's already further along the pipeline).
//   5. (Optional, recommended) Kick off the full proposal pipeline for this
//      lead — `void runProposalPipeline(...)` from "@/lib/proposal/pipeline".
//      That way the proposal is ready before the actual call.
//   6. Return 200 quickly (under 5s) so GHL doesn't retry.
//
// ─────────────────────────────────────────────────────────────────────────────
// GHL CONFIGURATION (do this in GoHighLevel BEFORE deploying this route)
// ─────────────────────────────────────────────────────────────────────────────
//   1. In GHL → Automation → Workflows → New Workflow
//   2. Trigger: "Appointment" → "Appointment Booked" (filter by the calendar
//      assigned to https://go.innovat3solutions.com/meet-with-jc)
//   3. Action: "Webhook"
//        • URL: https://app.innovat3solutions.com/api/webhooks/ghl
//          (or whatever NEXT_PUBLIC_APP_URL points to in prod)
//        • Method: POST
//        • Custom Header: `X-INNOVAT3-Webhook-Secret: <generated-secret>`
//        • Body: Send all custom field values + appointment details. At minimum:
//            { contact: { email, first_name, last_name, phone, custom_fields },
//              appointment: { id, start_time, end_time, calendar_id },
//              utm: { content, source, campaign }   ← the offer token lives in utm.content
//            }
//   4. Save & Activate the workflow.
//   5. Generate a long random secret (e.g. `openssl rand -hex 32`) and:
//        • Paste it into the X-INNOVAT3-Webhook-Secret header in the GHL action
//        • Add the same value to .env as GHL_WEBHOOK_SECRET=<value>
//        • Add it to Vercel env vars when deploying.
//
// ─────────────────────────────────────────────────────────────────────────────
// PAYLOAD ASSUMPTIONS (verify these against an actual GHL "Test Webhook" send)
// ─────────────────────────────────────────────────────────────────────────────
// The exact GHL payload shape varies by workflow config. Likely fields:
//   • contact.email             — primary key for fallback matching
//   • contact.first_name, .last_name, .phone
//   • contact.custom_fields     — anything we set up there
//   • appointment.id            — for de-duping if GHL retries
//   • appointment.start_time    — ISO datetime, useful for the proposal email
//   • Some carry of UTM params (often as utm_content or in custom fields).
//     Confirm where utm_content lands in the actual payload — that's the
//     IntroOffer.token we stamped onto the scheduling URL in
//     src/app/api/leads/[id]/intro-offer/send/route.ts.
//
// ─────────────────────────────────────────────────────────────────────────────
// LOCAL TESTING
// ─────────────────────────────────────────────────────────────────────────────
//   • Use ngrok: `ngrok http 3000` → paste the public URL into a TEST workflow
//     in GHL, fire its "Run Test" action.
//   • Or call directly with curl, simulating GHL's payload:
//       curl -X POST http://localhost:3000/api/webhooks/ghl \
//         -H "X-INNOVAT3-Webhook-Secret: <secret>" \
//         -H "Content-Type: application/json" \
//         -d '{"contact":{"email":"test@example.com"},"utm":{"content":"<offer-token>"}}'
//
// ─────────────────────────────────────────────────────────────────────────────
// PSEUDOCODE FOR THE IMPLEMENTATION
// ─────────────────────────────────────────────────────────────────────────────
//   export async function POST(req: Request) {
//     // 1. Verify shared secret
//     const secret = req.headers.get("x-innovat3-webhook-secret");
//     if (secret !== process.env.GHL_WEBHOOK_SECRET) {
//       return new Response("forbidden", { status: 403 });
//     }
//
//     const body = await req.json();
//
//     // 2. Find the IntroOffer
//     const offerToken = body?.utm?.content ?? body?.contact?.custom_fields?.utm_content;
//     const email = body?.contact?.email;
//     const offer = offerToken
//       ? await db.introOffer.findUnique({ where: { token: offerToken }, include: { lead: true } })
//       : email
//         ? await db.introOffer.findFirst({
//             where: { sentToEmail: email, status: "active" },
//             orderBy: { sentAt: "desc" },
//             include: { lead: true },
//           })
//         : null;
//
//     if (!offer) {
//       // Lead booked without coming from one of our offers — log + 200.
//       console.warn("[ghl-webhook] booking with no matching IntroOffer", { email, offerToken });
//       return Response.json({ ok: true, matched: false });
//     }
//
//     // 3. Flip offer → redeemed
//     await db.introOffer.update({
//       where: { id: offer.id },
//       data: { status: "redeemed", redeemedAt: new Date() },
//     });
//
//     // 4. Flip lead → READY_TO_CALL (only if not further along)
//     const advancedStatuses = new Set(["READY_TO_CALL", "MEETING", "PROPOSAL"]);
//     if (!advancedStatuses.has(offer.lead.status)) {
//       await db.lead.update({
//         where: { id: offer.leadId },
//         data: { status: "READY_TO_CALL" },
//       });
//     }
//
//     // 5. (Optional) Auto-kick the full proposal pipeline so it's ready by the call
//     const proposal = await db.proposal.create({
//       data: {
//         token: nanoid(22),
//         leadId: offer.leadId,
//         createdById: offer.sentByUserId,  // attribute to the rep who sent the offer
//         status: "pending",
//         stage: "Queued (auto from booking)",
//         progress: 0,
//       },
//     });
//     void runProposalPipeline(proposal.id);
//
//     return Response.json({ ok: true, matched: true, proposalId: proposal.id });
//   }
//
// ─────────────────────────────────────────────────────────────────────────────
// SECURITY NOTES
// ─────────────────────────────────────────────────────────────────────────────
//   • DO use a shared-secret header (above). GHL doesn't sign requests with
//     HMAC by default, so this is the cheapest reliable check.
//   • DO timing-safe compare the secret if you want to be belt-and-suspenders:
//        import { timingSafeEqual } from "node:crypto";
//   • Rate-limit if you ever expose this without a secret.
//   • DO NOT trust the email field alone — anyone could POST to the endpoint
//     with a real customer's email. The secret header is what gates this.
//
// ─────────────────────────────────────────────────────────────────────────────
// ENV VAR TO ADD (already stubbed in .env — uncomment & fill when you have it)
// ─────────────────────────────────────────────────────────────────────────────
//   GHL_WEBHOOK_SECRET="<openssl rand -hex 32 output>"

import { NextResponse } from "next/server";

export const runtime = "nodejs";

export async function POST(_req: Request) {
  return NextResponse.json(
    {
      error: "Not Implemented",
      message:
        "GHL booking webhook is not wired yet. See the comment block at the top of src/app/api/webhooks/ghl/route.ts for the implementation steps. Required: GHL workflow + shared secret + GHL_WEBHOOK_SECRET env var.",
    },
    { status: 501 },
  );
}
