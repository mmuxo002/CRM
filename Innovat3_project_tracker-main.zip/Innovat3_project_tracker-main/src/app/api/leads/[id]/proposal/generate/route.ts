// Kick off the full Rend3r proposal pipeline for a Lead.
//
// Creates a Proposal row with status="pending", returns { id, token }
// immediately, and runs the pipeline in the background. The rep UI redirects
// to a status page that polls /api/proposals/[id]/status until status=ready.

import { NextResponse } from "next/server";
import { nanoid } from "nanoid";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";
import { runProposalPipeline } from "@/lib/proposal/pipeline";

// Pipeline runs Puppeteer + multiple AI calls — needs Node runtime, not Edge.
export const runtime = "nodejs";
// Allow long-running fire-and-forget; on Vercel set vercel.json maxDuration.
export const maxDuration = 300;

export async function POST(
  _req: Request,
  ctx: RouteContext<"/api/leads/[id]/proposal/generate">,
) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const { id: leadId } = await ctx.params;

  const lead = await db.lead.findUnique({ where: { id: leadId } });
  if (!lead) {
    return NextResponse.json({ error: "Lead not found" }, { status: 404 });
  }

  // 22-char URL-safe token. Unguessable enough for a public link.
  const token = nanoid(22);

  const proposal = await db.proposal.create({
    data: {
      token,
      leadId,
      createdById: user.id,
      status: "pending",
      stage: "Queued",
      progress: 0,
    },
    select: { id: true, token: true },
  });

  // Fire-and-forget: pipeline runs after the response is sent. Locally this
  // works because the Node process is long-lived. On Vercel, swap to
  // `import { after } from "next/server"; after(() => runProposalPipeline(...))`
  // (or a queue) before deploying.
  void runProposalPipeline(proposal.id).catch((err) => {
    console.error(`[proposal:${proposal.id}] unhandled pipeline error`, err);
  });

  return NextResponse.json({ ok: true, id: proposal.id, token: proposal.token });
}
