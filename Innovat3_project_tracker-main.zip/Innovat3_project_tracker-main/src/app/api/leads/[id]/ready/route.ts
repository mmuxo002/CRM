import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";

export async function POST(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN") return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id } = await ctx.params;
  const lead = await db.lead.update({ where: { id }, data: { status: "READY_TO_CALL" } });
  await db.activity.create({ data: { kind: "SYSTEM", title: "Marked Ready to Call → pushed to High Level", teamId: "SALES", actorId: user.id, leadId: lead.id } });
  return NextResponse.json({ ok: true, ghlContactId: lead.ghlContactId || "HL-" + lead.id.slice(0, 6) });
}
