import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";
import { lookupSunbiz, type SunbizResult } from "@/lib/sales/sunbiz";
import { lookupApolloDecisionMakers, apolloConfigured, type ApolloPerson } from "@/lib/sales/apollo";

export interface DecisionMakerCandidate {
  name: string;
  title: string;
  source: "sunbiz" | "apollo" | "persona";
  address?: string;
  email?: string;
  linkedinUrl?: string;
  filingDate?: string;
  entityStatus?: string;
  detailUrl?: string;
}

export async function POST(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const { id } = await ctx.params;
  const lead = await db.lead.findUnique({ where: { id }, include: { persona: true } });
  if (!lead) return NextResponse.json({ error: "Lead not found" }, { status: 404 });

  const candidates: DecisionMakerCandidate[] = [];

  // 1) Sunbiz — Florida public corporate filings
  let sunbiz: SunbizResult | null = null;
  try {
    sunbiz = await lookupSunbiz(lead.name);
  } catch {}

  if (sunbiz) {
    for (const officer of sunbiz.officers) {
      candidates.push({
        name: officer.name,
        title: officer.title,
        source: "sunbiz",
        address: officer.address,
        filingDate: sunbiz.filingDate,
        entityStatus: sunbiz.status,
        detailUrl: sunbiz.detailUrl,
      });
    }
    if (sunbiz.registeredAgent && !candidates.find((c) => c.name === sunbiz!.registeredAgent!.name)) {
      candidates.push({
        name: sunbiz.registeredAgent.name,
        title: "Registered Agent",
        source: "sunbiz",
        address: sunbiz.registeredAgent.address,
        entityStatus: sunbiz.status,
        detailUrl: sunbiz.detailUrl,
      });
    }
  }

  // 2) Apollo — only if configured via APOLLO_API_KEY
  let apolloPeople: ApolloPerson[] = [];
  if (apolloConfigured()) {
    try {
      const apolloResult = await lookupApolloDecisionMakers({
        businessName: lead.name,
        website: lead.website,
        location: lead.address || lead.location,
      });
      if (apolloResult) {
        apolloPeople = apolloResult.people;
        for (const p of apolloPeople) {
          candidates.push({
            name: p.name,
            title: p.title,
            source: "apollo",
            email: p.email,
            linkedinUrl: p.linkedinUrl,
          });
        }
      }
    } catch {}
  }

  // Pick the primary candidate — prefer Sunbiz officers with an executive title
  const executiveRank: Record<string, number> = {
    "PRESIDENT": 10, "CEO": 10, "OWNER": 10, "MANAGING MEMBER": 9,
    "MANAGING PARTNER": 9, "FOUNDER": 9, "CO-FOUNDER": 8,
    "MANAGER": 7, "MEMBER": 6, "VICE PRESIDENT": 6,
    "DIRECTOR": 5, "SECRETARY": 4, "TREASURER": 4,
    "AUTHORIZED MEMBER": 5, "AUTHORIZED PERSON": 4,
    "REGISTERED AGENT": 2,
  };

  const rankedCandidates = [...candidates].sort((a, b) => {
    const rankA = executiveRank[a.title.toUpperCase()] || 0;
    const rankB = executiveRank[b.title.toUpperCase()] || 0;
    if (rankB !== rankA) return rankB - rankA;
    // Sunbiz is more verified than Apollo for ownership data
    if (a.source === "sunbiz" && b.source !== "sunbiz") return -1;
    if (b.source === "sunbiz" && a.source !== "sunbiz") return 1;
    return 0;
  });

  const primary = rankedCandidates[0];

  // Persist primary into Persona (create if missing) and return candidates
  if (primary) {
    if (lead.persona) {
      await db.persona.update({
        where: { leadId: id },
        data: {
          decisionMakerName: primary.name,
          decisionMakerTitle: primary.title,
        },
      });
    } else {
      await db.persona.create({
        data: {
          leadId: id,
          decisionMakerName: primary.name,
          decisionMakerTitle: primary.title,
        },
      });
    }
  }

  await db.activity.create({
    data: {
      kind: "SYSTEM",
      title: primary
        ? `Decision maker lookup — found ${primary.name} (${primary.title}) via ${primary.source}`
        : "Decision maker lookup — no public records found",
      teamId: "SALES",
      actorId: user.id,
      leadId: id,
    },
  });

  return NextResponse.json({
    ok: true,
    primary: primary || null,
    candidates: rankedCandidates,
    sources: {
      sunbiz: sunbiz
        ? {
            entityName: sunbiz.entityName,
            documentNumber: sunbiz.documentNumber,
            status: sunbiz.status,
            entityType: sunbiz.entityType,
            filingDate: sunbiz.filingDate,
            principalAddress: sunbiz.principalAddress,
            detailUrl: sunbiz.detailUrl,
            officerCount: sunbiz.officers.length,
          }
        : null,
      apollo: apolloConfigured()
        ? { enabled: true, resultCount: apolloPeople.length }
        : { enabled: false, resultCount: 0 },
    },
  });
}
