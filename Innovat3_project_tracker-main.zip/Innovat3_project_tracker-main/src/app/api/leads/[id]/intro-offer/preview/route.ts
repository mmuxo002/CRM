// Preview endpoint for the intro offer email.
// No DB writes. Renders the email the agent would send with whatever
// overrides are passed in.
//
// Two modes:
//   • Initial load (no overrides): runs Sonnet to AI-generate a personalized
//     subject + body using persona research, then renders.
//   • Subsequent loads (with overrides) OR explicit `regenerate: true`: use
//     overrides directly, no AI call (saves ~$0.003 + ~3-8s per keystroke
//     debounce-cycle). `regenerate: true` forces a fresh AI roll.

import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";
import {
  buildIntroOfferEmail,
  defaultIntroOfferBody,
  defaultIntroOfferSubject,
  cleanBusinessName,
  firstNameFrom,
  type DefaultBodyContext,
} from "@/lib/proposal/intro-offer-email";
import { generateIntroOfferDefaults } from "@/lib/proposal/intro-offer-ai";

export const runtime = "nodejs";

function safeJsonParse<T>(s: string | null | undefined, fallback: T): T {
  if (!s) return fallback;
  try { return JSON.parse(s) as T; } catch { return fallback; }
}

function domainFrom(url: string | null): string | null {
  if (!url) return null;
  try {
    const u = new URL(url.startsWith("http") ? url : `https://${url}`);
    return u.hostname.replace(/^www\./, "");
  } catch {
    return null;
  }
}

export async function POST(
  req: Request,
  ctx: RouteContext<"/api/leads/[id]/intro-offer/preview">,
) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const { id: leadId } = await ctx.params;

  const lead = await db.lead.findUnique({
    where: { id: leadId },
    include: { persona: true, company: true, salesProject: true },
  });
  if (!lead) return NextResponse.json({ error: "Lead not found" }, { status: 404 });

  const body = (await req.json().catch(() => ({}))) as {
    subjectOverride?: string | null;
    bodyOverride?: string | null;
    recipientFirstNameOverride?: string | null;
    businessNameDisplayOverride?: string | null;
    /** When true, ignores any prior body/subject and re-runs the AI generator. */
    regenerate?: boolean;
  };

  // ── Compute base defaults from persona + company ──
  const businessNameDisplayDefault =
    cleanBusinessName(lead.company?.name || "") ||
    cleanBusinessName(lead.name) ||
    lead.name;
  const recipientFirstNameDefault = firstNameFrom(lead.persona?.decisionMakerName);
  const painPoints = safeJsonParse<string[]>(lead.persona?.painPoints, []);
  const opportunities = safeJsonParse<string[]>(lead.persona?.opportunities, []);
  const challenges = safeJsonParse<string[]>(lead.persona?.challenges, []);
  const competitors = safeJsonParse<string[]>(lead.persona?.competitors, []);
  const rawServices = safeJsonParse<Array<string | { name?: string }>>(lead.recommendedServices, []);
  const recommendedServiceNames = rawServices
    .map((s) => (typeof s === "string" ? s : s?.name || ""))
    .filter(Boolean);
  const industry = lead.company?.industry || lead.salesProject?.niche || null;

  // ── Decide whether to call the AI ──
  // Initial load = no override fields present. Regenerate = explicit user
  // request. Both call AI; everything else uses overrides as-is.
  const isInitialLoad =
    body.subjectOverride === undefined &&
    body.bodyOverride === undefined &&
    body.recipientFirstNameOverride === undefined &&
    body.businessNameDisplayOverride === undefined;
  const shouldRunAI = isInitialLoad || body.regenerate === true;

  // Fallback static defaults (used if AI fails OR if not running AI).
  const staticBodyCtx: DefaultBodyContext = {
    businessNameDisplay: businessNameDisplayDefault,
    hasWebsite: !!lead.website,
    painPoints,
    opportunities,
    recommendedServiceNames,
    industry,
  };
  const staticSubjectDefault = defaultIntroOfferSubject(businessNameDisplayDefault);
  const staticBodyDefault = defaultIntroOfferBody(staticBodyCtx);

  // Run AI if appropriate.
  let aiSubject: string | null = null;
  let aiBody: string | null = null;
  let aiUsed = false;
  if (shouldRunAI) {
    const ai = await generateIntroOfferDefaults({
      businessName: businessNameDisplayDefault,
      recipientFirstName: recipientFirstNameDefault,
      industry,
      location: lead.address || lead.location,
      website: lead.website,
      websiteDomain: domainFrom(lead.website),
      painPoints,
      opportunities,
      challenges,
      competitors,
      digitalPresence: lead.persona?.digitalPresence || null,
      googleRating: lead.googleRating,
      googleReviewCount: lead.googleReviewCount,
      businessSummary: lead.persona?.businessSummary || null,
    });
    if (ai) {
      aiSubject = ai.subject;
      aiBody = ai.body;
      aiUsed = true;
    }
  }

  const subjectDefault = aiSubject || staticSubjectDefault;
  const bodyDefault = aiBody || staticBodyDefault;

  // ── Apply overrides (if any) on top of defaults ──
  const recipientFirstName = body.recipientFirstNameOverride ?? recipientFirstNameDefault;
  const businessNameDisplay = (body.businessNameDisplayOverride ?? businessNameDisplayDefault) || lead.name;

  // Subject: if regenerate, use AI's fresh subject. Otherwise honor any
  // subjectOverride; if business name was overridden but subject wasn't,
  // re-derive a static subject so the business name stays in sync.
  let subject: string;
  if (body.regenerate && aiSubject) {
    subject = aiSubject;
  } else if (body.subjectOverride !== undefined && body.subjectOverride !== null) {
    subject = body.subjectOverride;
  } else if (body.businessNameDisplayOverride) {
    subject = defaultIntroOfferSubject(businessNameDisplay);
  } else {
    subject = subjectDefault;
  }

  // Body: same precedence pattern.
  let bodyText: string;
  if (body.regenerate && aiBody) {
    bodyText = aiBody;
  } else if (body.bodyOverride !== undefined && body.bodyOverride !== null) {
    bodyText = body.bodyOverride;
  } else {
    bodyText = bodyDefault;
  }

  // Fake the expires + URL for preview purposes only.
  const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);
  const baseUrl = process.env.NEXT_PUBLIC_APP_URL?.replace(/\/$/, "") || "http://localhost:3000";
  const offerUrl = `${baseUrl}/offer/preview`;

  const rendered = buildIntroOfferEmail({
    recipientFirstName,
    businessNameDisplay,
    fromName: user.name || "Juan from INNOVAT3",
    offerUrl,
    expiresAt,
    subject,
    body: bodyText,
  });

  return NextResponse.json({
    ok: true,
    defaults: {
      recipientFirstName: recipientFirstNameDefault,
      businessNameDisplay: businessNameDisplayDefault,
      subject: subjectDefault,
      body: bodyDefault,
    },
    leadInfo: {
      hasPersona: !!lead.persona,
      painPointCount: painPoints.length,
      recommendedServiceCount: recommendedServiceNames.length,
      hasDecisionMakerName: !!recipientFirstNameDefault,
      aiUsed,
    },
    preview: {
      subject: rendered.subject,
      html: rendered.html,
      text: rendered.text,
      expiresAt: expiresAt.toISOString(),
    },
  });
}
