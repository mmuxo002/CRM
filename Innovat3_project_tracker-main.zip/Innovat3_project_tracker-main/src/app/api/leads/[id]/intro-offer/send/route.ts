// Send the 24h cold-lead intro offer (25% off onboarding) via Resend.
// Body: {
//   to?: string,
//   schedulingLink?: string,
//   subjectOverride?, bodyOverride?,
//   recipientFirstNameOverride?, businessNameDisplayOverride?
// }
// Anything not overridden falls back to persona-driven defaults built from
// the same logic as the preview endpoint, so the rep can either click "Send"
// straight from defaults or after editing in the modal.

import { NextResponse } from "next/server";
import { nanoid } from "nanoid";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";
import {
  sendIntroOfferEmail,
  defaultIntroOfferBody,
  defaultIntroOfferSubject,
  cleanBusinessName,
  firstNameFrom,
  type DefaultBodyContext,
} from "@/lib/proposal/intro-offer-email";

export const runtime = "nodejs";

const DEFAULT_SCHEDULING_LINK = "https://go.innovat3solutions.com/meet-with-jc";

function safeJsonParse<T>(s: string | null | undefined, fallback: T): T {
  if (!s) return fallback;
  try { return JSON.parse(s) as T; } catch { return fallback; }
}

/** Append GHL-friendly query params to the scheduling URL so the booking
 * form pre-fills and the eventual booking webhook tells us which lead booked. */
function withAttribution(
  base: string,
  args: { email: string; firstName: string; lastName: string; phone: string | null; offerToken: string },
): string {
  const url = new URL(base);
  if (args.email) url.searchParams.set("email", args.email);
  if (args.firstName) url.searchParams.set("first_name", args.firstName);
  if (args.lastName) url.searchParams.set("last_name", args.lastName);
  if (args.phone) url.searchParams.set("phone", args.phone);
  url.searchParams.set("utm_source", "innovat3-pulse");
  url.searchParams.set("utm_campaign", "intro-offer-25");
  url.searchParams.set("utm_content", args.offerToken);
  return url.toString();
}

export async function POST(
  req: Request,
  ctx: RouteContext<"/api/leads/[id]/intro-offer/send">,
) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const { id: leadId } = await ctx.params;

  const lead = await db.lead.findUnique({
    where: { id: leadId },
    include: { persona: true, company: true, salesProject: true },
  });
  if (!lead) return NextResponse.json({ error: "Lead not found" }, { status: 404 });

  const body = (await req.json().catch(() => ({}))) as {
    to?: string;
    schedulingLink?: string;
    subjectOverride?: string | null;
    bodyOverride?: string | null;
    recipientFirstNameOverride?: string | null;
    businessNameDisplayOverride?: string | null;
  };

  const to = body.to?.trim() || lead.email;
  if (!to) return NextResponse.json({ error: "No recipient email" }, { status: 400 });

  const baseLink = body.schedulingLink?.trim() || process.env.GHL_SCHEDULING_LINK || DEFAULT_SCHEDULING_LINK;

  // ── Build the resolved field set: overrides on top of persona-driven defaults ──
  const businessNameDisplayDefault =
    cleanBusinessName(lead.company?.name || "") ||
    cleanBusinessName(lead.name) ||
    lead.name;
  const businessNameDisplay = body.businessNameDisplayOverride?.trim() || businessNameDisplayDefault;

  const recipientFirstName =
    (body.recipientFirstNameOverride ?? "").trim() ||
    firstNameFrom(lead.persona?.decisionMakerName);

  const painPoints = safeJsonParse<string[]>(lead.persona?.painPoints, []);
  const opportunities = safeJsonParse<string[]>(lead.persona?.opportunities, []);
  const rawServices = safeJsonParse<Array<string | { name?: string }>>(lead.recommendedServices, []);
  const recommendedServiceNames = rawServices
    .map((s) => (typeof s === "string" ? s : s?.name || ""))
    .filter(Boolean);
  const industry = lead.company?.industry || lead.salesProject?.niche || null;

  const defaultBodyCtx: DefaultBodyContext = {
    businessNameDisplay,
    hasWebsite: !!lead.website,
    painPoints,
    opportunities,
    recommendedServiceNames,
    industry,
  };

  const subject = body.subjectOverride?.trim() || defaultIntroOfferSubject(businessNameDisplay);
  const bodyText = body.bodyOverride?.trim() || defaultIntroOfferBody(defaultBodyCtx);

  // ── Create the IntroOffer row ──
  const token = nanoid(22);
  const sentAt = new Date();
  const expiresAt = new Date(sentAt.getTime() + 24 * 60 * 60 * 1000);

  const [firstNameForUrl, ...rest] = (lead.name || "").split(" ");
  const lastNameForUrl = rest.join(" ");
  const schedulingLink = withAttribution(baseLink, {
    email: to,
    firstName: firstNameForUrl || "",
    lastName: lastNameForUrl,
    phone: lead.phone,
    offerToken: token,
  });

  const offer = await db.introOffer.create({
    data: {
      token,
      leadId,
      sentByUserId: user.id,
      sentAt,
      expiresAt,
      schedulingLink,
      sentToEmail: to,
      status: "active",
    },
    select: { id: true, token: true, expiresAt: true },
  });

  const baseUrl = process.env.NEXT_PUBLIC_APP_URL?.replace(/\/$/, "") || "http://localhost:3000";
  const offerUrl = `${baseUrl}/offer/${offer.token}`;

  const result = await sendIntroOfferEmail({
    to,
    fromEmail: process.env.RESEND_FROM_EMAIL || "",
    recipientFirstName,
    businessNameDisplay,
    fromName: user.name || "Juan from INNOVAT3",
    offerUrl,
    expiresAt: offer.expiresAt,
    subject,
    body: bodyText,
  });

  if (!result.ok) {
    return NextResponse.json({ error: result.error, offerId: offer.id }, { status: 502 });
  }

  await db.introOffer.update({
    where: { id: offer.id },
    data: { emailMessageId: result.messageId },
  });

  return NextResponse.json({
    ok: true,
    offerId: offer.id,
    token: offer.token,
    expiresAt: offer.expiresAt.toISOString(),
    offerUrl,
  });
}
