import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";
import { recordLeadActivity } from "@/lib/sales/claim-pool";

// Bulk-add leads to the sales pipeline and assign to current user
export async function POST(req: Request) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN")
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { leadIds } = await req.json();
  if (!Array.isArray(leadIds) || leadIds.length === 0)
    return NextResponse.json({ error: "leadIds array required" }, { status: 400 });

  let added = 0;
  for (const id of leadIds) {
    await db.lead.update({
      where: { id },
      data: {
        status: "PROSPECT",
        assignedTo: user.id,
      },
    });

    // Log activity
    await db.activity.create({
      data: {
        kind: "SYSTEM",
        title: "Added to pipeline",
        body: `Assigned to ${user.name || user.email}`,
        teamId: "SALES",
        actorId: user.id,
        leadId: id,
      },
    });

    await recordLeadActivity(id);

    added++;
  }

  return NextResponse.json({ ok: true, added });
}
