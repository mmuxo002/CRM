import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";
import { recordLeadActivity } from "@/lib/sales/claim-pool";

const VALID = new Set(["NEW", "PROSPECT", "OUTREACHED", "SCHEDULED", "CLOSED", "NOT_INTERESTED"]);

export async function POST(req: Request) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN") return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id, toColumn } = await req.json();
  if (!id || !VALID.has(toColumn)) return NextResponse.json({ error: "Invalid" }, { status: 400 });
  await db.lead.update({ where: { id }, data: { status: toColumn } });
  await recordLeadActivity(id);
  return NextResponse.json({ ok: true });
}
