import { NextResponse } from "next/server";
import { requireSession } from "@/lib/rbac";
import { startBreak, endBreak } from "@/lib/sales/time";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN") {
    return NextResponse.json({ error: "Sales role required" }, { status: 403 });
  }
  const body = await request.json().catch(() => ({}));
  const action = body?.action as "start" | "end" | undefined;
  try {
    if (action === "start") {
      const state = await startBreak(user.id);
      return NextResponse.json({ ok: true, state });
    }
    if (action === "end") {
      const state = await endBreak(user.id);
      return NextResponse.json({ ok: true, state });
    }
    return NextResponse.json({ error: "action must be 'start' or 'end'" }, { status: 400 });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: msg }, { status: 409 });
  }
}
