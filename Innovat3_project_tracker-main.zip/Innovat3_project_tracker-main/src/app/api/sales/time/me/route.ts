import { NextResponse } from "next/server";
import { requireSession } from "@/lib/rbac";
import { db } from "@/lib/db";
import { cstDateKey } from "@/lib/sales/cst";
import { computeState } from "@/lib/sales/time";

export const dynamic = "force-dynamic";

export async function GET() {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN") {
    return NextResponse.json({ error: "Sales role required" }, { status: 403 });
  }
  const todayCST = cstDateKey();
  const session = await db.workSession.findUnique({
    where: { userId_dateCST: { userId: user.id, dateCST: todayCST } },
    include: { intervals: { orderBy: { startedAt: "asc" } } },
  });
  if (!session) {
    return NextResponse.json({ ok: true, state: null, dateCST: todayCST });
  }
  return NextResponse.json({ ok: true, state: computeState(session), dateCST: todayCST });
}
