import { NextResponse } from "next/server";
import { requireSession } from "@/lib/rbac";
import { endTodaysSession } from "@/lib/sales/time";

export const dynamic = "force-dynamic";

export async function POST() {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN") {
    return NextResponse.json({ error: "Sales role required" }, { status: 403 });
  }
  try {
    const state = await endTodaysSession(user.id);
    return NextResponse.json({ ok: true, state });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: msg }, { status: 409 });
  }
}
