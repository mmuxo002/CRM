import { NextResponse } from "next/server";
import { requireSession } from "@/lib/rbac";
import { getOrStartTodaysSession, computeState } from "@/lib/sales/time";

export const dynamic = "force-dynamic";

export async function POST() {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN") {
    return NextResponse.json({ error: "Sales role required" }, { status: 403 });
  }
  const { session, created } = await getOrStartTodaysSession(user.id);
  const state = computeState(session);
  return NextResponse.json({ ok: true, created, state });
}
