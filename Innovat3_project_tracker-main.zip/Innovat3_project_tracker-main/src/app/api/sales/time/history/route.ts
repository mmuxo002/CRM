import { NextResponse } from "next/server";
import { requireSession } from "@/lib/rbac";
import { db } from "@/lib/db";
import { cstDateKey, cstWeekKey } from "@/lib/sales/cst";
import { computeState } from "@/lib/sales/time";

export const dynamic = "force-dynamic";

// GET /api/sales/time/history?weekOf=YYYY-Www
// Returns every WorkSession for the current user within the given CST week,
// or the current CST week if no param. For admins, accepts ?userId=<id>
// to view another rep's history.
export async function GET(request: Request) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN") {
    return NextResponse.json({ error: "Sales role required" }, { status: 403 });
  }

  const { searchParams } = new URL(request.url);
  const weekOf = searchParams.get("weekOf") || cstWeekKey();
  const targetUserId = user.role === "ADMIN" ? (searchParams.get("userId") || user.id) : user.id;

  // Pull a wide date range then filter by week; SQLite has no week functions,
  // so we compute in JS. Reps rarely need more than ~14 days, keep the window small.
  const since = new Date();
  since.setUTCDate(since.getUTCDate() - 14);
  const sessions = await db.workSession.findMany({
    where: { userId: targetUserId, startedAt: { gte: since } },
    orderBy: { startedAt: "desc" },
    include: { intervals: { orderBy: { startedAt: "asc" } } },
  });

  const filtered = sessions.filter((s) => cstWeekKey(s.startedAt) === weekOf);
  const states = filtered.map((s) => computeState(s));

  const totals = states.reduce(
    (acc, st) => {
      acc.workMs += st.totals.workMs;
      acc.breakMs += st.totals.breakMs;
      acc.breakCount += st.totals.breakCount;
      return acc;
    },
    { workMs: 0, breakMs: 0, breakCount: 0 },
  );

  return NextResponse.json({
    ok: true,
    weekOf,
    todayCST: cstDateKey(),
    totals,
    states,
  });
}
