import { NextResponse } from "next/server";
import { requireSession } from "@/lib/rbac";
import { tickHeartbeat } from "@/lib/sales/time";

export const dynamic = "force-dynamic";

export async function POST() {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN") {
    return NextResponse.json({ error: "Sales role required" }, { status: 403 });
  }
  const result = await tickHeartbeat(user.id);
  if (result.kind === "signOut") {
    return NextResponse.json({ ok: true, signOut: true, reason: result.reason });
  }
  if (result.kind === "needsStart") {
    return NextResponse.json({ ok: true, needsStart: true });
  }
  return NextResponse.json({
    ok: true,
    state: result.state,
    transitioned: "transitioned" in result ? result.transitioned : null,
  });
}
