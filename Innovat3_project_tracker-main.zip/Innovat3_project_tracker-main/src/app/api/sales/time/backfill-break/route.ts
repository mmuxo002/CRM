import { NextResponse } from "next/server";
import { requireSession } from "@/lib/rbac";
import { backfillBreak } from "@/lib/sales/time";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN") {
    return NextResponse.json({ error: "Sales role required" }, { status: 403 });
  }
  const body = await request.json().catch(() => ({}));
  const startAt = body?.startAt ? new Date(body.startAt) : null;
  const endAt = body?.endAt ? new Date(body.endAt) : null;
  const note = typeof body?.note === "string" ? body.note : undefined;
  if (!startAt || !endAt || isNaN(startAt.getTime()) || isNaN(endAt.getTime())) {
    return NextResponse.json({ error: "startAt and endAt (ISO) required" }, { status: 400 });
  }
  try {
    const state = await backfillBreak(user.id, startAt, endAt, note);
    return NextResponse.json({ ok: true, state });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: msg }, { status: 409 });
  }
}
