import { NextResponse } from "next/server";
import { requireSession } from "@/lib/rbac";
import { db } from "@/lib/db";
import { cstMonthKey, cstWeekKey } from "@/lib/sales/cst";

export const dynamic = "force-dynamic";

// GET /api/sales/commissions/me?weekOf=YYYY-Www&monthOf=YYYY-MM
// Returns this rep's commissions with per-range totals. Either filter may be
// specified; when neither is given, returns recent (last ~60 days).
export async function GET(request: Request) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN") {
    return NextResponse.json({ error: "Sales role required" }, { status: 403 });
  }

  const { searchParams } = new URL(request.url);
  const weekOf = searchParams.get("weekOf");
  const monthOf = searchParams.get("monthOf");

  const where: { userId: string; weekOfCST?: string; monthOfCST?: string; earnedAt?: { gte: Date } } = {
    userId: user.id,
  };
  if (weekOf) where.weekOfCST = weekOf;
  else if (monthOf) where.monthOfCST = monthOf;
  else {
    const since = new Date();
    since.setUTCDate(since.getUTCDate() - 60);
    where.earnedAt = { gte: since };
  }

  const commissions = await db.commission.findMany({
    where,
    orderBy: { earnedAt: "desc" },
    include: {
      contact: { select: { id: true, name: true, email: true } },
      lead: { select: { id: true, name: true, source: true } },
      project: { select: { id: true, name: true, serviceType: true } },
    },
  });

  const totals = commissions.reduce(
    (acc, c) => {
      acc.onboardingTotal += c.onboardingAmount;
      acc.commissionTotal += c.commissionAmount;
      acc.paidTotal += c.status === "PAID" ? c.commissionAmount : 0;
      acc.pendingTotal += c.status === "PENDING" ? c.commissionAmount : 0;
      return acc;
    },
    { onboardingTotal: 0, commissionTotal: 0, paidTotal: 0, pendingTotal: 0 },
  );

  return NextResponse.json({
    ok: true,
    thisWeek: cstWeekKey(),
    thisMonth: cstMonthKey(),
    filter: { weekOf, monthOf },
    totals,
    commissions,
  });
}
