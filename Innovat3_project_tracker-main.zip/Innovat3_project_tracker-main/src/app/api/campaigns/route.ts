import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { db } from "@/lib/db";

export async function POST(req: Request) {
  const session = await auth();
  if (!session) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  const userId = (session.user as any)?.id as string;

  const body = await req.json() as { name?: string; entityName?: string; description?: string; funnelUrl?: string; websiteUrl?: string; coverColor?: string; service?: string; niche?: string };
  if (!body.name?.trim()) return NextResponse.json({ error: "Name is required" }, { status: 400 });

  const campaign = await db.campaign.create({
    data: {
      name: body.name.trim(),
      entityName: body.entityName?.trim() || null,
      description: body.description?.trim() || null,
      funnelUrl: body.funnelUrl?.trim() || null,
      websiteUrl: body.websiteUrl?.trim() || null,
      service: body.service?.trim() || null,
      niche: body.niche?.trim() || null,
      coverColor: body.coverColor || "#ec4899",
      ownerId: userId,
    },
  });

  return NextResponse.json({ ok: true, campaign });
}
