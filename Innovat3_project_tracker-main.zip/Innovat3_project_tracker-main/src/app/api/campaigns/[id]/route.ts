import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { db } from "@/lib/db";

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  const { id } = await params;

  const body = await req.json() as {
    name?: string;
    entityName?: string | null;
    description?: string | null;
    funnelUrl?: string | null;
    websiteUrl?: string | null;
    coverColor?: string;
    service?: string | null;
    niche?: string | null;
    status?: string;
  };

  const data: Record<string, unknown> = {};
  const setStr = (k: keyof typeof body) => {
    if (body[k] === undefined) return;
    const v = body[k];
    data[k as string] = typeof v === "string" ? (v.trim() || null) : v;
  };
  setStr("name");
  setStr("entityName");
  setStr("description");
  setStr("funnelUrl");
  setStr("websiteUrl");
  setStr("service");
  setStr("niche");
  if (body.coverColor) data.coverColor = body.coverColor;
  if (body.status) data.status = body.status;

  if (data.name === null) return NextResponse.json({ error: "Name cannot be empty" }, { status: 400 });

  const campaign = await db.campaign.update({ where: { id }, data });
  return NextResponse.json({ ok: true, campaign });
}
