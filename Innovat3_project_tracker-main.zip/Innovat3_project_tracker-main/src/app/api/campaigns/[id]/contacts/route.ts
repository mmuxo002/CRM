import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { db } from "@/lib/db";

// Add a new contact to a campaign via a specific tag.
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!(await auth())) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  const { id } = await params;
  const { name, email, phone, status, tagId } = await req.json() as { name?: string; email?: string; phone?: string; status?: string; tagId?: string };
  if (!name?.trim()) return NextResponse.json({ error: "Name required" }, { status: 400 });
  if (!tagId) return NextResponse.json({ error: "Tag required" }, { status: 400 });

  const tag = await db.campaignTag.findUnique({ where: { id: tagId } });
  if (!tag || tag.campaignId !== id) return NextResponse.json({ error: "Invalid tag for campaign" }, { status: 400 });

  const contact = await db.contact.create({
    data: {
      name: name.trim(),
      email: email?.trim() || null,
      phone: phone?.trim() || null,
      status: (status === "CLIENT" || status === "PROSPECT") ? status : "LEAD",
      campaignTags: { connect: [{ id: tagId }] },
    },
  });

  return NextResponse.json({ ok: true, contact });
}
