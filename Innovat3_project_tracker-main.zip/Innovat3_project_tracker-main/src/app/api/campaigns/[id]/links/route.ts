import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { db } from "@/lib/db";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!(await auth())) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  const { id } = await params;
  const { label, url, kind } = await req.json() as { label?: string; url?: string; kind?: string };
  if (!label?.trim() || !url?.trim()) return NextResponse.json({ error: "Label and URL required" }, { status: 400 });
  const link = await db.campaignLink.create({ data: { campaignId: id, label: label.trim(), url: url.trim(), kind: kind || "OTHER" } });
  return NextResponse.json({ ok: true, link });
}
