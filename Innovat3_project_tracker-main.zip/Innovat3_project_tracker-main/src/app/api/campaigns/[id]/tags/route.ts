import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { db } from "@/lib/db";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!(await auth())) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  const { id } = await params;
  const { label, color } = await req.json() as { label?: string; color?: string };
  if (!label?.trim()) return NextResponse.json({ error: "Label required" }, { status: 400 });
  const tag = await db.campaignTag.create({ data: { campaignId: id, label: label.trim(), color: color || "#ec4899" } });
  return NextResponse.json({ ok: true, tag });
}
