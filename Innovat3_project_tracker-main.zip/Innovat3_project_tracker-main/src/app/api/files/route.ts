import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";

export async function POST(req: Request) {
  const { user } = await requireSession();
  const { projectId, dealId, folderId, name, format, url, isLink } = await req.json();
  if (!name) return NextResponse.json({ error: "name required" }, { status: 400 });
  const file = await db.fileAsset.create({ data: {
    name, format: format || (isLink ? "LINK" : "PDF"), url: url || "#", isLink: !!isLink,
    folderId: folderId || null, projectId: projectId || null, dealId: dealId || null, uploadedBy: user.id,
  } });
  return NextResponse.json(file);
}

export async function DELETE(req: Request) {
  await requireSession();
  const { id } = await req.json();
  await db.fileAsset.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
