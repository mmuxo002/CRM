import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";
import { CRM_STAGES } from "@/lib/crm";

const VALID = new Set(CRM_STAGES.map((s) => s.id));

export async function POST(req: Request) {
  const { user } = await requireSession();
  if (user.role !== "CRM_DEV" && user.role !== "ADMIN") return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id, toColumn } = await req.json();
  if (!id || !VALID.has(toColumn)) return NextResponse.json({ error: "Invalid" }, { status: 400 });

  const project = await db.project.findUnique({ where: { id } });
  if (!project) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (project.teamId !== "CRM") return NextResponse.json({ error: "Not a CRM project" }, { status: 400 });

  const progressMap: Record<string, number> = { ONBOARDED: 10, SCOPING: 25, BUILDING: 55, REVIEW: 85, LIVE: 100 };
  const updated = await db.project.update({ where: { id }, data: { crmStage: toColumn, progress: progressMap[toColumn] ?? project.progress, stage: toColumn === "LIVE" ? "LIVE" : "CRM_DEV" } });
  await db.activity.create({ data: { kind: "SYSTEM", title: `Moved to ${toColumn}`, body: updated.name, teamId: "CRM", actorId: user.id, projectId: updated.id } });
  return NextResponse.json({ ok: true });
}
