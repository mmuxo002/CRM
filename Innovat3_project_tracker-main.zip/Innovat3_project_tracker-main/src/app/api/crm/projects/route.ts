import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";

export async function POST(req: Request) {
  const { user } = await requireSession();
  if (user.role !== "CRM_DEV" && user.role !== "ADMIN") return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const body = await req.json();
  const { companyName, contactName, companyEmail, companyPhone, companyWebsite, projectName, serviceType, description, dueDate, mrr, priority } = body;

  if (!companyName || !contactName || !companyEmail || !companyPhone || !serviceType) {
    return NextResponse.json({ error: "companyName, contactName, companyEmail, companyPhone, serviceType are required" }, { status: 400 });
  }

  const resolvedProjectName = projectName || `${companyName} · ${serviceType}`;

  const company = await db.company.create({
    data: { name: companyName, email: companyEmail || null, phone: companyPhone || null, website: companyWebsite || null },
  });

  await db.contact.create({
    data: {
      name: contactName,
      email: companyEmail || null,
      phone: companyPhone || null,
      isPrimary: true,
      status: "CLIENT",
      companyId: company.id,
    },
  });

  const project = await db.project.create({
    data: {
      name: resolvedProjectName,
      description: description || null,
      teamId: "CRM",
      stage: "CRM_DEV",
      crmStage: "ONBOARDED",
      priority: priority || "MEDIUM",
      serviceType,
      onboarded: true,
      mrr: Number(mrr || 0),
      progress: 10,
      dueDate: dueDate ? new Date(dueDate) : null,
      ownerId: user.id,
      companyId: company.id,
    },
  });

  await db.activity.create({ data: { kind: "SYSTEM", title: `Onboarded ${company.name}`, body: `${projectName} · ${serviceType}`, teamId: "CRM", actorId: user.id, projectId: project.id } });
  return NextResponse.json({ ok: true, id: project.id });
}
