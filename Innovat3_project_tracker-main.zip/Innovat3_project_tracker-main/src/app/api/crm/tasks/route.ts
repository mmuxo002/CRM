import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";

export async function POST(req: Request) {
  const { user } = await requireSession();
  if (user.role !== "CRM_DEV" && user.role !== "ADMIN") return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { projectId, title, description, assignedTo, dueDate } = await req.json();
  if (!projectId || !title) return NextResponse.json({ error: "projectId and title required" }, { status: 400 });

  const proj = await db.project.findUnique({ where: { id: projectId } });
  if (!proj || proj.teamId !== "CRM") return NextResponse.json({ error: "Invalid project" }, { status: 400 });

  const task = await db.task.create({ data: { title, description: description || null, projectId, teamId: "CRM", assignedTo: assignedTo || user.id, dueDate: dueDate ? new Date(dueDate) : null, status: "BACKLOG" } });
  return NextResponse.json({ ok: true, id: task.id });
}

export async function PATCH(req: Request) {
  const { user } = await requireSession();
  if (user.role !== "CRM_DEV" && user.role !== "ADMIN") return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { id, status } = await req.json();
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });

  const task = await db.task.findUnique({ where: { id } });
  if (!task || task.teamId !== "CRM") return NextResponse.json({ error: "Invalid" }, { status: 400 });

  await db.task.update({ where: { id }, data: { status: status || (task.status === "DONE" ? "IN_PROGRESS" : "DONE") } });
  return NextResponse.json({ ok: true });
}
