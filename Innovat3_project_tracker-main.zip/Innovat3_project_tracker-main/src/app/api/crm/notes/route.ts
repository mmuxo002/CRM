import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";

export async function POST(req: Request) {
  const { user } = await requireSession();
  const { projectId, body } = await req.json();
  if (!projectId || !body) return NextResponse.json({ error: "projectId and body required" }, { status: 400 });

  const proj = await db.project.findUnique({ where: { id: projectId } });
  if (!proj) return NextResponse.json({ error: "Invalid project" }, { status: 400 });

  const note = await db.comment.create({
    data: { projectId, authorId: user.id, body: body.trim() },
    include: { author: { select: { id: true, name: true, image: true } } },
  });
  await db.activity.create({ data: { kind: "NOTE", title: "Added note", body: body.slice(0, 140), teamId: proj.teamId, actorId: user.id, projectId } });
  return NextResponse.json({ ok: true, id: note.id, comment: note });
}
