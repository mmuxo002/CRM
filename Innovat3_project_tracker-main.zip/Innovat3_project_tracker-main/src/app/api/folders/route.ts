import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";

export async function POST(req: Request) {
  await requireSession();
  const { projectId, dealId, name, color } = await req.json();
  if (!name) return NextResponse.json({ error: "name required" }, { status: 400 });
  const folder = await db.folder.create({ data: { name, color: color || "#7c3aed", projectId: projectId || null, dealId: dealId || null } });
  return NextResponse.json(folder);
}
