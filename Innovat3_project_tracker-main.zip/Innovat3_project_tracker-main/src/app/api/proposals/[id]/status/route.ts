// Status polling for the rep-side UI while the pipeline runs.
// Returns just enough to render a progress bar + thumbnail.

import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";

export const runtime = "nodejs";

export async function GET(
  _req: Request,
  ctx: RouteContext<"/api/proposals/[id]/status">,
) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const { id } = await ctx.params;

  const proposal = await db.proposal.findUnique({
    where: { id },
    select: {
      id: true,
      token: true,
      status: true,
      stage: true,
      progress: true,
      errorMessage: true,
      mockupImageUrl: true,
      rend3rImageUrl: true,
      currentSiteUrl: true,
      sentAt: true,
      sentToEmail: true,
      firstViewedAt: true,
      lastViewedAt: true,
      viewCount: true,
      scheduledAt: true,
    },
  });

  if (!proposal) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  return NextResponse.json({ ok: true, proposal });
}
