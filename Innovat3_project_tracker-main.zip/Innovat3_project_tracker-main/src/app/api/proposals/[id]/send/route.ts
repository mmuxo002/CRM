// Send the proposal email via Resend.
// Body: { to?: string; customMessage?: string }
//   - to defaults to the lead's email
//   - customMessage is the rep-edited intro paragraph (optional)

import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";
import { sendProposalEmail } from "@/lib/proposal/email";
import type { ProposalJSON } from "@/lib/sales/proposal-schema";

export const runtime = "nodejs";

export async function POST(
  req: Request,
  ctx: RouteContext<"/api/proposals/[id]/send">,
) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const { id } = await ctx.params;

  const proposal = await db.proposal.findUnique({
    where: { id },
    include: { lead: true },
  });
  if (!proposal) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (proposal.status !== "ready" && proposal.status !== "sent" && proposal.status !== "viewed" && proposal.status !== "scheduled") {
    return NextResponse.json({ error: `Proposal is ${proposal.status} — wait until it's ready before sending.` }, { status: 409 });
  }
  if (!proposal.proposalJson) {
    return NextResponse.json({ error: "Proposal has no copy generated." }, { status: 409 });
  }

  const body = (await req.json().catch(() => ({}))) as {
    to?: string;
    customMessage?: string;
  };

  const to = body.to?.trim() || proposal.lead.email;
  if (!to) {
    return NextResponse.json({ error: "No recipient email." }, { status: 400 });
  }

  const proposalCopy = JSON.parse(proposal.proposalJson) as ProposalJSON;
  const baseUrl = process.env.NEXT_PUBLIC_APP_URL?.replace(/\/$/, "") || "http://localhost:3000";
  const proposalUrl = `${baseUrl}/p/${proposal.token}`;

  const result = await sendProposalEmail({
    to,
    fromName: user.name || "Your INNOVAT3 rep",
    fromEmail: process.env.RESEND_FROM_EMAIL || "",
    proposal: proposalCopy,
    proposalUrl,
    mockupImageUrl: proposal.mockupImageUrl,
    customMessage: body.customMessage,
  });

  if (!result.ok) {
    return NextResponse.json({ error: result.error }, { status: 502 });
  }

  await db.proposal.update({
    where: { id },
    data: {
      status: proposal.status === "ready" ? "sent" : proposal.status,
      sentAt: new Date(),
      sentToEmail: to,
      emailMessageId: result.messageId,
    },
  });

  return NextResponse.json({ ok: true, messageId: result.messageId });
}
