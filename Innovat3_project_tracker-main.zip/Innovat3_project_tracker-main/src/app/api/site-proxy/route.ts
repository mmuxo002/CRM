import { NextRequest, NextResponse } from "next/server";
import { requireSession } from "@/lib/rbac";

export const dynamic = "force-dynamic";

/**
 * Proxies an external website so it can render inside an iframe.
 * Strips X-Frame-Options / CSP frame-ancestors that would otherwise block it,
 * and injects a <base> tag so relative assets still resolve to the original host.
 */
export async function GET(request: NextRequest) {
  await requireSession();

  const url = request.nextUrl.searchParams.get("url");
  if (!url) {
    return NextResponse.json({ error: "Missing url parameter" }, { status: 400 });
  }

  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    return NextResponse.json({ error: "Invalid url" }, { status: 400 });
  }

  // Only allow http/https
  if (!["http:", "https:"].includes(parsed.protocol)) {
    return NextResponse.json({ error: "Invalid protocol" }, { status: 400 });
  }

  try {
    const upstream = await fetch(url, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
      },
      redirect: "follow",
      signal: AbortSignal.timeout(10_000),
    });

    const contentType = upstream.headers.get("content-type") || "text/html";

    // For non-HTML resources just stream them through
    if (!contentType.includes("text/html")) {
      const body = await upstream.arrayBuffer();
      return new NextResponse(body, {
        status: upstream.status,
        headers: { "Content-Type": contentType, "Cache-Control": "public, max-age=300" },
      });
    }

    let html = await upstream.text();

    // Inject a <base> tag so relative URLs (CSS, images, JS) resolve to the original origin.
    const baseHref = parsed.origin + "/";
    if (!/<base\s/i.test(html)) {
      html = html.replace(
        /(<head[^>]*>)/i,
        `$1<base href="${baseHref}">`
      );
    }

    return new NextResponse(html, {
      status: 200,
      headers: {
        "Content-Type": "text/html; charset=utf-8",
        "Cache-Control": "public, max-age=300",
        // Deliberately NOT forwarding X-Frame-Options or CSP from upstream
      },
    });
  } catch (err: any) {
    const message = err?.name === "TimeoutError" ? "Request timed out" : "Failed to fetch site";
    return NextResponse.json({ error: message }, { status: 502 });
  }
}
