import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  await requireSession();
  const { id } = await params;
  const body = await req.json();
  const data: Record<string, unknown> = {};
  for (const k of ["name", "industry", "website", "phone", "email", "headquarters", "address"] as const) {
    if (k in body) data[k] = body[k] || null;
  }
  if (data.name === null) delete data.name;
  await db.company.update({ where: { id }, data });
  return NextResponse.json({ ok: true });
}
