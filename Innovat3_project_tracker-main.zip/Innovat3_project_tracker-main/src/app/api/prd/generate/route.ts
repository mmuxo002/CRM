import { NextResponse } from "next/server";
import Anthropic from "@anthropic-ai/sdk";
import { requireSession } from "@/lib/rbac";

export const dynamic = "force-dynamic";

const SYSTEM_PROMPT = `You are a senior product manager writing a Product Requirements Document (PRD). Produce a clean, structured PRD in Markdown with these sections:

# <Project Name>
## Problem
## Goals
## Non-Goals
## Users & Personas
## Scope
## Functional Requirements
## Non-Functional Requirements
## Milestones
## Success Metrics
## Open Questions

Be concrete and concise. Use bullet points. No preamble, no trailing commentary — return only the Markdown document.`;

export async function POST(req: Request) {
  await requireSession();
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return NextResponse.json({ error: "ANTHROPIC_API_KEY not configured" }, { status: 500 });
  }
  const { input, projectName } = await req.json();
  if (!input || typeof input !== "string" || input.trim().length < 10) {
    return NextResponse.json({ error: "input must be at least 10 characters" }, { status: 400 });
  }

  const client = new Anthropic({ apiKey });

  const userPrompt = projectName
    ? `Project name: ${projectName}\n\nSource material:\n\n${input}`
    : `Source material:\n\n${input}`;

  const message = await client.messages.create({
    model: "claude-sonnet-4-6",
    max_tokens: 4096,
    system: SYSTEM_PROMPT,
    messages: [{ role: "user", content: userPrompt }],
  });

  const prd = message.content
    .filter((b): b is Anthropic.TextBlock => b.type === "text")
    .map((b) => b.text)
    .join("\n")
    .trim();

  return NextResponse.json({ prd });
}
