import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  await requireSession();
  const { id } = await params;
  const project = await db.project.findUnique({ where: { id }, select: { name: true, prd: true } });
  if (!project || !project.prd) {
    return new Response("PRD not found", { status: 404 });
  }
  const filename = `${project.name.replace(/[^a-z0-9]+/gi, "_")}_PRD.md`;
  return new Response(project.prd, {
    status: 200,
    headers: {
      "Content-Type": "text/markdown; charset=utf-8",
      "Content-Disposition": `inline; filename="${filename}"`,
    },
  });
}
