import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";
import { socialIntroPrompt, emailOutreachPrompt } from "@/lib/sales/ai-prompts";
import Anthropic from "@anthropic-ai/sdk";

const anthropic = process.env.ANTHROPIC_API_KEY
  ? new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })
  : null;

const SOCIAL_PLATFORMS = ["INSTAGRAM", "LINKEDIN", "FACEBOOK", "TWITTER", "SMS"] as const;

export async function POST(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN")
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { id } = await params;

  const project = await db.salesProject.findUnique({ where: { id } });
  if (!project) return NextResponse.json({ error: "Project not found" }, { status: 404 });

  const leads = await db.lead.findMany({
    where: { salesProjectId: id, qualified: true },
    include: { persona: true },
  });

  let messagesCreated = 0;
  let leadsProcessed = 0;

  for (const lead of leads) {
    // Delete existing outreach for re-generation
    await db.outreach.deleteMany({ where: { leadId: lead.id } });

    const painPoints = safeJsonParse(lead.persona?.painPoints, [
      "Limited online presence",
      "Difficulty attracting new customers",
    ]);
    const services = safeJsonParse(lead.recommendedServices, []).map((s: any) =>
      typeof s === "string" ? s : s.name
    );

    // Generate social intros for each platform
    for (const platform of SOCIAL_PLATFORMS) {
      let intro = "";
      let followUp = "";

      if (anthropic) {
        try {
          const response = await anthropic.messages.create({
            model: "claude-sonnet-4-5-20250514",
            max_tokens: 600,
            messages: [{
              role: "user",
              content: socialIntroPrompt(
                lead.name, project.niche, project.targetLocation,
                painPoints, services, platform
              ),
            }],
          });

          const text = response.content[0]?.type === "text" ? response.content[0].text : "";
          const jsonMatch = text.match(/\{[\s\S]*\}/);
          if (jsonMatch) {
            const data = JSON.parse(jsonMatch[0]);
            intro = data.intro || "";
            followUp = data.followUp || "";
          }
        } catch {
          intro = generateFallbackIntro(lead.name, platform, project.niche);
          followUp = generateFallbackFollowUp(lead.name, platform);
        }
      } else {
        intro = generateFallbackIntro(lead.name, platform, project.niche);
        followUp = generateFallbackFollowUp(lead.name, platform);
      }

      if (intro) {
        await db.outreach.create({
          data: { leadId: lead.id, platform, type: "INTRO", body: intro },
        });
        messagesCreated++;
      }

      if (followUp) {
        await db.outreach.create({
          data: { leadId: lead.id, platform, type: "FOLLOW_UP", body: followUp },
        });
        messagesCreated++;
      }
    }

    // Generate email outreach
    if (anthropic) {
      try {
        const topService = services[0] || "digital services";
        const response = await anthropic.messages.create({
          model: "claude-sonnet-4-5-20250514",
          max_tokens: 800,
          messages: [{
            role: "user",
            content: emailOutreachPrompt(
              lead.name, project.niche, project.targetLocation,
              lead.persona?.decisionMakerName || null,
              topService, painPoints
            ),
          }],
        });

        const text = response.content[0]?.type === "text" ? response.content[0].text : "";
        const jsonMatch = text.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          const data = JSON.parse(jsonMatch[0]);
          if (data.body) {
            await db.outreach.create({
              data: { leadId: lead.id, platform: "EMAIL", type: "INTRO", subject: data.subject, body: data.body },
            });
            messagesCreated++;
          }
          if (data.followUpBody) {
            await db.outreach.create({
              data: { leadId: lead.id, platform: "EMAIL", type: "FOLLOW_UP", subject: data.followUpSubject, body: data.followUpBody },
            });
            messagesCreated++;
          }
        }
      } catch {}
    }

    await db.lead.update({
      where: { id: lead.id },
      data: { pipelinePhase: Math.max(lead.pipelinePhase, 5) },
    });

    leadsProcessed++;
  }

  await db.salesProject.update({
    where: { id },
    data: { currentPhase: 6 },
  });

  return NextResponse.json({ ok: true, leadsProcessed, messagesCreated });
}

function generateFallbackIntro(name: string, platform: string, niche: string): string {
  const intros: Record<string, string> = {
    INSTAGRAM: `Hey! Just came across ${name} and love what you're doing in the ${niche} space. Your work is really impressive! Would love to connect.`,
    LINKEDIN: `Hi, I noticed ${name} while researching ${niche} businesses in the area. I'm impressed by what you've built and would love to connect professionally.`,
    FACEBOOK: `Hi there! I came across ${name} and wanted to reach out. Love what you're doing in the ${niche} space!`,
    TWITTER: `Just discovered ${name} — really impressed with your ${niche} business! Would love to connect.`,
    SMS: `Hi! I came across ${name} and was really impressed. Would love to chat about how we could help grow your business.`,
  };
  return intros[platform] || intros.LINKEDIN;
}

function generateFallbackFollowUp(name: string, platform: string): string {
  return `Hey, just following up on my earlier message about ${name}. We actually built a sample website for businesses like yours — completely free, no commitment. Would you be interested in taking a look?`;
}

function safeJsonParse(str: string | null | undefined, fallback: any) {
  if (!str) return fallback;
  try { return JSON.parse(str); } catch { return fallback; }
}
