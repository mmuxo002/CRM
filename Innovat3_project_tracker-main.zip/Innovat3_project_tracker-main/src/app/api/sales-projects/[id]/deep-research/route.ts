import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";
import { hasApiKey, textSearchPlace, getPlaceDetails } from "@/lib/sales/google-places";

const NEWLY_LICENSED_DAYS = 90;

/**
 * Deep-research worker for the DBPR_LICENSED path.
 *
 * Input: { leadIds: string[] } — leads selected on the AWAITING_DEEP_RESEARCH
 * screen. Cap is 100 (matches the kickoff cap).
 *
 * Per lead: Google Places text search (businessName + address) → place_id →
 * Place Details for website / phone / rating / reviews. Then qualification:
 *   - hasWebsite === false → auto-qualify (top of outreach queue)
 *   - licenseIssuedAt < 90d → flag newlyLicensed for the recently-verified script
 *
 * On the last lead in this batch, the project flips to ENRICHING (the existing
 * downstream pipeline picks it up from there).
 */
export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const { id } = await params;
  const project = await db.salesProject.findUnique({ where: { id } });
  if (!project) return NextResponse.json({ error: "Project not found" }, { status: 404 });

  if (!hasApiKey()) {
    return NextResponse.json(
      { error: "GOOGLE_PLACES_API_KEY missing — deep research requires the Places API." },
      { status: 500 }
    );
  }

  const body = await req.json().catch(() => ({}));
  const leadIds: unknown = body?.leadIds;
  if (!Array.isArray(leadIds) || leadIds.length === 0) {
    return NextResponse.json({ error: "leadIds (string[]) is required" }, { status: 400 });
  }
  const ids = leadIds.filter((x): x is string => typeof x === "string").slice(0, 100);
  if (ids.length === 0) {
    return NextResponse.json({ error: "leadIds must contain at least one string" }, { status: 400 });
  }

  // Fetch only leads that belong to this project. Anything else is silently dropped.
  const leads = await db.lead.findMany({
    where: { id: { in: ids }, salesProjectId: project.id },
    select: {
      id: true, name: true, address: true, phone: true,
      website: true, googlePlaceId: true,
      licenseIssuedAt: true,
    },
  });

  if (leads.length === 0) {
    return NextResponse.json({ error: "None of the selected leads belong to this project." }, { status: 404 });
  }

  // Mark project as enriching while the batch runs.
  await db.salesProject.update({
    where: { id: project.id },
    data: { status: "ENRICHING", currentPhase: 3 },
  });

  let processed = 0;
  let withWebsite = 0;
  let withoutWebsite = 0;
  let newlyLicensedCount = 0;
  let placesMisses = 0;

  const cutoff = new Date(Date.now() - NEWLY_LICENSED_DAYS * 86400000);

  for (const lead of leads) {
    const query = [lead.name, firstAddressLine(lead.address)].filter(Boolean).join(" ");
    let placeId: string | null = lead.googlePlaceId ?? null;

    if (!placeId && query) {
      placeId = await textSearchPlace(query);
    }

    let website: string | null = lead.website;
    let phone: string | null = lead.phone;
    let address: string | null = lead.address;
    let rating: number | null = null;
    let reviewCount: number | null = null;

    if (placeId) {
      const details = await getPlaceDetails(placeId);
      if (details) {
        website = details.website ?? website;
        phone = details.phone ?? phone;
        address = details.address || address;
        rating = details.rating;
        reviewCount = details.reviewCount;
      } else {
        placesMisses++;
      }
    } else {
      placesMisses++;
    }

    const hasWebsite = !!website;
    const newlyLicensed = !!(lead.licenseIssuedAt && lead.licenseIssuedAt > cutoff);

    if (hasWebsite) withWebsite++;
    else withoutWebsite++;
    if (newlyLicensed) newlyLicensedCount++;

    // Qualification rules:
    //   - no website → auto-qualify, big score boost (they need what we sell)
    //   - newly licensed → smaller boost + flag for the recently-verified script
    let qualificationScore = 0;
    const qualReasons: string[] = [];
    if (!hasWebsite) { qualificationScore += 40; qualReasons.push("no website"); }
    if (newlyLicensed) { qualificationScore += 25; qualReasons.push("licensed in last 90d"); }
    if (rating !== null && reviewCount !== null && reviewCount < 10) {
      qualificationScore += 10;
      qualReasons.push("thin Google review presence");
    }

    await db.lead.update({
      where: { id: lead.id },
      data: {
        website: website ?? undefined,
        phone: phone ?? undefined,
        address: address ?? undefined,
        googlePlaceId: placeId ?? undefined,
        googleRating: rating ?? undefined,
        googleReviewCount: reviewCount ?? undefined,
        newlyLicensed,
        qualified: !hasWebsite || newlyLicensed,
        qualificationScore,
        qualificationReason: qualReasons.length ? qualReasons.join("; ") : null,
        pipelinePhase: 3,
      },
    });

    processed++;
  }

  // Bump qualifiedCount + park project for the rep to take over outreach.
  const projectQualified = await db.lead.count({
    where: { salesProjectId: project.id, qualified: true },
  });
  await db.salesProject.update({
    where: { id: project.id },
    data: { qualifiedCount: projectQualified, status: "QUALIFYING", currentPhase: 5 },
  });

  return NextResponse.json({
    ok: true,
    processed,
    withWebsite,
    withoutWebsite,
    newlyLicensed: newlyLicensedCount,
    placesMisses,
    message:
      `Researched ${processed} lead${processed === 1 ? "" : "s"} · ` +
      `${withoutWebsite} no-website (auto-qualified) · ` +
      `${newlyLicensedCount} newly licensed · ` +
      `${placesMisses} Google Places miss${placesMisses === 1 ? "" : "es"}`,
  });
}

function firstAddressLine(addr: string | null | undefined): string {
  if (!addr) return "";
  return addr.split(/\s{2,}|,/)[0]?.trim() ?? "";
}
