import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";
import { qualifyLead } from "@/lib/sales/scoring";

export async function POST(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN")
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { id } = await params;

  const project = await db.salesProject.findUnique({ where: { id } });
  if (!project) return NextResponse.json({ error: "Project not found" }, { status: 404 });

  const leads = await db.lead.findMany({
    where: { salesProjectId: id },
    include: { persona: true },
  });

  let scored = 0;
  let qualifiedCount = 0;

  for (const lead of leads) {
    const result = qualifyLead(
      {
        website: lead.website,
        googleRating: lead.googleRating,
        googleReviewCount: lead.googleReviewCount,
        instagramHandle: lead.instagramHandle,
        linkedinUrl: lead.linkedinUrl,
        facebookUrl: lead.facebookUrl,
        email: lead.email,
        persona: lead.persona,
      },
      project.niche
    );

    await db.lead.update({
      where: { id: lead.id },
      data: {
        qualificationScore: result.score,
        qualified: result.qualified,
        qualificationReason: result.reason,
        recommendedServices: JSON.stringify(result.recommendedServices),
        pipelinePhase: Math.max(lead.pipelinePhase, 4),
      },
    });

    scored++;
    if (result.qualified) qualifiedCount++;
  }

  await db.salesProject.update({
    where: { id },
    data: {
      qualifiedCount,
      status: "GENERATING",
      currentPhase: 5,
    },
  });

  return NextResponse.json({ ok: true, scored, qualified: qualifiedCount });
}
