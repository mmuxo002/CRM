import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";
import { personaPrompt } from "@/lib/sales/ai-prompts";
import { qualifyLead } from "@/lib/sales/scoring";
import { lookupSunbiz, formatSunbizForPrompt } from "@/lib/sales/sunbiz";
import { lookupDbpr, formatDbprForPrompt } from "@/lib/sales/dbpr";
import Anthropic from "@anthropic-ai/sdk";

const anthropic = process.env.ANTHROPIC_API_KEY
  ? new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })
  : null;

// POST /api/sales-projects/[id]/research
// Body: { leadId?: string } — if provided, research single lead; otherwise batch all
export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN")
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { id } = await params;
  const body = await req.json().catch(() => ({}));
  const targetLeadId = body.leadId as string | undefined;

  const project = await db.salesProject.findUnique({ where: { id } });
  if (!project) return NextResponse.json({ error: "Project not found" }, { status: 404 });

  // Fetch either a single lead or all un-researched leads
  const leads = targetLeadId
    ? await db.lead.findMany({
        where: { id: targetLeadId, salesProjectId: id },
        include: { persona: true },
      })
    : await db.lead.findMany({
        where: { salesProjectId: id, pipelinePhase: { lt: 3 } },
        include: { persona: true },
      });

  let researched = 0;

  for (const lead of leads) {
    // Delete existing persona for re-research
    if (lead.persona) {
      await db.persona.delete({ where: { leadId: lead.id } });
    }

    let personaData: any = generateFallbackPersona(lead.name, project.niche, !!lead.website);

    // Public-record lookups — Sunbiz (FL corporate registry) + DBPR (FL professional
    // licenses). Both are best-effort; null on failure. Run in parallel to keep the
    // per-lead research latency manageable (Puppeteer-based DBPR adds ~3-5s).
    const [sunbizResult, dbprResult] = await Promise.all([
      lookupSunbiz(lead.name).catch(() => null),
      lookupDbpr(lead.name).catch(() => null),
    ]);

    const sunbizInfo = sunbizResult ? formatSunbizForPrompt(sunbizResult) : null;
    const dbprInfo = dbprResult ? formatDbprForPrompt(dbprResult) : null;

    if (anthropic) {
      try {
        const response = await anthropic.messages.create({
          model: "claude-sonnet-4-5-20250514",
          max_tokens: 3000,
          messages: [{
            role: "user",
            content: personaPrompt(
              lead.name, project.targetLocation, project.niche,
              lead.website, lead.googleRating, lead.googleReviewCount,
              !!(lead.email && lead.email !== ""),
              !!(lead.instagramHandle || lead.linkedinUrl),
              sunbizInfo,
              {
                instagram: lead.instagramHandle,
                linkedin: lead.linkedinUrl,
                facebook: lead.facebookUrl,
                twitter: lead.twitterHandle,
              },
              dbprInfo,
            ),
          }],
        });

        const text = response.content[0]?.type === "text" ? response.content[0].text : "";
        const jsonMatch = text.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          personaData = JSON.parse(jsonMatch[0]);
        }
      } catch {}
    }

    // If Sunbiz found officers but Claude didn't use them, inject directly
    if (sunbizResult?.officers?.length && !personaData.decisionMakerName) {
      const primary = sunbizResult.officers[0];
      personaData.decisionMakerName = primary.name;
      personaData.decisionMakerTitle = primary.title;
    }

    await db.persona.create({
      data: {
        leadId: lead.id,
        businessSummary: personaData.businessSummary || null,
        digitalPresence: personaData.digitalPresence ? JSON.stringify(personaData.digitalPresence) : null,
        decisionMakerName: personaData.decisionMakerName || null,
        decisionMakerTitle: personaData.decisionMakerTitle || null,
        decisionMakerStyle: personaData.decisionMakerStyle || null,
        painPoints: personaData.painPoints ? JSON.stringify(personaData.painPoints) : null,
        opportunities: personaData.opportunities ? JSON.stringify(personaData.opportunities) : null,
        challenges: personaData.challenges ? JSON.stringify(personaData.challenges) : null,
        competitors: personaData.competitors ? JSON.stringify(personaData.competitors) : null,
        toolsUsed: personaData.toolsUsed ? JSON.stringify(personaData.toolsUsed) : null,
        estimatedAge: personaData.estimatedAge || null,
        demographics: personaData.demographics || null,
        rawAnalysis: JSON.stringify(personaData),
      },
    });

    // Auto-qualify after research
    const freshLead = await db.lead.findUnique({
      where: { id: lead.id },
      include: { persona: true },
    });

    const result = qualifyLead(
      {
        website: lead.website,
        googleRating: lead.googleRating,
        googleReviewCount: lead.googleReviewCount,
        instagramHandle: lead.instagramHandle,
        linkedinUrl: lead.linkedinUrl,
        facebookUrl: lead.facebookUrl,
        email: lead.email,
        persona: freshLead?.persona,
      },
      project.niche
    );

    await db.lead.update({
      where: { id: lead.id },
      data: {
        pipelinePhase: 4, // researched + qualified
        qualificationScore: result.score,
        qualified: result.qualified,
        qualificationReason: result.reason,
        recommendedServices: JSON.stringify(result.recommendedServices),
      },
    });

    researched++;
  }

  return NextResponse.json({ ok: true, researched });
}

function generateFallbackPersona(businessName: string, niche: string, hasWebsite: boolean) {
  return {
    businessSummary: `${businessName} is a local ${niche} business serving the surrounding community.`,
    digitalPresence: {
      hasWebsite,
      websiteQuality: hasWebsite ? "basic" : "none",
      hasOnlineBooking: false,
      hasCallHandling: false,
      hasGoogleBusiness: true,
      socialMedia: { facebook: false, instagram: false, linkedin: false },
      seoPresence: "weak",
    },
    decisionMakerTitle: "Owner/Operator",
    decisionMakerStyle: "relationship-focused",
    painPoints: [
      hasWebsite ? "Website exists but lacks online booking" : "No website — losing online visibility",
      "No AI call handling — missing calls from potential customers",
      "Limited online visibility and local SEO",
      "No automated lead follow-up system",
      "Competing with larger, well-funded competitors",
    ],
    opportunities: [
      hasWebsite ? "Add appointment system to existing website" : "Build professional website",
      "Implement Voice AI Agent for 24/7 call handling",
      "Set up automated lead qualification outreach",
      "Leverage local SEO for visibility",
      "Build customer review reputation",
    ],
    challenges: [
      "Budget constraints for marketing",
      "Lack of digital expertise",
      "Time management between service delivery and business growth",
    ],
    toolsUsed: ["Phone/text for appointments", "Cash register or basic POS", "Paper records or spreadsheets"],
    estimatedAge: "3-5 years",
    demographics: "Local community residents within 5-10 mile radius",
  };
}
