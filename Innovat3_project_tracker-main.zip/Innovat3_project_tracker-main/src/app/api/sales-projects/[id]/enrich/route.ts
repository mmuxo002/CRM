import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";
import { scrapeWebsite, guessInstagramHandle } from "@/lib/sales/enrichment";
import { enrichmentPrompt } from "@/lib/sales/ai-prompts";
import Anthropic from "@anthropic-ai/sdk";

const anthropic = process.env.ANTHROPIC_API_KEY
  ? new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })
  : null;

export async function POST(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN")
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { id } = await params;

  const project = await db.salesProject.findUnique({ where: { id } });
  if (!project) return NextResponse.json({ error: "Project not found" }, { status: 404 });

  const leads = await db.lead.findMany({
    where: { salesProjectId: id, pipelinePhase: { lt: 2 } },
  });

  let emailsFound = 0;
  let socialsFound = 0;

  for (const lead of leads) {
    let email = lead.email || "";
    let linkedinUrl = lead.linkedinUrl || null;
    let instagramHandle = lead.instagramHandle || null;
    let facebookUrl = lead.facebookUrl || null;
    let twitterHandle = lead.twitterHandle || null;

    // Strategy A: Website scraping
    if (lead.website) {
      const scraped = await scrapeWebsite(lead.website);
      if (scraped.emails.length > 0 && !email) email = scraped.emails[0];
      if (scraped.linkedinUrls.length > 0 && !linkedinUrl) linkedinUrl = scraped.linkedinUrls[0];
      if (scraped.instagramHandles.length > 0 && !instagramHandle) instagramHandle = scraped.instagramHandles[0];
      if (scraped.facebookUrls.length > 0 && !facebookUrl) facebookUrl = scraped.facebookUrls[0];
      if (scraped.twitterHandles.length > 0 && !twitterHandle) twitterHandle = scraped.twitterHandles[0];
    }

    // Strategy B: AI-powered discovery for missing fields
    if (anthropic && (!email || !instagramHandle || !linkedinUrl)) {
      try {
        const response = await anthropic.messages.create({
          model: "claude-sonnet-4-5-20250514",
          max_tokens: 300,
          messages: [{
            role: "user",
            content: enrichmentPrompt(lead.name, project.targetLocation, project.niche),
          }],
        });

        const text = response.content[0]?.type === "text" ? response.content[0].text : "";
        const jsonMatch = text.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          const data = JSON.parse(jsonMatch[0]);
          if (!email && data.email) email = data.email;
          if (!instagramHandle && data.instagram) instagramHandle = data.instagram;
          if (!linkedinUrl && data.linkedin) linkedinUrl = data.linkedin;
        }
      } catch {
        // AI enrichment failed — continue with what we have
      }
    }

    // Strategy C: Pattern-based Instagram guess
    if (!instagramHandle) {
      instagramHandle = guessInstagramHandle(lead.name, project.targetLocation);
    }

    // Track stats
    if (email && email !== lead.email) emailsFound++;
    if (instagramHandle || linkedinUrl || facebookUrl) socialsFound++;

    // Update lead
    await db.lead.update({
      where: { id: lead.id },
      data: {
        email: email || "",
        linkedinUrl,
        instagramHandle,
        facebookUrl,
        twitterHandle,
        pipelinePhase: 2,
      },
    });
  }

  await db.salesProject.update({
    where: { id },
    data: { status: "RESEARCHING", currentPhase: 3 },
  });

  return NextResponse.json({
    ok: true,
    enriched: leads.length,
    emailsFound,
    socialsFound,
  });
}
