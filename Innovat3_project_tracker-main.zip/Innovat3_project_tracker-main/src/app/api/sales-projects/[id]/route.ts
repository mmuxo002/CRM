import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";
import { releaseClaim } from "@/lib/sales/claim-pool";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN")
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { id } = await params;

  const project = await db.salesProject.findUnique({
    where: { id },
    include: {
      creator: { select: { id: true, name: true, email: true } },
      leads: {
        orderBy: { qualificationScore: "desc" },
        include: {
          persona: true,
          preCallBrief: { select: { id: true } },
          _count: { select: { outreaches: true } },
        },
      },
    },
  });

  if (!project) return NextResponse.json({ error: "Not found" }, { status: 404 });

  // Compute phase stats
  const stats = {
    total: project.leads.length,
    discovered: project.leads.filter((l) => l.pipelinePhase >= 1).length,
    enriched: project.leads.filter((l) => l.pipelinePhase >= 2).length,
    researched: project.leads.filter((l) => l.pipelinePhase >= 3).length,
    qualified: project.leads.filter((l) => l.qualified).length,
    withOutreach: project.leads.filter((l) => l._count.outreaches > 0).length,
    withBrief: project.leads.filter((l) => l.preCallBrief).length,
    avgScore:
      project.leads.length > 0
        ? Math.round(
            project.leads.reduce((sum, l) => sum + l.qualificationScore, 0) /
              project.leads.length
          )
        : 0,
  };

  return NextResponse.json({ ...project, stats });
}

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN")
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { id } = await params;
  const body = await req.json();

  const allowed: Record<string, unknown> = {};
  if (body.name !== undefined) allowed.name = body.name;
  if (body.status !== undefined) allowed.status = body.status;
  if (body.currentPhase !== undefined) allowed.currentPhase = body.currentPhase;

  const project = await db.salesProject.update({
    where: { id },
    data: allowed,
  });

  return NextResponse.json({ ok: true, project });
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { user } = await requireSession();
  if (user.role !== "ADMIN")
    return NextResponse.json({ error: "Admin only" }, { status: 403 });

  const { id } = await params;

  // Release every active claim on this project — leads flip back to the open pool
  // with all their research preserved. Historical LeadClaim rows stay for the contact
  // timeline; their projectId becomes null via ON DELETE SET NULL, but
  // projectNameSnapshot keeps the name visible.
  const activeClaims = await db.leadClaim.findMany({
    where: { projectId: id, releasedAt: null },
    select: { id: true },
  });
  for (const claim of activeClaims) {
    await releaseClaim({ claimId: claim.id, reason: "PROJECT_DELETED" });
  }

  await db.salesProject.delete({ where: { id } });

  return NextResponse.json({ ok: true, releasedClaims: activeClaims.length });
}
