// Open-pool browse & claim.
//
// GET: lists Leads that (a) have no active claim and (b) match this project's
// niche + location. Matching is best-effort — niche is a case-insensitive
// equality check on the snapshotted Lead.niche; location matches if the
// project's ZIP or city appears in the lead's address/location string.
//
// POST { leadIds: string[] }: claims each listed lead for this project.
// Skips any that slipped back into an active claim since the GET.

import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";
import { claimLead, extractZip, hasActiveClaim } from "@/lib/sales/claim-pool";

function locationTokens(loc: string): string[] {
  const tokens: string[] = [];
  const zip = extractZip(loc);
  if (zip) tokens.push(zip);
  // Split on commas / slashes; keep first city-like token.
  for (const part of loc.split(/[,/]/)) {
    const trimmed = part.trim();
    if (!trimmed) continue;
    if (/^\d{5}$/.test(trimmed)) continue;
    tokens.push(trimmed);
  }
  return tokens.filter((t) => t.length >= 2);
}

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN")
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { id } = await params;
  const project = await db.salesProject.findUnique({ where: { id } });
  if (!project) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const tokens = locationTokens(project.targetLocation);

  const candidates = await db.lead.findMany({
    where: {
      salesProjectId: null,
      niche: { equals: project.niche },
      OR: tokens.length
        ? tokens.flatMap((t) => [
            { address: { contains: t } },
            { location: { contains: t } },
          ])
        : undefined,
    },
    select: {
      id: true, name: true, phone: true, email: true, website: true, address: true,
      location: true, niche: true, qualified: true, qualificationScore: true,
      pipelinePhase: true,
      claims: {
        orderBy: { claimedAt: "desc" },
        take: 1,
        select: {
          claimedAt: true, releasedAt: true, releaseReason: true,
          projectNameSnapshot: true, claimedByNameSnapshot: true,
        },
      },
      _count: { select: { outreaches: true } },
      preCallBrief: { select: { id: true } },
      persona: { select: { id: true } },
    },
    orderBy: [{ qualified: "desc" }, { qualificationScore: "desc" }],
    take: 200,
  });

  return NextResponse.json({ leads: candidates });
}

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN")
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { id } = await params;
  const project = await db.salesProject.findUnique({ where: { id } });
  if (!project) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const body = await req.json();
  const leadIds: string[] = Array.isArray(body?.leadIds) ? body.leadIds : [];
  if (leadIds.length === 0) return NextResponse.json({ error: "leadIds required" }, { status: 400 });

  let claimed = 0;
  let skipped = 0;

  for (const leadId of leadIds) {
    if (await hasActiveClaim(leadId)) { skipped++; continue; }
    try {
      await claimLead({
        leadId,
        projectId: project.id,
        projectName: project.name,
        userId: user.id,
        userName: user.name ?? null,
      });
      claimed++;
    } catch {
      skipped++;
    }
  }

  await db.salesProject.update({
    where: { id },
    data: { discoveredCount: { increment: claimed } },
  });

  return NextResponse.json({ ok: true, claimed, skipped });
}
