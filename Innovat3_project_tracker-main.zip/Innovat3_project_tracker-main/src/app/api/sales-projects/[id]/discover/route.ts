import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";
import { hasApiKey, geocodeLocation, searchNearby, getPlaceDetails, textSearchPlace } from "@/lib/sales/google-places";
import { getNicheMapping } from "@/lib/sales/niche-config";
import { scrapeWebsite, guessInstagramHandle } from "@/lib/sales/enrichment";
import { enrichmentPrompt } from "@/lib/sales/ai-prompts";
import { claimLead, findExistingLead, hasActiveClaim, extractZip } from "@/lib/sales/claim-pool";
import { queryDbprByLicenseType, DbprQueryError, type DbprLicensee } from "@/lib/sales/dbpr";
import { getDbprNicheConfig, resolveDbprCountyCode } from "@/lib/sales/dbpr-license-types";
import { detectFrequentNames, isFranchise } from "@/lib/sales/franchise-filter";
import Anthropic from "@anthropic-ai/sdk";

const anthropic = process.env.ANTHROPIC_API_KEY
  ? new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })
  : null;

type RawLead = {
  businessName: string;
  phone: string | null;
  website: string | null;
  address: string;
  googleRating: number | null;
  googleReviewCount: number | null;
  googlePlaceId: string;
  // When the lead came from DBPR, carry the raw licensee record so we can
  // store license details on the Lead and label its source correctly.
  dbpr?: DbprLicensee;
};

export async function POST(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN")
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { id } = await params;

  const project = await db.salesProject.findUnique({ where: { id } });
  if (!project) return NextResponse.json({ error: "Project not found" }, { status: 404 });

  // ─── Path A: explicit DBPR_LICENSED kickoff ─────────────────────────────────
  // The licensed path uses filters chosen at kickoff (board, license types,
  // county) to pull up to 100 actively-licensed businesses, then parks the
  // project in AWAITING_DEEP_RESEARCH so the rep can pick which leads to push
  // through the deep-research worker. No Google enrichment in this stage.
  if (project.source === "DBPR_LICENSED") {
    return runDbprLicensedDiscovery(project, user);
  }

  await db.salesProject.update({
    where: { id },
    data: { status: "DISCOVERING", currentPhase: 2 },
  });

  // Pull wider than targetLeadCount — many will be skipped because they're already
  // actively claimed elsewhere. 3x gives headroom; searchNearby auto-widens radius.
  const fetchTarget = project.targetLeadCount * 3;
  const nicheMapping = getNicheMapping(project.niche);

  const rawLeads: RawLead[] = [];
  let googleFailureReason: string | null = null;
  let dbprFailureReason: string | null = null;
  let dbprFilteredOut = 0;
  let dbprLicensedCount = 0;
  let source: "DBPR" | "Google Places" = "Google Places";

  if (!hasApiKey()) {
    await db.salesProject.update({ where: { id }, data: { status: "CREATED", currentPhase: 1 } });
    return NextResponse.json({
      error: "GOOGLE_PLACES_API_KEY missing from .env — real discovery requires a valid Google Places key.",
    }, { status: 500 });
  }

  // ─── DBPR-first branch (licensed trades: HVAC, Plumbing, Roofing, etc.) ─────
  // For niches that map to a DBPR board + license type, the authoritative
  // prospect list is the state's licensee roster — not Google Places.
  const dbprConfig = getDbprNicheConfig(project.niche);
  const dbprCountyCode = dbprConfig ? resolveDbprCountyCode(project.targetLocation) : null;

  if (dbprConfig && !dbprCountyCode) {
    dbprFailureReason = `Couldn't map "${project.targetLocation}" to a Florida county. Use a ZIP or include the county/city name (e.g. "Miami, FL 33175").`;
  }

  if (dbprConfig && dbprCountyCode) {
    source = "DBPR";
    try {
      const licensees: DbprLicensee[] = [];
      for (const typeCode of dbprConfig.licenseTypeCodes) {
        const batch = await queryDbprByLicenseType({
          boardCode: dbprConfig.boardCode,
          licenseTypeCode: typeCode,
          countyCode: dbprCountyCode,
          activeOnly: true,
          limit: fetchTarget,
        });
        licensees.push(...batch);
      }

      // Collapse duplicates across license types — same business may hold both
      // Certified and Registered licenses; keep the first seen.
      const seenNames = new Set<string>();
      const unique = licensees.filter((l) => {
        const key = l.businessName.toUpperCase();
        if (seenNames.has(key)) return false;
        seenNames.add(key);
        return true;
      });

      // Franchise / chain filter (name blocklist + >10 statewide duplicates).
      const frequentNames = detectFrequentNames(unique.map((l) => l.businessName));
      const survivors = unique.filter((l) => {
        if (isFranchise(l.businessName, frequentNames)) { dbprFilteredOut++; return false; }
        return true;
      });
      dbprLicensedCount = survivors.length;

      // Enrich each surviving licensee via Google Places (text search by name +
      // address). If Places misses, we still keep the lead — absence of Google
      // presence is itself a sales hook.
      for (const licensee of survivors) {
        if (rawLeads.length >= fetchTarget) break;
        const placesMatch = await findPlaceForLicensee(licensee);
        rawLeads.push({
          businessName: licensee.businessName,
          phone: placesMatch?.phone ?? null,
          website: placesMatch?.website ?? null,
          address: licensee.locationAddress ?? licensee.mainAddress ?? placesMatch?.address ?? "",
          googleRating: placesMatch?.rating ?? null,
          googleReviewCount: placesMatch?.reviewCount ?? null,
          googlePlaceId: placesMatch?.placeId ?? `dbpr:${licensee.licenseNumber}`,
          dbpr: licensee,
        });
      }

      if (rawLeads.length === 0) {
        dbprFailureReason = `DBPR returned 0 active licensees for "${project.niche}" in county ${dbprCountyCode} after franchise filter (${dbprFilteredOut} filtered).`;
      }
    } catch (err) {
      const stage = err instanceof DbprQueryError ? err.stage : "unknown";
      dbprFailureReason = `DBPR scrape failed (${stage}): ${err instanceof Error ? err.message : String(err)}`;
    }
  }

  // ─── Google-first branch (niches not gated by DBPR) ─────────────────────────
  if (rawLeads.length === 0 && !dbprConfig) {
    try {
      const geo = await geocodeLocation(project.targetLocation);
      if (!geo) {
        googleFailureReason = "Geocoding API rejected the request (enable Geocoding API in Google Cloud for this key's project).";
      } else {
        const places = await searchNearby(
          geo.lat, geo.lng,
          nicheMapping.keyword || project.niche,
          nicheMapping.placeType,
          fetchTarget
        );

        for (const place of places) {
          const details = await getPlaceDetails(place.placeId);
          if (details) {
            rawLeads.push({
              businessName: details.name,
              phone: details.phone,
              website: details.website,
              address: details.address,
              googleRating: details.rating,
              googleReviewCount: details.reviewCount,
              googlePlaceId: place.placeId,
            });
          }
        }

        if (rawLeads.length === 0) {
          googleFailureReason = `Google Places returned no ${nicheMapping.keyword || project.niche} results near ${project.targetLocation}. Widen location or try a different niche.`;
        }
      }
    } catch (err) {
      googleFailureReason = err instanceof Error ? err.message : String(err);
    }
  }

  // Hard-fail with a specific reason. No mock data, ever.
  if (rawLeads.length === 0) {
    await db.salesProject.update({ where: { id }, data: { status: "CREATED", currentPhase: 1 } });
    const reason = dbprFailureReason
      ?? googleFailureReason
      ?? "No leads discovered and no failure reason captured — this is a bug, check server logs.";
    return NextResponse.json({
      error: reason,
      source,
      dbprFailureReason,
      googleFailureReason,
    }, { status: 502 });
  }

  let newCount = 0;
  let reusedCount = 0;
  let skippedClaimed = 0;
  let emailsFound = 0;
  let socialsFound = 0;

  const projectZipGuess = extractZip(project.targetLocation);

  for (const raw of rawLeads) {
    // Stop once we've hit the project's target (new + reused both count).
    if (newCount + reusedCount >= project.targetLeadCount) break;

    const identity = {
      googlePlaceId: raw.googlePlaceId || null,
      phone: raw.phone,
      businessName: raw.businessName,
      zip: extractZip(raw.address) ?? projectZipGuess,
    };

    const existing = await findExistingLead(identity);

    // Path 1: existing lead, currently claimed by someone else — skip.
    if (existing && await hasActiveClaim(existing.id)) {
      skippedClaimed++;
      continue;
    }

    // Path 2: existing open-pool lead — reuse all prior research.
    if (existing) {
      try {
        await claimLead({
          leadId: existing.id,
          projectId: project.id,
          projectName: project.name,
          userId: user.id,
          userName: user.name ?? null,
        });
        reusedCount++;
      } catch {
        // Race: someone claimed it between findExistingLead and claimLead.
        skippedClaimed++;
      }
      continue;
    }

    // Path 3: brand-new lead — discover + enrich + claim.
    const enriched = await enrich(raw, project.targetLocation, project.niche);
    if (enriched.email) emailsFound++;
    if (enriched.instagramHandle || enriched.linkedinUrl || enriched.facebookUrl) socialsFound++;

    // DBPR-sourced leads carry licensing context that belongs in the summary
    // so research + persona generation can cite it.
    const leadSource = raw.dbpr ? "DBPR" : "Google Places";
    const summary = raw.dbpr
      ? `[DBPR #${raw.dbpr.licenseNumber} · ${raw.dbpr.licenseType} · ${raw.dbpr.status}${raw.dbpr.expirationDate ? ` — expires ${raw.dbpr.expirationDate}` : ""}]`
      : null;

    try {
      const lead = await db.lead.create({
        data: {
          name: raw.businessName,
          email: enriched.email || "",
          phone: raw.phone || null,
          website: raw.website,
          address: raw.address,
          location: project.targetLocation,
          niche: project.niche,
          googlePlaceId: raw.googlePlaceId.startsWith("dbpr:") ? null : raw.googlePlaceId,
          googleRating: raw.googleRating,
          googleReviewCount: raw.googleReviewCount,
          linkedinUrl: enriched.linkedinUrl,
          instagramHandle: enriched.instagramHandle,
          facebookUrl: enriched.facebookUrl,
          twitterHandle: enriched.twitterHandle,
          summary,
          status: "NEW",
          source: leadSource,
          salesProjectId: project.id,
          assignedTo: user.id,
          pipelinePhase: 2,
        },
        select: { id: true },
      });
      await db.leadClaim.create({
        data: {
          leadId: lead.id,
          projectId: project.id,
          projectNameSnapshot: project.name,
          claimedByUserId: user.id,
          claimedByNameSnapshot: user.name ?? null,
        },
      });
      newCount++;
    } catch {
      // Likely a unique-constraint race on googlePlaceId — another agent created it.
      skippedClaimed++;
    }
  }

  await db.salesProject.update({
    where: { id },
    data: {
      discoveredCount: newCount + reusedCount,
      status: "COMPLETE",
      currentPhase: 2,
    },
  });

  const totalFetched = rawLeads.length;
  const shortfall = project.targetLeadCount - (newCount + reusedCount);

  return NextResponse.json({
    ok: true,
    discovered: newCount + reusedCount,
    newLeads: newCount,
    reusedFromPool: reusedCount,
    skippedActivelyClaimed: skippedClaimed,
    emailsFound,
    socialsFound,
    source,
    dbprLicensedCount,
    dbprFilteredOut,
    message: buildMessage({
      source,
      newCount,
      reusedCount,
      skippedClaimed,
      shortfall,
      totalFetched,
      emailsFound,
      socialsFound,
      dbprLicensedCount,
      dbprFilteredOut,
    }),
  });
}

// ─── DBPR_LICENSED kickoff handler ─────────────────────────────────────────
// Pulls up to 100 actively-licensed businesses for the project's filters,
// stamps each one as a Lead with license context, and parks the project in
// AWAITING_DEEP_RESEARCH. Google Places enrichment happens later when the rep
// hits "Send to Deep Research" on selected leads.
async function runDbprLicensedDiscovery(
  project: { id: string; name: string; niche: string; targetLocation: string; dbprFilters: unknown },
  user: { id: string; name?: string | null }
) {
  const filters = project.dbprFilters as null | {
    boardCode?: string;
    licenseTypeCodes?: string[];
    countyCode?: string;
    activeOnly?: boolean;
  };
  if (!filters || !filters.boardCode || !Array.isArray(filters.licenseTypeCodes) || !filters.countyCode) {
    return NextResponse.json({ error: "Project is missing dbprFilters — recreate the kickoff." }, { status: 400 });
  }

  await db.salesProject.update({
    where: { id: project.id },
    data: { status: "DISCOVERING", currentPhase: 2 },
  });

  const activeOnly = filters.activeOnly ?? true;
  const limit = 100;

  const licensees: DbprLicensee[] = [];
  let dbprFailureReason: string | null = null;
  try {
    for (const typeCode of filters.licenseTypeCodes) {
      if (licensees.length >= limit) break;
      const remaining = limit - licensees.length;
      const batch = await queryDbprByLicenseType({
        boardCode: filters.boardCode,
        licenseTypeCode: typeCode,
        countyCode: filters.countyCode,
        activeOnly,
        limit: remaining,
        fetchIssueDate: true,
      });
      licensees.push(...batch);
    }
  } catch (err) {
    const stage = err instanceof DbprQueryError ? err.stage : "unknown";
    dbprFailureReason = `DBPR scrape failed (${stage}): ${err instanceof Error ? err.message : String(err)}`;
  }

  if (licensees.length === 0) {
    await db.salesProject.update({ where: { id: project.id }, data: { status: "CREATED", currentPhase: 1 } });
    return NextResponse.json({
      error: dbprFailureReason ?? `DBPR returned 0 licensees for the selected filters.`,
    }, { status: 502 });
  }

  // Collapse duplicates across license types — same business may hold both
  // Certified and Registered; keep the first seen.
  const seen = new Set<string>();
  const unique = licensees.filter((l) => {
    const key = l.businessName.toUpperCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  // Franchise filter (name blocklist + cluster detection).
  const frequentNames = detectFrequentNames(unique.map((l) => l.businessName));
  let filteredOut = 0;
  const survivors = unique.filter((l) => {
    if (isFranchise(l.businessName, frequentNames)) { filteredOut++; return false; }
    return true;
  });

  let newCount = 0;
  let reusedCount = 0;
  let skippedClaimed = 0;

  for (const lic of survivors) {
    const identity = {
      googlePlaceId: null,
      phone: null,
      businessName: lic.businessName,
      zip: extractZip(lic.locationAddress ?? lic.mainAddress ?? ""),
    };

    const existing = await findExistingLead(identity);

    if (existing && await hasActiveClaim(existing.id)) {
      skippedClaimed++;
      continue;
    }

    const summary =
      `[DBPR #${lic.licenseNumber} · ${lic.licenseType} · ${lic.status}` +
      (lic.expirationDate ? ` — expires ${lic.expirationDate}` : "") +
      (lic.originalLicenseDate ? ` — issued ${lic.originalLicenseDate}` : "") +
      `]`;

    const issuedAt = parseDbprDate(lic.originalLicenseDate);

    if (existing) {
      try {
        await claimLead({
          leadId: existing.id,
          projectId: project.id,
          projectName: project.name,
          userId: user.id,
          userName: user.name ?? null,
        });
        // Update license fields if the existing lead doesn't have them yet.
        await db.lead.update({
          where: { id: existing.id },
          data: {
            niche: project.niche,
            summary,
            licenseIssuedAt: issuedAt ?? undefined,
            assignedTo: user.id,
            pipelinePhase: 2,
            source: "DBPR",
          },
        });
        reusedCount++;
      } catch {
        skippedClaimed++;
      }
      continue;
    }

    try {
      const lead = await db.lead.create({
        data: {
          name: lic.businessName,
          email: "",
          phone: null,
          website: null,
          address: lic.locationAddress ?? lic.mainAddress ?? "",
          location: project.targetLocation,
          niche: project.niche,
          summary,
          licenseIssuedAt: issuedAt ?? undefined,
          status: "NEW",
          source: "DBPR",
          salesProjectId: project.id,
          assignedTo: user.id,
          pipelinePhase: 2,
        },
        select: { id: true },
      });
      await db.leadClaim.create({
        data: {
          leadId: lead.id,
          projectId: project.id,
          projectNameSnapshot: project.name,
          claimedByUserId: user.id,
          claimedByNameSnapshot: user.name ?? null,
        },
      });
      newCount++;
    } catch {
      skippedClaimed++;
    }
  }

  await db.salesProject.update({
    where: { id: project.id },
    data: {
      discoveredCount: newCount + reusedCount,
      status: "AWAITING_DEEP_RESEARCH",
      currentPhase: 2,
    },
  });

  return NextResponse.json({
    ok: true,
    discovered: newCount + reusedCount,
    newLeads: newCount,
    reusedFromPool: reusedCount,
    skippedActivelyClaimed: skippedClaimed,
    dbprLicensedCount: survivors.length,
    dbprFilteredOut: filteredOut,
    awaitingDeepResearch: true,
    message: `[DBPR-licensed] ${newCount + reusedCount} licensee${newCount + reusedCount === 1 ? "" : "s"} ready` +
      (filteredOut ? ` (${filteredOut} franchise${filteredOut === 1 ? "" : "s"} filtered)` : "") +
      ` — pick which ones to send to deep research.`,
  });
}

// Parse DBPR's mm/dd/yyyy strings into a Date. Returns null on bad input.
function parseDbprDate(s: string | null | undefined): Date | null {
  if (!s) return null;
  const m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (!m) return null;
  const [, mm, dd, yyyy] = m;
  const d = new Date(Date.UTC(Number(yyyy), Number(mm) - 1, Number(dd)));
  return isNaN(d.getTime()) ? null : d;
}

// Google Places text search by business name + first line of street address.
// Returns the top match (phone, website, rating, address, placeId) or null.
async function findPlaceForLicensee(licensee: DbprLicensee): Promise<{
  placeId: string; phone: string | null; website: string | null;
  address: string; rating: number | null; reviewCount: number | null;
} | null> {
  if (!hasApiKey()) return null;
  const addr = licensee.locationAddress ?? licensee.mainAddress ?? "";
  const firstLine = addr.split(/\s{2,}|,/)[0]?.trim() ?? "";
  const query = [licensee.businessName, firstLine].filter(Boolean).join(" ");
  if (!query) return null;
  const placeId = await textSearchPlace(query);
  if (!placeId) return null;
  const details = await getPlaceDetails(placeId);
  if (!details) return null;
  return {
    placeId,
    phone: details.phone,
    website: details.website,
    address: details.address,
    rating: details.rating,
    reviewCount: details.reviewCount,
  };
}

async function enrich(raw: RawLead, location: string, niche: string) {
  let email = "";
  let linkedinUrl: string | null = null;
  let instagramHandle: string | null = null;
  let facebookUrl: string | null = null;
  let twitterHandle: string | null = null;

  if (raw.website) {
    try {
      const scraped = await scrapeWebsite(raw.website);
      if (scraped.emails.length > 0) email = scraped.emails[0];
      if (scraped.linkedinUrls.length > 0) linkedinUrl = scraped.linkedinUrls[0];
      if (scraped.instagramHandles.length > 0) instagramHandle = scraped.instagramHandles[0];
      if (scraped.facebookUrls.length > 0) facebookUrl = scraped.facebookUrls[0];
      if (scraped.twitterHandles.length > 0) twitterHandle = scraped.twitterHandles[0];
    } catch {}
  }

  if (anthropic && (!email || !instagramHandle || !linkedinUrl)) {
    try {
      const response = await anthropic.messages.create({
        model: "claude-sonnet-4-5-20250514",
        max_tokens: 300,
        messages: [{ role: "user", content: enrichmentPrompt(raw.businessName, location, niche) }],
      });
      const text = response.content[0]?.type === "text" ? response.content[0].text : "";
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const data = JSON.parse(jsonMatch[0]);
        if (!email && data.email) email = data.email;
        if (!instagramHandle && data.instagram) instagramHandle = data.instagram;
        if (!linkedinUrl && data.linkedin) linkedinUrl = data.linkedin;
      }
    } catch {}
  }

  if (!instagramHandle) {
    instagramHandle = guessInstagramHandle(raw.businessName, location);
  }

  return { email, linkedinUrl, instagramHandle, facebookUrl, twitterHandle };
}

function buildMessage(s: {
  source: "DBPR" | "Google Places";
  newCount: number; reusedCount: number; skippedClaimed: number;
  shortfall: number; totalFetched: number; emailsFound: number; socialsFound: number;
  dbprLicensedCount: number; dbprFilteredOut: number;
}): string {
  const total = s.newCount + s.reusedCount;
  const parts: string[] = [];
  parts.push(`${total} lead${total === 1 ? "" : "s"} in your project`);
  if (s.newCount) parts.push(`${s.newCount} new`);
  if (s.reusedCount) parts.push(`${s.reusedCount} reused from open pool`);
  if (s.skippedClaimed) parts.push(`${s.skippedClaimed} skipped (claimed by another agent)`);
  if (s.source === "DBPR") {
    parts.push(`${s.dbprLicensedCount} active licenses`);
    if (s.dbprFilteredOut > 0) parts.push(`${s.dbprFilteredOut} franchises filtered`);
  }
  parts.push(`${s.emailsFound} emails`);
  parts.push(`${s.socialsFound} social profiles`);
  let msg = parts.join(" · ");
  if (s.shortfall > 0) msg += ` — ${s.shortfall} short of target; widen location or try again later.`;
  if (s.source === "DBPR") msg = `[DBPR-first] ${msg}`;
  return msg;
}
