import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";
import { preCallBriefPrompt } from "@/lib/sales/ai-prompts";
import Anthropic from "@anthropic-ai/sdk";

const anthropic = process.env.ANTHROPIC_API_KEY
  ? new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })
  : null;

export async function POST(
  _req: Request,
  { params }: { params: Promise<{ id: string; leadId: string }> }
) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN")
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { id, leadId } = await params;

  const lead = await db.lead.findFirst({
    where: { id: leadId, salesProjectId: id },
    include: { persona: true },
  });
  if (!lead) return NextResponse.json({ error: "Lead not found" }, { status: 404 });

  const project = await db.salesProject.findUnique({ where: { id } });
  if (!project) return NextResponse.json({ error: "Project not found" }, { status: 404 });

  const recommendedServices = safeJsonParse(lead.recommendedServices, []);
  const persona = lead.persona
    ? {
        businessSummary: lead.persona.businessSummary,
        decisionMakerTitle: lead.persona.decisionMakerTitle,
        decisionMakerStyle: lead.persona.decisionMakerStyle,
        painPoints: safeJsonParse(lead.persona.painPoints, []),
      }
    : null;

  let briefData: any = {
    headline: `${lead.name} — Score ${lead.qualificationScore}: Strong opportunity in ${project.niche}`,
    talkingPoints: [
      `Reference their ${project.niche} business specifically`,
      `Mention their location in ${project.targetLocation}`,
      "Lead with value — offer a free website preview",
      "Ask about their current digital marketing approach",
    ],
    openingLines: [
      `Hi, I've been looking at ${project.niche} businesses in ${project.targetLocation} and noticed ${lead.name} — I'd love to share some insights about what's working for similar businesses.`,
      `Hi, I'm reaching out because I noticed ${lead.name} could benefit from a stronger online presence. We've helped other ${project.niche} businesses significantly increase their visibility.`,
    ],
    qualificationQuestions: [
      "How are you currently handling online bookings/appointments?",
      "What's your biggest challenge with attracting new customers?",
      "Have you considered upgrading your online presence?",
    ],
  };

  if (anthropic && persona) {
    try {
      const response = await anthropic.messages.create({
        model: "claude-sonnet-4-5-20250514",
        max_tokens: 1000,
        messages: [{
          role: "user",
          content: preCallBriefPrompt(
            lead.name, project.niche, project.targetLocation,
            persona, lead.qualificationScore, recommendedServices
          ),
        }],
      });

      const text = response.content[0]?.type === "text" ? response.content[0].text : "";
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        briefData = { ...briefData, ...JSON.parse(jsonMatch[0]) };
      }
    } catch {}
  }

  // Upsert brief
  const existing = await db.preCallBrief.findUnique({ where: { leadId } });

  const briefRecord = existing
    ? await db.preCallBrief.update({
        where: { leadId },
        data: {
          headline: briefData.headline,
          talkingPoints: JSON.stringify(briefData.talkingPoints),
          openingLines: JSON.stringify(briefData.openingLines),
          qualificationQuestions: JSON.stringify(briefData.qualificationQuestions),
          recommendedServices: JSON.stringify(briefData.recommendedServices || recommendedServices),
        },
      })
    : await db.preCallBrief.create({
        data: {
          leadId,
          headline: briefData.headline,
          talkingPoints: JSON.stringify(briefData.talkingPoints),
          openingLines: JSON.stringify(briefData.openingLines),
          qualificationQuestions: JSON.stringify(briefData.qualificationQuestions),
          recommendedServices: JSON.stringify(briefData.recommendedServices || recommendedServices),
        },
      });

  await db.lead.update({
    where: { id: leadId },
    data: { pipelinePhase: Math.max(lead.pipelinePhase, 6) },
  });

  await db.salesProject.update({
    where: { id },
    data: { currentPhase: Math.max(project!.currentPhase, 7) },
  });

  return NextResponse.json({ ok: true, brief: briefRecord });
}

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string; leadId: string }> }
) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN")
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { leadId } = await params;

  const brief = await db.preCallBrief.findUnique({ where: { leadId } });
  if (!brief) return NextResponse.json({ error: "Brief not found" }, { status: 404 });

  return NextResponse.json(brief);
}

function safeJsonParse(str: string | null | undefined, fallback: any) {
  if (!str) return fallback;
  try { return JSON.parse(str); } catch { return fallback; }
}
