import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";
import { coachingPrompt } from "@/lib/sales/ai-prompts";
import { recordLeadActivity } from "@/lib/sales/claim-pool";
import Anthropic from "@anthropic-ai/sdk";

const anthropic = process.env.ANTHROPIC_API_KEY
  ? new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })
  : null;

export async function POST(
  _req: Request,
  { params }: { params: Promise<{ id: string; leadId: string }> }
) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN")
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { id, leadId } = await params;

  const lead = await db.lead.findFirst({
    where: { id: leadId, salesProjectId: id },
    include: { persona: true, preCallBrief: true },
  });
  if (!lead) return NextResponse.json({ error: "Lead not found" }, { status: 404 });

  const project = await db.salesProject.findUnique({ where: { id } });
  if (!project) return NextResponse.json({ error: "Project not found" }, { status: 404 });

  const recommendedServices = safeJsonParse(lead.recommendedServices, []);
  const persona = lead.persona
    ? {
        decisionMakerStyle: lead.persona.decisionMakerStyle,
        painPoints: safeJsonParse(lead.persona.painPoints, []),
      }
    : null;

  let coachingData: any = {
    callScript: generateFallbackScript(lead.name, project.niche, project.targetLocation),
    objectionHandlers: generateFallbackObjections(),
    pricingGuidance: generateFallbackPricing(project.niche),
    roiProjections: generateFallbackROI(project.niche),
  };

  if (anthropic && persona) {
    try {
      const response = await anthropic.messages.create({
        model: "claude-sonnet-4-5-20250514",
        max_tokens: 2000,
        messages: [{
          role: "user",
          content: coachingPrompt(
            lead.name, project.niche, persona,
            recommendedServices, lead.qualificationScore
          ),
        }],
      });

      const text = response.content[0]?.type === "text" ? response.content[0].text : "";
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        coachingData = { ...coachingData, ...parsed };
      }
    } catch {}
  }

  // Update the brief with coaching data
  if (lead.preCallBrief) {
    await db.preCallBrief.update({
      where: { leadId },
      data: {
        callScript: coachingData.callScript,
        objectionHandlers: coachingData.objectionHandlers,
        pricingGuidance: coachingData.pricingGuidance,
        roiProjections: coachingData.roiProjections,
      },
    });
  }

  await db.lead.update({
    where: { id: leadId },
    data: { pipelinePhase: Math.max(lead.pipelinePhase, 7) },
  });

  await db.salesProject.update({
    where: { id },
    data: { currentPhase: Math.max(project!.currentPhase, 8), status: "COMPLETE" },
  });

  return NextResponse.json({
    ...coachingData,
    callNotes: lead.preCallBrief?.callNotes || "",
    callOutcome: lead.preCallBrief?.callOutcome || "",
  });
}

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string; leadId: string }> }
) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN")
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { leadId } = await params;

  const brief = await db.preCallBrief.findUnique({ where: { leadId } });
  if (!brief) return NextResponse.json({ error: "Not found" }, { status: 404 });

  return NextResponse.json(brief);
}

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string; leadId: string }> }
) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN")
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { leadId } = await params;
  const body = await req.json();

  const data: Record<string, unknown> = {};
  if (body.callNotes !== undefined) data.callNotes = body.callNotes;
  if (body.callOutcome !== undefined) data.callOutcome = body.callOutcome;

  await db.preCallBrief.update({ where: { leadId }, data });
  await recordLeadActivity(leadId);

  return NextResponse.json({ ok: true });
}

function generateFallbackScript(name: string, niche: string, location: string): string {
  return `OPENING:\n"Hi, this is [Your Name] from INNOVAT3. I was doing some research on ${niche} businesses in ${location} and came across ${name}. Do you have just a quick minute?"\n\nDISCOVERY:\n- "How are you currently handling your online presence?"\n- "What's your biggest challenge when it comes to attracting new customers?"\n- "Have you thought about how a professional website could help?"\n\nVALUE PRESENTATION:\n"We actually specialize in helping ${niche} businesses like yours. We've helped similar businesses increase their customer base by 30-50% with a professional online presence."\n\nCLOSING:\n"I'd love to show you a sample website we built specifically for a business like yours — completely free, no strings attached. Would you be open to a quick 15-minute call this week to walk through it?"`;
}

function generateFallbackObjections(): string {
  return `"WE ALREADY HAVE A WEBSITE":\n→ "That's great! We actually build on what you already have. Mind if I take a look and share some quick wins we've found for similar businesses?"\n\n"IT'S TOO EXPENSIVE":\n→ "I totally understand. That's exactly why we start with a free sample — so you can see the value before any commitment. Most of our clients find it pays for itself within the first month."\n\n"WE'RE TOO BUSY RIGHT NOW":\n→ "I completely get that — running a business is no joke. That's actually one of the main reasons our clients love working with us. We handle everything so you don't have to lift a finger."\n\n"I NEED TO THINK ABOUT IT":\n→ "Absolutely, take your time. Would it help if I sent over some case studies from similar businesses? That way you have something concrete to review."\n\n"SEND ME MORE INFORMATION":\n→ "Happy to! What's the best email? I'll also include the sample website we built — most people find that more helpful than a brochure."`;
}

function generateFallbackPricing(niche: string): string {
  return `PRICING APPROACH:\n\nAnchor High, Deliver Value:\n- Start by mentioning what competitors charge ($3,000-$10,000 for a website)\n- Then present your package as significantly more affordable\n- Emphasize monthly ROI vs. one-time cost\n\nSTARTER PACKAGE (~$500-1,500):\n- Professional website\n- Google Business optimization\n- Basic SEO setup\n\nGROWTH PACKAGE (~$1,500-3,000/mo):\n- Everything in Starter\n- Social media management\n- Review management\n- AI Voice Receptionist\n\nPREMIUM PACKAGE (~$3,000-5,000/mo):\n- Full digital transformation\n- All services included\n- Dedicated account manager\n- Monthly reporting\n\nALWAYS lead with the free sample website as the hook.`;
}

function generateFallbackROI(niche: string): string {
  return `ROI PROJECTIONS FOR ${niche.toUpperCase()}:\n\nWEBSITE + SEO:\n- Average new customer value: $200-500\n- Expected new customers/month from SEO: 5-15\n- Monthly revenue increase: $1,000-7,500\n- ROI: 3-5x within 3 months\n\nGOOGLE BUSINESS OPTIMIZATION:\n- Increased visibility in local search by 40-60%\n- Expected call increase: 20-30%\n- Cost: Included in package\n\nAI VOICE RECEPTIONIST:\n- Captures 100% of calls (vs. ~60% typical answer rate)\n- Each missed call = potential $200-500 lost\n- Saves 10+ hours/week of phone management\n\nSOCIAL MEDIA:\n- Brand awareness increase within 30 days\n- Customer engagement improvement: 2-3x\n- Long-term: organic lead generation channel`;
}

function safeJsonParse(str: string | null | undefined, fallback: any) {
  if (!str) return fallback;
  try { return JSON.parse(str); } catch { return fallback; }
}
