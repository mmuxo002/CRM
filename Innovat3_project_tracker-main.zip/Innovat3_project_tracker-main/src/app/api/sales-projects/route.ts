import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";

export async function GET() {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN")
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const projects = await db.salesProject.findMany({
    orderBy: { createdAt: "desc" },
    include: {
      creator: { select: { id: true, name: true, email: true } },
      _count: { select: { leads: true } },
    },
  });

  return NextResponse.json(projects);
}

export async function POST(req: Request) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN")
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const body = await req.json();
  const {
    source,            // "GOOGLE_GENERAL" | "DBPR_LICENSED" — defaults to general
    niche,
    targetLocation,
    targetLeadCount,
    dbprFilters,       // only set on DBPR_LICENSED path
    dbprNicheKey,      // DBPR-specific niche key (e.g. "hvac") — used by the discover route
                       // to resolve license-type codes via getDbprNicheConfig
  } = body;

  const resolvedSource: "GOOGLE_GENERAL" | "DBPR_LICENSED" =
    source === "DBPR_LICENSED" ? "DBPR_LICENSED" : "GOOGLE_GENERAL";

  if (!niche || !targetLocation || !targetLeadCount) {
    return NextResponse.json(
      { error: "niche, targetLocation, and targetLeadCount are required" },
      { status: 400 }
    );
  }

  if (resolvedSource === "DBPR_LICENSED") {
    if (!dbprFilters || typeof dbprFilters !== "object") {
      return NextResponse.json({ error: "dbprFilters is required for the licensed path" }, { status: 400 });
    }
    if (!dbprFilters.boardCode || !Array.isArray(dbprFilters.licenseTypeCodes) || dbprFilters.licenseTypeCodes.length === 0) {
      return NextResponse.json({ error: "dbprFilters.boardCode and licenseTypeCodes are required" }, { status: 400 });
    }
    if (!dbprFilters.countyCode) {
      return NextResponse.json({ error: "dbprFilters.countyCode is required" }, { status: 400 });
    }
  }

  // Licensed path is hard-capped at 100; Google path keeps the caller's count.
  const count =
    resolvedSource === "DBPR_LICENSED"
      ? 100
      : Math.min(Math.max(Number(targetLeadCount), 1), 300);

  const name = `${niche} · ${targetLocation}`;

  // Persist dbprNicheKey inside dbprFilters so the discover route can resolve
  // license-type codes from a single field on the project.
  const filtersToStore =
    resolvedSource === "DBPR_LICENSED"
      ? { ...dbprFilters, nicheKey: dbprNicheKey ?? null }
      : null;

  const project = await db.salesProject.create({
    data: {
      name,
      niche,
      targetLocation,
      targetLeadCount: count,
      source: resolvedSource,
      dbprFilters: filtersToStore ?? undefined,
      createdBy: user.id,
    },
  });

  return NextResponse.json({ ok: true, id: project.id });
}
