import { requireDepartment } from "@/lib/rbac";
import { db } from "@/lib/db";
import { NewCampaignButton } from "@/components/marketing/NewCampaignButton";
import { CampaignsExplorer, type CampaignRow } from "@/components/marketing/CampaignsExplorer";

export const dynamic = "force-dynamic";

export default async function CampaignsListPage() {
  await requireDepartment("marketing");

  const campaigns = await db.campaign.findMany({
    orderBy: { createdAt: "desc" },
    include: {
      tags: { include: { contacts: { select: { status: true } }, _count: { select: { contacts: true } } } },
      _count: { select: { links: true, files: true } },
    },
  });

  const rows: CampaignRow[] = campaigns.map((c) => {
    let leads = 0, prospects = 0, clients = 0;
    for (const t of c.tags) for (const ct of t.contacts) {
      if (ct.status === "CLIENT") clients++;
      else if (ct.status === "PROSPECT") prospects++;
      else leads++;
    }
    return {
      id: c.id, name: c.name, entityName: c.entityName, description: c.description,
      coverColor: c.coverColor, service: c.service, niche: c.niche, status: c.status,
      leads, prospects, clients, total: leads + prospects + clients,
      tagCount: c.tags.length, linkCount: c._count.links, fileCount: c._count.files,
      tags: c.tags.map((t) => ({ id: t.id, label: t.label, color: t.color, count: t._count.contacts })),
    };
  });

  return (
    <div className="animate-slide-up">
      <div className="row-between" style={{ marginBottom: "1.25rem" }}>
        <div>
          <h1 className="page-title" style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <span className="dept-dot" style={{ background: "#ec4899", width: 12, height: 12 }} />
            Marketing · Campaigns
          </h1>
          <p className="page-subtitle">Every campaign, asset, and conversion across your entity.</p>
        </div>
        <NewCampaignButton />
      </div>

      <CampaignsExplorer campaigns={rows} />
    </div>
  );
}
