import { requireDepartment } from "@/lib/rbac";
import { db } from "@/lib/db";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Globe, Target as TargetIcon, Users, TrendingUp, Building2 } from "lucide-react";
import { CampaignClient } from "@/components/marketing/CampaignClient";
import { CampaignDetailsEditor } from "@/components/marketing/CampaignDetailsEditor";

export const dynamic = "force-dynamic";

export default async function CampaignProfilePage({ params }: { params: Promise<{ id: string }> }) {
  await requireDepartment("marketing");
  const { id } = await params;

  const campaign = await db.campaign.findUnique({
    where: { id },
    include: {
      owner: true,
      links: { orderBy: { createdAt: "asc" } },
      files: { include: { uploader: true }, orderBy: { createdAt: "desc" } },
      tags: { include: { contacts: true } },
    },
  });
  if (!campaign) notFound();

  let leads = 0, prospects = 0, clients = 0;
  for (const t of campaign.tags) for (const c of t.contacts) {
    if (c.status === "CLIENT") clients++;
    else if (c.status === "PROSPECT") prospects++;
    else leads++;
  }
  const total = leads + prospects + clients;
  const conversion = total ? Math.round((clients / total) * 100) : 0;

  return (
    <div className="animate-slide-up">
      <div className="row-between" style={{ marginBottom: "1rem" }}>
        <div className="flex-gap" style={{ fontSize: "0.85rem", color: "var(--text-secondary)" }}>
          <Link href="/marketing/campaigns">Campaigns</Link>
          <span>/</span>
          <span style={{ color: "var(--text-primary)", fontWeight: 700 }}>{campaign.name}</span>
        </div>
      </div>

      <div className="card" style={{ padding: 0, overflow: "hidden", marginBottom: "1rem" }}>
        <div style={{ height: 100, background: `linear-gradient(135deg, ${campaign.coverColor}, ${campaign.coverColor}aa)`, display: "flex", alignItems: "flex-end", padding: "1rem 1.5rem", color: "white", position: "relative" }}>
          <div>
            <div style={{ fontSize: "0.72rem", textTransform: "uppercase", letterSpacing: "0.08em", fontWeight: 700, opacity: 0.85 }}>Campaign</div>
            <div style={{ fontSize: "1.5rem", fontWeight: 900, lineHeight: 1.1 }}>{campaign.name}</div>
          </div>
        </div>
        <div style={{ padding: "1.25rem 1.5rem", display: "grid", gridTemplateColumns: "1.5fr auto", gap: "1.5rem", alignItems: "center" }}>
          <div>
            <div style={{ fontSize: "0.85rem", color: "var(--text-secondary)", display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
              <Building2 size={12} /> {campaign.entityName || "—"}
              {campaign.websiteUrl && <><span style={{ margin: "0 4px" }}>·</span><Globe size={12} /> <a href={campaign.websiteUrl} target="_blank" rel="noreferrer" style={{ color: campaign.coverColor, fontWeight: 700 }}>Website ↗</a></>}
              {campaign.funnelUrl && <><span style={{ margin: "0 4px" }}>·</span><TargetIcon size={12} /> <a href={campaign.funnelUrl} target="_blank" rel="noreferrer" style={{ color: campaign.coverColor, fontWeight: 700 }}>Funnel ↗</a></>}
            </div>
            {campaign.description && <div style={{ fontSize: "0.88rem", lineHeight: 1.5, maxWidth: 720 }}>{campaign.description}</div>}
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: "0.7rem", textTransform: "uppercase", color: "var(--text-muted)", letterSpacing: "0.05em", fontWeight: 700 }}>Conversion</div>
            <div style={{ fontSize: "2rem", fontWeight: 900, color: campaign.coverColor }}>{conversion}%</div>
            <div style={{ fontSize: "0.72rem", color: "var(--text-muted)" }}>{clients} of {total} contacts</div>
          </div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "0.75rem", marginBottom: "1.25rem" }}>
        <StatTile label="Total Contacts" value={total} icon={<Users size={16} />} color={campaign.coverColor} />
        <StatTile label="Leads" value={leads} icon={<Users size={16} />} color="#94a3b8" />
        <StatTile label="Prospects" value={prospects} icon={<Users size={16} />} color="#f59e0b" />
        <StatTile label="Clients" value={clients} icon={<TrendingUp size={16} />} color="#10b981" />
      </div>

      <CampaignDetailsEditor
        campaignId={campaign.id}
        coverColor={campaign.coverColor}
        initial={{
          service: campaign.service,
          niche: campaign.niche,
          entityName: campaign.entityName,
          websiteUrl: campaign.websiteUrl,
          funnelUrl: campaign.funnelUrl,
          description: campaign.description,
        }}
      />

      <CampaignClient
        campaignId={campaign.id}
        coverColor={campaign.coverColor}
        tags={campaign.tags.map((t) => ({
          id: t.id,
          label: t.label,
          color: t.color,
          leads: t.contacts.filter((c) => c.status === "LEAD").length,
          prospects: t.contacts.filter((c) => c.status === "PROSPECT").length,
          clients: t.contacts.filter((c) => c.status === "CLIENT").length,
          contacts: t.contacts.map((c) => ({ id: c.id, name: c.name, email: c.email, status: c.status })),
        }))}
        links={campaign.links.map((l) => ({ id: l.id, label: l.label, url: l.url, kind: l.kind }))}
        files={campaign.files.map((f) => ({ id: f.id, name: f.name, format: f.format, url: f.url, createdAt: f.createdAt.toISOString(), uploader: f.uploader ? { name: f.uploader.name, image: f.uploader.image } : null }))}
      />
    </div>
  );
}

function StatTile({ label, value, icon, color }: { label: string; value: number; icon: React.ReactNode; color: string }) {
  return (
    <div className="card" style={{ padding: "1rem" }}>
      <div className="row-between" style={{ marginBottom: "0.4rem" }}>
        <div style={{ fontSize: "0.7rem", textTransform: "uppercase", color: "var(--text-secondary)", letterSpacing: "0.05em", fontWeight: 700 }}>{label}</div>
        <div style={{ color, display: "flex", alignItems: "center", justifyContent: "center", width: 28, height: 28, borderRadius: 8, background: color + "18" }}>{icon}</div>
      </div>
      <div style={{ fontSize: "1.6rem", fontWeight: 900, color }}>{value}</div>
    </div>
  );
}
