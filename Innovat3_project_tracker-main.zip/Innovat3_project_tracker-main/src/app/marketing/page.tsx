import { requireDepartment } from "@/lib/rbac";
import { db } from "@/lib/db";
import Link from "next/link";
import { Megaphone, TrendingUp, Target } from "lucide-react";
import { NewCampaignButton } from "@/components/marketing/NewCampaignButton";

export const dynamic = "force-dynamic";

export default async function MarketingCommandCenter() {
  await requireDepartment("marketing");

  const campaigns = await db.campaign.findMany({
    orderBy: { createdAt: "desc" },
    include: { tags: { include: { contacts: { select: { status: true } } } }, _count: { select: { links: true, files: true } } },
  });

  type Stats = { id: string; name: string; entityName: string | null; coverColor: string; leads: number; prospects: number; clients: number; total: number; tagCount: number; linkCount: number; fileCount: number };
  const stats: Stats[] = campaigns.map((c) => {
    let leads = 0, prospects = 0, clients = 0;
    for (const t of c.tags) for (const ct of t.contacts) {
      if (ct.status === "CLIENT") clients++;
      else if (ct.status === "PROSPECT") prospects++;
      else leads++;
    }
    return { id: c.id, name: c.name, entityName: c.entityName, coverColor: c.coverColor, leads, prospects, clients, total: leads + prospects + clients, tagCount: c.tags.length, linkCount: c._count.links, fileCount: c._count.files };
  });

  const totals = stats.reduce((a, s) => ({ leads: a.leads + s.leads, prospects: a.prospects + s.prospects, clients: a.clients + s.clients, total: a.total + s.total }), { leads: 0, prospects: 0, clients: 0, total: 0 });
  const overallConv = totals.total ? Math.round((totals.clients / totals.total) * 100) : 0;
  const topByConv = [...stats].filter((s) => s.total > 0).sort((a, b) => (b.clients / Math.max(b.total, 1)) - (a.clients / Math.max(a.total, 1))).slice(0, 5);

  return (
    <div className="animate-slide-up">
      <div className="row-between" style={{ marginBottom: "1.25rem" }}>
        <div>
          <h1 className="page-title" style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <span className="dept-dot" style={{ background: "#ec4899", width: 12, height: 12 }} />
            Marketing · Command Center
          </h1>
          <p className="page-subtitle">{campaigns.length} campaigns · {totals.total} tagged contacts · {totals.clients} converted to clients.</p>
        </div>
        <div className="flex-gap">
          <Link href="/marketing/campaigns" className="btn btn-ghost">All Campaigns →</Link>
          <NewCampaignButton />
        </div>
      </div>

      <div className="sales-hero" style={{ background: "linear-gradient(135deg, #ec4899 0%, #7c3aed 55%, #4318ff 100%)", boxShadow: "0 20px 40px rgba(236, 72, 153, 0.25)" }}>
        <div style={{ position: "relative", zIndex: 1 }}>
          <div className="hero-label"><Megaphone size={12} style={{ display: "inline", marginRight: 4 }} /> Overall Conversion</div>
          <div className="hero-value">{overallConv}% <span style={{ fontSize: "1rem", opacity: 0.75, fontWeight: 600 }}>tagged → client</span></div>
          <div className="hero-sub">{totals.clients} clients from {totals.total} tagged contacts across {campaigns.length} campaigns</div>
          <div className="quota-bar"><div className="quota-fill" style={{ width: `${overallConv}%` }} /></div>
          <div style={{ display: "flex", gap: "0.5rem", marginTop: "1rem", flexWrap: "wrap" }}>
            <span style={{ background: "rgba(255,255,255,0.18)", padding: "0.35rem 0.7rem", borderRadius: 999, fontSize: "0.75rem", fontWeight: 700 }}>{totals.leads} leads</span>
            <span style={{ background: "rgba(255,255,255,0.18)", padding: "0.35rem 0.7rem", borderRadius: 999, fontSize: "0.75rem", fontWeight: 700 }}>{totals.prospects} prospects</span>
            <span style={{ background: "rgba(255,255,255,0.18)", padding: "0.35rem 0.7rem", borderRadius: 999, fontSize: "0.75rem", fontWeight: 700 }}>{totals.clients} clients</span>
          </div>
        </div>
        <div className="hero-kpis">
          <div className="hero-kpi"><div className="k-label">Active Campaigns</div><div className="k-value">{campaigns.length}</div><div className="k-delta">Running now</div></div>
          <div className="hero-kpi"><div className="k-label">Total Contacts</div><div className="k-value">{totals.total}</div><div className="k-delta">Across all tags</div></div>
          <div className="hero-kpi"><div className="k-label">Clients Converted</div><div className="k-value">{totals.clients}</div><div className="k-delta">Tag status = CLIENT</div></div>
          <div className="hero-kpi"><div className="k-label">Prospects in Play</div><div className="k-value">{totals.prospects}</div><div className="k-delta">Ready to close</div></div>
        </div>
      </div>

      <div className="sales-split">
        <div className="card">
          <div className="row-between" style={{ marginBottom: "0.75rem" }}>
            <h2 style={{ fontSize: "1rem", fontWeight: 800, display: "flex", alignItems: "center", gap: 6 }}><Target size={16} color="#ec4899" /> Campaigns by Volume</h2>
            <Link href="/marketing/campaigns" style={{ fontSize: "0.8rem", color: "#ec4899", fontWeight: 700 }}>All →</Link>
          </div>
          {stats.length === 0 && <div style={{ color: "var(--text-muted)", fontSize: "0.85rem", padding: "1rem 0" }}>No campaigns yet. Create your first one to start tracking.</div>}
          {stats.map((s) => {
            const conv = s.total ? Math.round((s.clients / s.total) * 100) : 0;
            return (
              <Link key={s.id} href={`/marketing/campaigns/${s.id}`} className="hot-lead-row" style={{ textDecoration: "none" }}>
                <div style={{ minWidth: 44, height: 44, borderRadius: 12, background: s.coverColor, color: "white", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 900, fontSize: "0.85rem", flexShrink: 0 }}>
                  {s.name.slice(0, 2).toUpperCase()}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: 700, fontSize: "0.88rem", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{s.name}</div>
                  <div style={{ fontSize: "0.7rem", color: "var(--text-secondary)", display: "flex", gap: 8, marginTop: 2 }}>
                    <span>{s.total} contacts</span>
                    <span style={{ color: "#94a3b8" }}>{s.leads}L</span>
                    <span style={{ color: "#f59e0b" }}>{s.prospects}P</span>
                    <span style={{ color: "#10b981", fontWeight: 700 }}>{s.clients}C</span>
                  </div>
                </div>
                <div style={{ textAlign: "right", minWidth: 62 }}>
                  <div style={{ fontSize: "0.95rem", fontWeight: 900, color: s.coverColor }}>{conv}%</div>
                  <div style={{ fontSize: "0.65rem", color: "var(--text-muted)", fontWeight: 700 }}>conv</div>
                </div>
              </Link>
            );
          })}
        </div>

        <div className="card">
          <div className="row-between" style={{ marginBottom: "0.75rem" }}>
            <h2 style={{ fontSize: "1rem", fontWeight: 800, display: "flex", alignItems: "center", gap: 6 }}><TrendingUp size={16} color="#10b981" /> Top Converters</h2>
            <span style={{ fontSize: "0.75rem", color: "var(--text-muted)" }}>By client rate</span>
          </div>
          {topByConv.length === 0 && <div style={{ color: "var(--text-muted)", fontSize: "0.85rem", padding: "1rem 0" }}>No conversion data yet.</div>}
          {topByConv.map((s, i) => {
            const conv = Math.round((s.clients / s.total) * 100);
            return (
              <div key={s.id} className="rep-row">
                <div className={`rep-rank ${i === 0 ? "top" : ""}`}>{i + 1}</div>
                <div style={{ width: 36, height: 36, borderRadius: 10, background: s.coverColor, color: "white", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, fontSize: "0.75rem", flexShrink: 0 }}>
                  {s.name.slice(0, 2).toUpperCase()}
                </div>
                <div style={{ minWidth: 0, flex: "0 0 140px" }}>
                  <div className="rep-name" style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{s.name}</div>
                  <div className="rep-meta">{s.clients} clients · {s.total} contacts</div>
                </div>
                <div className="rep-bar"><div className="rep-bar-fill" style={{ width: `${conv}%`, background: `linear-gradient(90deg, ${s.coverColor}, #10b981)` }} /></div>
                <div className="rep-value">{conv}%</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
