import { requireAdmin } from "@/lib/rbac";
import { db } from "@/lib/db";
import { CommissionConfigEditor } from "@/components/admin/CommissionConfigEditor";

export const dynamic = "force-dynamic";

const SERVICE_TYPES = [
  "WEBSITE_BUILD",
  "FORM_INTEGRATION",
  "CRM_INTEGRATION",
  "AUTOMATION",
  "VOICE_AI",
  "LEAD_NURTURING",
  "EMAIL_MARKETING",
  "OTHER",
] as const;

const DEFAULT_LABELS: Record<string, string> = {
  WEBSITE_BUILD: "Website Build",
  FORM_INTEGRATION: "Form Integration",
  CRM_INTEGRATION: "CRM Integration",
  AUTOMATION: "Automation",
  VOICE_AI: "Voice AI",
  LEAD_NURTURING: "Lead Nurturing",
  EMAIL_MARKETING: "Email Marketing",
  OTHER: "Other",
};

export default async function CommissionConfigPage() {
  await requireAdmin();

  const [activeRate, rateHistory, activePricing] = await Promise.all([
    db.commissionRate.findFirst({
      where: { effectiveTo: null },
      orderBy: { effectiveFrom: "desc" },
      include: { updatedBy: { select: { name: true, email: true } } },
    }),
    db.commissionRate.findMany({
      orderBy: { effectiveFrom: "desc" },
      take: 10,
      include: { updatedBy: { select: { name: true, email: true } } },
    }),
    db.servicePricing.findMany({
      where: { effectiveTo: null },
      orderBy: { serviceType: "asc" },
      include: { updatedBy: { select: { name: true, email: true } } },
    }),
  ]);

  // Ensure every service type has a row — unconfigured ones render as empty
  const pricingByType = new Map(activePricing.map((p) => [p.serviceType, p]));
  const pricingRows = SERVICE_TYPES.map((st) => {
    const existing = pricingByType.get(st);
    if (existing) return existing;
    return {
      id: null,
      serviceType: st,
      label: DEFAULT_LABELS[st] || st,
      onboardingFee: 0,
      monthlyFee: 0,
      cost: 0,
      effectiveFrom: null,
      updatedBy: null,
    };
  });

  const payload = JSON.parse(JSON.stringify({
    activeRate,
    rateHistory,
    pricingRows,
    serviceTypes: SERVICE_TYPES,
  }));

  return <CommissionConfigEditor initial={payload} />;
}
