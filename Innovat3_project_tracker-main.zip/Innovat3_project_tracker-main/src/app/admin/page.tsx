import { requireAdmin } from "@/lib/rbac";
import { AdminCommandCenter } from "@/components/admin/AdminCommandCenter";

export const dynamic = "force-dynamic";

export default async function AdminDashboardPage() {
  await requireAdmin();
  return <AdminCommandCenter />;
}
