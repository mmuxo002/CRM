import { requireAdmin } from "@/lib/rbac";
import { db } from "@/lib/db";
import { InviteForm } from "@/components/admin/InviteForm";
import { UserTable } from "@/components/admin/UserTable";
import type { AdminUser } from "@/components/admin/EditUserModal";
import { Shield, Mail, KeyRound, LogIn, Circle } from "lucide-react";

export const dynamic = "force-dynamic";

const ACTIVE_WINDOW_MIN = 5;

export default async function AdminUsersPage() {
  await requireAdmin();

  const users = await db.user.findMany({ orderBy: [{ isActive: "desc" }, { name: "asc" }] });
  const plainUsers: AdminUser[] = users.map((u) => ({
    id: u.id,
    name: u.name,
    email: u.email,
    image: u.image,
    title: u.title,
    role: u.role,
    accessDepartments: u.accessDepartments,
    isActive: u.isActive,
    mustResetPassword: u.mustResetPassword,
    invitedAt: u.invitedAt ? u.invitedAt.toISOString() : null,
    lastSeenAt: u.lastSeenAt ? u.lastSeenAt.toISOString() : null,
  }));

  const active = users.filter((u) => u.isActive);
  const enrolled = active.length;
  const pendingApproval = active.filter((u) => u.mustResetPassword).length;
  const approved = active.filter((u) => !u.mustResetPassword).length;
  const neverLoggedIn = active.filter((u) => !u.lastSeenAt).length;
  const onlineNow = active.filter((u) => u.lastSeenAt && (Date.now() - u.lastSeenAt.getTime()) / 60000 <= ACTIVE_WINDOW_MIN).length;

  return (
    <div className="animate-slide-up">
      <div className="row-between" style={{ marginBottom: "1.25rem" }}>
        <div>
          <h1 className="page-title" style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <Shield size={22} color="#4318ff" />
            User Management
          </h1>
          <p className="page-subtitle">Invite teammates, update their details, and control which departments they can access.</p>
        </div>
      </div>

      <div className="card" style={{ padding: "1rem 1.25rem", marginBottom: "1.5rem" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: "1rem" }}>
          <StatusStat label="Enrolled" value={enrolled} icon={<Mail size={14} />} color="#4318ff" sub="Active users" />
          <StatusStat label="Approved" value={approved} icon={<KeyRound size={14} />} color="#10b981" sub="Completed reset" />
          <StatusStat label="Pending approval" value={pendingApproval} icon={<KeyRound size={14} />} color="#f59e0b" sub="Awaiting reset" />
          <StatusStat label="Never logged in" value={neverLoggedIn} icon={<LogIn size={14} />} color="#ef4444" sub="No first sign-in yet" />
          <StatusStat label="Online now" value={onlineNow} icon={<Circle size={14} />} color="#059669" sub="Last 5 minutes" />
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1.5rem", marginBottom: "1.5rem" }}>
        <InviteForm />
        <div className="card">
          <h2 style={{ fontSize: "1rem", fontWeight: 800, marginBottom: "0.75rem" }}>Managing users</h2>
          <ol style={{ paddingLeft: "1.1rem", fontSize: "0.85rem", lineHeight: 1.6, color: "var(--text-secondary)" }}>
            <li><strong>Invite:</strong> fill in the form on the left — a temporary password is generated and shown to you once.</li>
            <li><strong>Edit:</strong> click <em>Edit</em> on any row to change their name, email, profile picture, role, or department access.</li>
            <li><strong>Reset password:</strong> inside Edit, click <em>Reset password</em> to issue a new temporary password they must change on next sign-in.</li>
            <li><strong>Deactivate:</strong> uncheck “Active” inside Edit to block sign-in without deleting their data.</li>
          </ol>
        </div>
      </div>

      <UserTable users={plainUsers} />
    </div>
  );
}

function StatusStat({ label, value, icon, color, sub }: { label: string; value: number; icon: React.ReactNode; color: string; sub: string }) {
  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: "0.65rem", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.04em", color: "var(--text-secondary)", marginBottom: 4 }}>
        <span style={{ color, display: "flex" }}>{icon}</span>
        {label}
      </div>
      <div style={{ fontSize: "1.5rem", fontWeight: 900, color: "var(--text-primary)" }}>{value}</div>
      <div style={{ fontSize: "0.68rem", color: "var(--text-muted)", fontWeight: 600 }}>{sub}</div>
    </div>
  );
}
