import { requireSession } from "@/lib/rbac";
import { DevDashboard } from "@/components/dashboard/DevDashboard";

export const dynamic = "force-dynamic";

export default async function AppsDevPage() {
  const { user } = await requireSession();
  return <DevDashboard team="APPS" userId={user.id} />;
}
