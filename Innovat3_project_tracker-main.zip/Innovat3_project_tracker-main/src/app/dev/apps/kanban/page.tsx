import { requireRole } from "@/lib/rbac";
import { TeamBoard } from "@/components/kanban/TeamBoard";
import { TaskPipelineStrip } from "@/components/kanban/TaskPipelineStrip";

export const dynamic = "force-dynamic";

export default async function AppsKanban() {
  await requireRole("APPS_DEV");
  return (
    <div className="animate-slide-up">
      <div className="row-between" style={{ marginBottom: "1.5rem" }}>
        <div>
          <h1 className="page-title">Development Board</h1>
          <p className="page-subtitle">Development Team pipeline & sprint board · isolated by team_id.</p>
        </div>
        <button className="btn btn-primary">+ Add New Task</button>
      </div>
      <TaskPipelineStrip team="APPS" />
      <TeamBoard team="APPS" />
    </div>
  );
}
