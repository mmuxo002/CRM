import { requireSession } from "@/lib/rbac";
import { OnboardForm } from "@/components/crm/OnboardForm";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default async function OnboardClientPage() {
  await requireSession();
  return (
    <div className="animate-slide-up">
      <div className="row-between" style={{ marginBottom: "1.5rem" }}>
        <div>
          <div className="flex-gap" style={{ fontSize: "0.85rem", color: "var(--text-secondary)" }}>
            <Link href="/dev/crm">CRM</Link><span>/</span><span style={{ color: "var(--text-primary)", fontWeight: 700 }}>Onboard Client</span>
          </div>
          <h1 className="page-title" style={{ marginTop: 6 }}>Onboard a new client</h1>
          <p className="page-subtitle">Create the client record, pick the service, and we'll spin up a project in the Onboarded column.</p>
        </div>
      </div>
      <OnboardForm />
    </div>
  );
}
