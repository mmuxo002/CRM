import { requireSession } from "@/lib/rbac";
import { CrmCommandCenter } from "@/components/dashboard/CrmCommandCenter";

export const dynamic = "force-dynamic";

export default async function CrmDevPage() {
  const { user } = await requireSession();
  return <CrmCommandCenter userId={user.id} />;
}
