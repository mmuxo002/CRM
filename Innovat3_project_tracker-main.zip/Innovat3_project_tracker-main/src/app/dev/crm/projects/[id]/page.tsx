import { requireSession } from "@/lib/rbac";
import { db } from "@/lib/db";
import { notFound } from "next/navigation";
import Link from "next/link";
import { Building2, Calendar, DollarSign, Mail, Phone, Globe } from "lucide-react";
import { serviceTypeMeta } from "@/lib/crm";
import { StageSelector, TaskList, NoteList } from "@/components/crm/ProjectDetailClient";
import { ProjectKanban } from "@/components/crm/ProjectKanban";
import { FilesFoldersEditor } from "@/components/records/ProjectRecordEditors";
import { ProjectMeetingsCard } from "@/components/schedule/ProjectMeetingsCard";

export const dynamic = "force-dynamic";

export default async function CrmProjectDetail({ params }: { params: Promise<{ id: string }> }) {
  await requireSession();
  const { id } = await params;

  const project = await db.project.findUnique({
    where: { id },
    include: {
      company: { include: { contacts: true } },
      owner: true,
      tasks: { include: { assignee: true }, orderBy: { createdAt: "asc" } },
      comments: { include: { author: true }, orderBy: { createdAt: "asc" } },
      tags: true,
      folders: true,
      files: true,
    },
  });
  if (!project || project.teamId !== "CRM") notFound();

  const svc = serviceTypeMeta(project.serviceType);

  return (
    <div className="animate-slide-up">
      <div className="row-between" style={{ marginBottom: "1rem" }}>
        <div className="flex-gap" style={{ fontSize: "0.85rem", color: "var(--text-secondary)" }}>
          <Link href="/dev/crm">CRM</Link><span>/</span>
          <Link href="/dev/crm/projects">Pipeline</Link><span>/</span>
          <span style={{ color: "var(--text-primary)", fontWeight: 700 }}>{project.company?.name || project.name}</span>
        </div>
      </div>

      <div className="card" style={{ padding: "1.25rem", marginBottom: "1.25rem", background: `linear-gradient(135deg, ${svc.color}12, transparent)` }}>
        <div className="row-between" style={{ alignItems: "flex-start", flexWrap: "wrap", gap: "1rem" }}>
          <div className="flex-gap" style={{ gap: "0.9rem" }}>
            <div style={{ width: 52, height: 52, borderRadius: 12, background: `linear-gradient(135deg, ${svc.color}, ${svc.color}aa)`, color: "white", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, fontSize: 16 }}>
              {(project.company?.name || project.name).slice(0, 2).toUpperCase()}
            </div>
            <div>
              <div style={{ fontSize: "1.3rem", fontWeight: 800 }}>{project.company?.name || project.name}</div>
              <div style={{ fontSize: "0.85rem", color: "var(--text-secondary)" }}>{project.name}</div>
              <div className="flex-gap" style={{ marginTop: 6, flexWrap: "wrap" }}>
                <span className="badge" style={{ background: svc.color + "22", color: svc.color, fontSize: 11 }}>{svc.label}</span>
                {project.priority && <span className={`priority-${project.priority.toLowerCase()}`}>{project.priority.toLowerCase()} priority</span>}
                {project.mrr > 0 && <span className="badge badge-green" style={{ fontSize: 11 }}><DollarSign size={10} style={{ display: "inline" }} /> ${project.mrr.toLocaleString()}/mo</span>}
                {project.dueDate && <span className="badge badge-blue" style={{ fontSize: 11 }}><Calendar size={10} style={{ display: "inline" }} /> Due {new Date(project.dueDate).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</span>}
                {project.tags.map((t) => (
                  <span key={t.id} className="badge" style={{ background: t.color + "22", color: t.color, fontSize: 11, fontWeight: 700 }}>{t.label}</span>
                ))}
              </div>
            </div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: "0.7rem", fontWeight: 700, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 6 }}>Delivery Stage</div>
            <StageSelector projectId={project.id} initial={project.crmStage} />
          </div>
        </div>
        <div style={{ marginTop: "1rem" }}>
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.75rem", marginBottom: 4 }}>
            <span style={{ fontWeight: 700 }}>Overall Progress</span><span style={{ color: "var(--text-muted)" }}>{project.progress}%</span>
          </div>
          <div className="progress-bar-bg"><div className="progress-bar-fill" style={{ width: `${project.progress}%`, background: svc.color }} /></div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.6fr 1fr", gap: "1.25rem" }}>
        <div style={{ display: "flex", flexDirection: "column", gap: "1.25rem" }}>
          <div className="card">
            <div className="row-between" style={{ marginBottom: "0.75rem" }}>
              <h2 style={{ fontSize: "1rem", fontWeight: 800 }}>Progress Board</h2>
              <span style={{ fontSize: "0.75rem", color: "var(--text-muted)" }}>Drag tasks across columns to update status.</span>
            </div>
            <ProjectKanban initial={project.tasks.map((t) => ({
              id: t.id,
              title: t.title,
              status: t.status,
              priority: t.priority,
              dueDate: t.dueDate?.toISOString() ?? null,
              assignee: t.assignee ? { id: t.assignee.id, name: t.assignee.name, image: t.assignee.image } : null,
            }))} />
          </div>

          <div className="card">
            <div className="row-between" style={{ marginBottom: "0.75rem" }}>
              <h2 style={{ fontSize: "1rem", fontWeight: 800 }}>Tasks</h2>
              <span style={{ fontSize: "0.75rem", color: "var(--text-muted)" }}>Check off as you go — no time tracking.</span>
            </div>
            <TaskList projectId={project.id} initial={project.tasks.map((t) => ({
              id: t.id,
              title: t.title,
              status: t.status,
              dueDate: t.dueDate?.toISOString() ?? null,
              assignee: t.assignee ? { id: t.assignee.id, name: t.assignee.name, image: t.assignee.image } : null,
            }))} />
          </div>

          <div className="card">
            <h2 style={{ fontSize: "1rem", fontWeight: 800, marginBottom: "0.75rem" }}>Notes</h2>
            <NoteList projectId={project.id} initial={project.comments.map((c) => ({
              id: c.id,
              body: c.body,
              createdAt: c.createdAt.toISOString(),
              author: { id: c.author.id, name: c.author.name, image: c.author.image },
            }))} />
          </div>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
          {project.company && (
            <div className="card">
              <h4 style={{ fontSize: "0.7rem", textTransform: "uppercase", color: "var(--text-secondary)", letterSpacing: "0.05em", fontWeight: 700, marginBottom: "0.75rem" }}>Client</h4>
              <div className="flex-gap" style={{ gap: "0.75rem", marginBottom: "0.75rem" }}>
                <div style={{ width: 40, height: 40, borderRadius: 10, background: "#f1f5f9", display: "flex", alignItems: "center", justifyContent: "center" }}><Building2 size={20} /></div>
                <div>
                  <div style={{ fontWeight: 800 }}>{project.company.name}</div>
                  <div style={{ fontSize: "0.75rem", color: "var(--text-muted)" }}>{project.company.industry || "—"}</div>
                </div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 6, fontSize: "0.8rem", color: "var(--text-secondary)" }}>
                {project.company.email && <div className="flex-gap"><Mail size={13} /> {project.company.email}</div>}
                {project.company.phone && <div className="flex-gap"><Phone size={13} /> {project.company.phone}</div>}
                {project.company.website && <div className="flex-gap"><Globe size={13} /> {project.company.website}</div>}
              </div>
              {project.company.contacts && project.company.contacts.length > 0 && (
                <div style={{ marginTop: "0.75rem", paddingTop: "0.75rem", borderTop: "1px solid var(--border-color)" }}>
                  <div style={{ fontSize: "0.7rem", textTransform: "uppercase", color: "var(--text-muted)", fontWeight: 700, letterSpacing: "0.05em", marginBottom: 6 }}>Point of contact</div>
                  {project.company.contacts.slice(0, 2).map((c) => (
                    <div key={c.id} className="flex-gap" style={{ fontSize: "0.8rem", marginBottom: 4 }}>
                      {c.avatarUrl && <img src={c.avatarUrl} alt="" style={{ width: 24, height: 24, borderRadius: "50%" }} />}
                      <div><div style={{ fontWeight: 700 }}>{c.name}</div><div style={{ fontSize: "0.7rem", color: "var(--text-muted)" }}>{c.title}</div></div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          <div className="card">
            <h4 style={{ fontSize: "0.7rem", textTransform: "uppercase", color: "var(--text-secondary)", letterSpacing: "0.05em", fontWeight: 700, marginBottom: "0.75rem" }}>Delivery Owner</h4>
            {project.owner ? (
              <div className="flex-gap">
                {project.owner.image ? <img src={project.owner.image} alt="" style={{ width: 36, height: 36, borderRadius: "50%" }} /> : <div style={{ width: 36, height: 36, borderRadius: "50%", background: "#e2e8f0" }} />}
                <div>
                  <div style={{ fontWeight: 700 }}>{project.owner.name}</div>
                  <div style={{ fontSize: "0.7rem", color: "var(--text-muted)" }}>{project.owner.title || project.owner.role}</div>
                </div>
              </div>
            ) : <div style={{ fontSize: "0.85rem", color: "var(--text-muted)" }}>Unassigned</div>}
          </div>

          <ProjectMeetingsCard projectId={project.id} />

          <div className="card">
            <h4 style={{ fontSize: "0.7rem", textTransform: "uppercase", color: "var(--text-secondary)", letterSpacing: "0.05em", fontWeight: 700, marginBottom: "0.75rem" }}>Files & Folders</h4>
            <FilesFoldersEditor
              projectId={project.id}
              initialFolders={project.folders.map((f) => ({ id: f.id, name: f.name, color: f.color }))}
              initialFiles={project.files.map((f) => ({ id: f.id, name: f.name, format: f.format, url: f.url, isLink: f.isLink, folderId: f.folderId }))}
            />
          </div>

          {project.description && (
            <div className="card">
              <h4 style={{ fontSize: "0.7rem", textTransform: "uppercase", color: "var(--text-secondary)", letterSpacing: "0.05em", fontWeight: 700, marginBottom: "0.75rem" }}>Scope Summary</h4>
              <div style={{ fontSize: "0.85rem", lineHeight: 1.55, color: "var(--text-primary)" }}>{project.description}</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
