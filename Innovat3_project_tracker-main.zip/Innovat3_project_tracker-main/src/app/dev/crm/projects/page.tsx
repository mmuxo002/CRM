import { requireSession } from "@/lib/rbac";
import { db } from "@/lib/db";
import Link from "next/link";
import { KanbanBoard, type KanbanColumn } from "@/components/kanban/KanbanBoard";
import { CRM_STAGES, serviceTypeMeta } from "@/lib/crm";
import { UserPlus } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function CrmProjectsBoard() {
  await requireSession();

  const projects = await db.project.findMany({
    where: { teamId: "CRM" },
    include: { company: true, owner: true, _count: { select: { tasks: true, comments: true, files: true } } },
    orderBy: { updatedAt: "desc" },
  });

  const columns: KanbanColumn[] = CRM_STAGES.map((s) => ({
    id: s.id,
    title: s.label,
    color: s.color,
    cards: projects.filter((p) => p.crmStage === s.id).map((p) => {
      const svc = serviceTypeMeta(p.serviceType);
      return {
        id: p.id,
        title: p.company?.name || p.name,
        description: p.name !== p.company?.name ? p.name : p.description || undefined,
        priority: p.priority,
        categoryTag: svc.label,
        progress: p.progress,
        dueDate: p.dueDate?.toISOString() ?? null,
        assignees: p.owner ? [{ id: p.owner.id, name: p.owner.name, image: p.owner.image }] : [],
        taskCount: p._count.tasks,
        commentCount: p._count.comments,
        attachmentCount: p._count.files,
        progressBarMode: "progress" as const,
        href: `/dev/crm/projects/${p.id}`,
      };
    }),
  }));

  return (
    <div className="animate-slide-up">
      <div className="row-between" style={{ marginBottom: "1.5rem" }}>
        <div>
          <h1 className="page-title">CRM Delivery Pipeline</h1>
          <p className="page-subtitle">Each card is a client engagement. Drag across stages as work progresses.</p>
        </div>
        <div className="flex-gap">
          <Link href="/dev/crm" className="btn btn-ghost">← Dashboard</Link>
          <Link href="/dev/crm/onboard" className="btn btn-primary" style={{ background: "linear-gradient(135deg, #7c3aed, #ec4899)", borderColor: "transparent" }}><UserPlus size={14} /> Onboard Client</Link>
        </div>
      </div>

      <KanbanBoard columns={columns} moveEndpoint="/api/crm/projects/move" />
    </div>
  );
}
