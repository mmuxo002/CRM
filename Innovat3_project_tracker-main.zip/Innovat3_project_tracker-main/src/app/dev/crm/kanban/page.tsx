import { requireRole } from "@/lib/rbac";
import { TeamBoard } from "@/components/kanban/TeamBoard";
import { TaskPipelineStrip } from "@/components/kanban/TaskPipelineStrip";

export const dynamic = "force-dynamic";

export default async function CrmKanban() {
  await requireRole("CRM_DEV");
  return (
    <div className="animate-slide-up">
      <div className="row-between" style={{ marginBottom: "1.5rem" }}>
        <div>
          <h1 className="page-title">CRM Development</h1>
          <p className="page-subtitle">CRM Team pipeline & sprint board · isolated by team_id.</p>
        </div>
        <button className="btn btn-primary">+ Add New Task</button>
      </div>
      <TaskPipelineStrip team="CRM" />
      <TeamBoard team="CRM" />
    </div>
  );
}
