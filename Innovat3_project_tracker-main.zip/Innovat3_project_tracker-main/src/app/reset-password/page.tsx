"use client";

import { useState } from "react";
import { useSession, signOut } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Eye, EyeOff, KeyRound, Loader2, LogOut } from "lucide-react";

export default function ResetPasswordPage() {
  const { data: session, update } = useSession();
  const router = useRouter();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNext, setShowNext] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (next.length < 8) { setError("Your new password must be at least 8 characters."); return; }
    if (next !== confirm) { setError("The confirmation does not match your new password."); return; }
    setLoading(true);
    const res = await fetch("/api/auth/reset-password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ currentPassword: current, newPassword: next }),
    });
    setLoading(false);
    if (!res.ok) {
      const j = await res.json().catch(() => ({}));
      setError(j.error || "We couldn't update your password. Please try again.");
      return;
    }
    await update();
    router.push("/");
    router.refresh();
  }

  const mustReset = (session?.user as any)?.mustResetPassword;
  const strength = scorePassword(next);

  return (
    <div style={styles.page}>
      <div style={styles.glowA} />
      <div style={styles.glowB} />

      <div style={styles.shell}>
        <div style={styles.brandRow}>
          <div style={styles.logoMark}>I3</div>
          <div>
            <div style={styles.wordmark}>INNOVAT3</div>
            <div style={styles.wordmarkSub}>Pulse Tracker</div>
          </div>
        </div>

        <div style={styles.card}>
          <div style={styles.eyebrow}>
            <KeyRound size={13} />
            {mustReset ? "First sign-in" : "Account security"}
          </div>
          <h1 style={styles.title}>{mustReset ? "Set your password" : "Change your password"}</h1>
          <p style={styles.subtitle}>
            {mustReset
              ? "This is your first time signing in. Choose a new password to continue to your workspace."
              : "Update your password. You'll stay signed in on this device."}
          </p>

          <form onSubmit={onSubmit} style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
            <Field label={mustReset ? "Temporary password" : "Current password"}>
              <PasswordInput
                value={current}
                onChange={setCurrent}
                show={showCurrent}
                setShow={setShowCurrent}
                autoComplete="current-password"
                autoFocus
                placeholder={mustReset ? "Paste the temp password your admin gave you" : "Enter your current password"}
              />
            </Field>

            <Field label="New password">
              <PasswordInput
                value={next}
                onChange={setNext}
                show={showNext}
                setShow={setShowNext}
                autoComplete="new-password"
                placeholder="At least 8 characters"
              />
              {next.length > 0 && <StrengthMeter score={strength} />}
            </Field>

            <Field label="Confirm new password">
              <PasswordInput
                value={confirm}
                onChange={setConfirm}
                show={showNext}
                setShow={setShowNext}
                autoComplete="new-password"
                placeholder="Re-enter your new password"
              />
            </Field>

            {error && <div style={styles.errorBox} role="alert">{error}</div>}

            <button
              type="submit"
              disabled={loading}
              style={{ ...styles.submitBtn, opacity: loading ? 0.7 : 1, cursor: loading ? "not-allowed" : "pointer" }}
            >
              {loading ? (
                <><Loader2 size={16} style={{ animation: "spin 0.8s linear infinite" }} /> Saving…</>
              ) : (
                "Save new password"
              )}
            </button>
            <button
              type="button"
              onClick={() => signOut({ callbackUrl: "/login" })}
              style={styles.secondaryBtn}
            >
              <LogOut size={15} />
              Sign out instead
            </button>
          </form>
        </div>
      </div>

      <style jsx global>{`
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      <span style={styles.fieldLabel}>{label}</span>
      {children}
    </label>
  );
}

function PasswordInput({
  value, onChange, show, setShow, autoComplete, placeholder, autoFocus,
}: {
  value: string;
  onChange: (v: string) => void;
  show: boolean;
  setShow: (v: boolean) => void;
  autoComplete: string;
  placeholder: string;
  autoFocus?: boolean;
}) {
  return (
    <div style={{ position: "relative" }}>
      <input
        type={show ? "text" : "password"}
        required
        value={value}
        autoFocus={autoFocus}
        autoComplete={autoComplete}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        style={{ ...styles.input, paddingRight: 44 }}
        onFocus={(e) => (e.currentTarget.style.borderColor = "var(--accent-primary)")}
        onBlur={(e) => (e.currentTarget.style.borderColor = "var(--border-hover)")}
      />
      <button
        type="button"
        onClick={() => setShow(!show)}
        aria-label={show ? "Hide password" : "Show password"}
        style={styles.eyeBtn}
      >
        {show ? <EyeOff size={16} /> : <Eye size={16} />}
      </button>
    </div>
  );
}

function scorePassword(pw: string): number {
  if (!pw) return 0;
  let score = 0;
  if (pw.length >= 8) score++;
  if (pw.length >= 12) score++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++;
  if (/\d/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  return Math.min(score, 4);
}

function StrengthMeter({ score }: { score: number }) {
  const labels = ["Too weak", "Weak", "Okay", "Strong", "Excellent"];
  const colors = ["#ef4444", "#f59e0b", "#eab308", "#22c55e", "#05cd99"];
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 6, marginTop: 2 }}>
      <div style={{ display: "flex", gap: 4 }}>
        {[0, 1, 2, 3].map((i) => (
          <div
            key={i}
            style={{
              flex: 1,
              height: 4,
              borderRadius: 2,
              background: i < score ? colors[score] : "var(--border-color)",
              transition: "background 0.15s ease",
            }}
          />
        ))}
      </div>
      <span style={{ fontSize: "0.72rem", color: colors[score], fontWeight: 600 }}>{labels[score]}</span>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  page: {
    position: "relative",
    minHeight: "100vh",
    width: "100%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: "2rem 1.5rem",
    background:
      "linear-gradient(145deg, #2a0fa8 0%, #4318ff 45%, #7c3aed 80%, #ec4899 100%)",
    overflow: "hidden",
  },
  glowA: {
    position: "absolute",
    top: -160,
    right: -160,
    width: 520,
    height: 520,
    borderRadius: "50%",
    background: "radial-gradient(circle, rgba(255,255,255,0.18) 0%, rgba(255,255,255,0) 70%)",
    pointerEvents: "none",
  },
  glowB: {
    position: "absolute",
    bottom: -220,
    left: -180,
    width: 560,
    height: 560,
    borderRadius: "50%",
    background: "radial-gradient(circle, rgba(236,72,153,0.32) 0%, rgba(236,72,153,0) 70%)",
    pointerEvents: "none",
  },
  shell: {
    position: "relative",
    zIndex: 1,
    width: "100%",
    maxWidth: 460,
    display: "flex",
    flexDirection: "column",
    gap: "1.25rem",
  },
  brandRow: {
    display: "flex",
    alignItems: "center",
    gap: "0.75rem",
    color: "white",
  },
  logoMark: {
    width: 44,
    height: 44,
    borderRadius: 11,
    background: "rgba(255,255,255,0.16)",
    border: "1px solid rgba(255,255,255,0.3)",
    backdropFilter: "blur(8px)",
    color: "white",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontWeight: 900,
    fontSize: 15,
  },
  wordmark: {
    fontSize: "1.1rem",
    fontWeight: 900,
    letterSpacing: "0.04em",
    lineHeight: 1,
    color: "white",
  },
  wordmarkSub: {
    fontSize: "0.7rem",
    opacity: 0.8,
    letterSpacing: "0.14em",
    marginTop: 3,
    fontWeight: 600,
    color: "white",
  },
  card: {
    background: "var(--bg-surface)",
    borderRadius: 20,
    padding: "2.25rem 2rem",
    boxShadow: "0 30px 70px -20px rgba(0,0,0,0.35)",
  },
  eyebrow: {
    display: "inline-flex",
    alignItems: "center",
    gap: 6,
    fontSize: "0.7rem",
    fontWeight: 700,
    textTransform: "uppercase",
    letterSpacing: "0.08em",
    color: "var(--accent-primary)",
    background: "var(--accent-glow)",
    padding: "0.35rem 0.7rem",
    borderRadius: 999,
    marginBottom: "1rem",
  },
  title: {
    fontSize: "1.6rem",
    fontWeight: 800,
    color: "var(--text-primary)",
    letterSpacing: "-0.01em",
    marginBottom: "0.4rem",
  },
  subtitle: {
    fontSize: "0.88rem",
    color: "var(--text-secondary)",
    lineHeight: 1.55,
    marginBottom: "1.5rem",
  },
  fieldLabel: {
    fontSize: "0.78rem",
    fontWeight: 700,
    color: "var(--text-primary)",
  },
  input: {
    width: "100%",
    padding: "0.8rem 0.95rem",
    borderRadius: 11,
    border: "1.5px solid var(--border-hover)",
    fontSize: "0.9rem",
    color: "var(--text-primary)",
    background: "var(--bg-surface)",
    outline: "none",
    transition: "border-color 0.15s ease",
    fontFamily: "var(--font-sans)",
  },
  eyeBtn: {
    position: "absolute",
    top: "50%",
    right: 12,
    transform: "translateY(-50%)",
    background: "transparent",
    border: "none",
    color: "var(--text-secondary)",
    cursor: "pointer",
    padding: 4,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 6,
  },
  errorBox: {
    background: "#fef2f2",
    border: "1px solid #fecaca",
    color: "#b91c1c",
    fontSize: "0.82rem",
    padding: "0.7rem 0.9rem",
    borderRadius: 10,
    fontWeight: 600,
  },
  submitBtn: {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    padding: "0.85rem 1rem",
    borderRadius: 11,
    background: "var(--accent-primary)",
    color: "white",
    border: "none",
    fontSize: "0.9rem",
    fontWeight: 700,
    marginTop: "0.25rem",
    boxShadow: "0 10px 25px -10px rgba(67,24,255,0.55)",
    fontFamily: "var(--font-sans)",
  },
  secondaryBtn: {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    padding: "0.7rem 1rem",
    borderRadius: 11,
    background: "transparent",
    color: "var(--text-secondary)",
    border: "1px solid var(--border-hover)",
    fontSize: "0.82rem",
    fontWeight: 600,
    cursor: "pointer",
    fontFamily: "var(--font-sans)",
  },
};
