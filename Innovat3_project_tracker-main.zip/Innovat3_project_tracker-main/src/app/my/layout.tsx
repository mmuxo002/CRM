import { requireSession } from "@/lib/rbac";
import { redirect } from "next/navigation";

export default async function MyLayout({ children }: { children: React.ReactNode }) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN") redirect("/");
  return <>{children}</>;
}
