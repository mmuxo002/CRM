"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Clock, Coffee, Plus, CheckCircle2, AlertCircle, ChevronLeft, ChevronRight } from "lucide-react";

type Interval = {
  id: string;
  kind: "WORK" | "BREAK";
  source: "SYSTEM" | "USER" | "BACKFILL";
  startedAt: string;
  endedAt: string | null;
  note: string | null;
};

type SessionState = {
  session: {
    id: string;
    dateCST: string;
    startedAt: string;
    endedAt: string | null;
    endReason: string | null;
    status: "ACTIVE" | "ON_BREAK" | "ENDED";
    lastActivityAt: string;
  };
  totals: { workMs: number; breakMs: number; breakCount: number };
  openInterval: Interval | null;
};

type HistoryPayload = {
  weekOf: string;
  todayCST: string;
  totals: { workMs: number; breakMs: number; breakCount: number };
  states: (SessionState & { session: SessionState["session"] & { intervals: Interval[] } })[];
};

function fmtHMS(ms: number) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  return `${h}h ${String(m).padStart(2, "0")}m`;
}

function currentWeekKey() {
  const d = new Date();
  const c = new Date(d.getTime() - 6 * 3600 * 1000);
  const t = new Date(Date.UTC(c.getUTCFullYear(), c.getUTCMonth(), c.getUTCDate()));
  const dayNum = t.getUTCDay() || 7;
  t.setUTCDate(t.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil(((t.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
  return `${t.getUTCFullYear()}-W${String(weekNo).padStart(2, "0")}`;
}

function shiftWeek(weekKey: string, delta: number): string {
  const [y, w] = weekKey.split("-W").map((n) => parseInt(n, 10));
  // Build a date at ISO week 1 Monday of year y, then add (w-1)*7 + delta*7 days.
  const jan4 = new Date(Date.UTC(y, 0, 4));
  const dayOfWeek = jan4.getUTCDay() || 7;
  const mondayWeek1 = new Date(jan4);
  mondayWeek1.setUTCDate(jan4.getUTCDate() - (dayOfWeek - 1));
  const target = new Date(mondayWeek1);
  target.setUTCDate(mondayWeek1.getUTCDate() + (w - 1 + delta) * 7);
  const yearStart = new Date(Date.UTC(target.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil(((target.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
  return `${target.getUTCFullYear()}-W${String(weekNo).padStart(2, "0")}`;
}

export default function MyTimesheetPage() {
  const [weekOf, setWeekOf] = useState<string>(() => currentWeekKey());
  const [data, setData] = useState<HistoryPayload | null>(null);
  const [loading, setLoading] = useState(false);
  const [showBackfill, setShowBackfill] = useState(false);

  const load = useCallback(async (week: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/sales/time/history?weekOf=${week}`, { cache: "no-store" });
      if (res.ok) setData(await res.json());
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { load(weekOf); }, [weekOf, load]);

  const thisWeekKey = useMemo(() => currentWeekKey(), []);
  const isCurrentWeek = weekOf === thisWeekKey;
  const todaySession = data?.states.find((s) => s.session.dateCST === data.todayCST) ?? null;
  const canBackfill = todaySession !== null;

  return (
    <div className="animate-slide-up">
      <div className="row-between" style={{ marginBottom: "1.25rem" }}>
        <div>
          <h1 className="page-title" style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <Clock size={22} color="#f59e0b" /> My Timesheet
          </h1>
          <p className="page-subtitle">Your hours by day and week. Times shown in Central Standard Time.</p>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <button className="btn btn-secondary" onClick={() => setWeekOf(shiftWeek(weekOf, -1))} disabled={loading}>
            <ChevronLeft size={14} />
          </button>
          <div style={{ fontWeight: 700, fontSize: 14, minWidth: 120, textAlign: "center" }}>
            {isCurrentWeek ? "This Week" : weekOf.replace("-W", " · Week ")}
          </div>
          <button className="btn btn-secondary" onClick={() => setWeekOf(shiftWeek(weekOf, 1))} disabled={loading || isCurrentWeek}>
            <ChevronRight size={14} />
          </button>
        </div>
      </div>

      {/* Week totals */}
      <div className="card" style={{ marginBottom: "1.25rem" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 16 }}>
          <Stat label="Worked This Week" value={data ? fmtHMS(data.totals.workMs) : "—"} accent="#10b981" />
          <Stat label="Break Time" value={data ? fmtHMS(data.totals.breakMs) : "—"} accent="#f59e0b" />
          <Stat label="Breaks Taken" value={data ? String(data.totals.breakCount) : "—"} />
          <Stat label="Days Logged" value={data ? String(data.states.length) : "—"} />
        </div>
      </div>

      {/* Backfill row */}
      {isCurrentWeek && canBackfill && (
        <div className="card" style={{ marginBottom: "1.25rem" }}>
          <div className="row-between">
            <div>
              <div style={{ fontWeight: 800, fontSize: 14, display: "flex", alignItems: "center", gap: 8 }}>
                <Coffee size={16} color="#f59e0b" /> Took a break you didn't log?
              </div>
              <div style={{ fontSize: 12, color: "var(--text-secondary)", marginTop: 4 }}>
                Record a break you took earlier today. This only affects today's session — talk to Juan for anything else.
              </div>
            </div>
            <button className="btn btn-primary" onClick={() => setShowBackfill(true)}>
              <Plus size={14} /> Add a Break
            </button>
          </div>
        </div>
      )}

      {/* Day cards */}
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {loading && !data && <div className="card"><span style={{ color: "var(--text-secondary)" }}>Loading…</span></div>}
        {data && data.states.length === 0 && (
          <div className="card" style={{ textAlign: "center", padding: "2rem" }}>
            <div style={{ color: "var(--text-secondary)" }}>No sessions logged this week.</div>
          </div>
        )}
        {data?.states.map((st) => (
          <DayCard key={st.session.id} state={st} isToday={st.session.dateCST === data.todayCST} />
        ))}
      </div>

      {showBackfill && todaySession && (
        <BackfillBreakModal
          dateCST={todaySession.session.dateCST}
          onClose={() => setShowBackfill(false)}
          onSaved={() => { setShowBackfill(false); load(weekOf); }}
        />
      )}
    </div>
  );
}

function Stat({ label, value, accent }: { label: string; value: string; accent?: string }) {
  return (
    <div>
      <div style={{ fontSize: 11, color: "var(--text-secondary)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.05em" }}>{label}</div>
      <div style={{ fontSize: 24, fontWeight: 900, fontVariantNumeric: "tabular-nums", marginTop: 4, color: accent ?? "var(--text-primary)" }}>{value}</div>
    </div>
  );
}

function DayCard({ state, isToday }: { state: HistoryPayload["states"][number]; isToday: boolean }) {
  const { session, totals } = state;
  const status = session.status;
  const dayLabel = new Date(session.dateCST + "T12:00:00").toLocaleDateString(undefined, { weekday: "long", month: "short", day: "numeric" });

  return (
    <div className="card">
      <div className="row-between" style={{ marginBottom: 12 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div>
            <div style={{ fontWeight: 800, fontSize: 15 }}>
              {dayLabel}
              {isToday && <span style={{ marginLeft: 8, fontSize: 10, padding: "2px 6px", background: "#f59e0b", color: "white", borderRadius: 4, verticalAlign: "middle", fontWeight: 800, letterSpacing: "0.05em" }}>TODAY</span>}
            </div>
            <div style={{ fontSize: 12, color: "var(--text-secondary)", marginTop: 2 }}>
              Started {new Date(session.startedAt).toLocaleTimeString()}
              {session.endedAt && ` · Ended ${new Date(session.endedAt).toLocaleTimeString()}`}
              {session.endReason && ` · ${endReasonLabel(session.endReason)}`}
            </div>
          </div>
        </div>
        <StatusPill status={status} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, marginBottom: 12 }}>
        <Mini label="Worked" value={fmtHMS(totals.workMs)} accent="#10b981" />
        <Mini label="Break" value={fmtHMS(totals.breakMs)} accent="#f59e0b" />
        <Mini label="Breaks" value={String(totals.breakCount)} />
      </div>

      {session.intervals.length > 0 && (
        <details>
          <summary style={{ fontSize: 12, fontWeight: 700, color: "var(--text-secondary)", cursor: "pointer", letterSpacing: "0.04em" }}>INTERVALS ({session.intervals.length})</summary>
          <div style={{ display: "flex", flexDirection: "column", gap: 4, marginTop: 8 }}>
            {session.intervals.map((iv) => {
              const start = new Date(iv.startedAt);
              const end = iv.endedAt ? new Date(iv.endedAt) : null;
              const dur = end ? end.getTime() - start.getTime() : 0;
              return (
                <div key={iv.id} style={{ display: "grid", gridTemplateColumns: "80px 80px 1fr 1fr 80px", gap: 8, padding: "0.4rem 0.6rem", background: "var(--bg-base)", borderRadius: 6, fontSize: 12, alignItems: "center" }}>
                  <span style={{ fontWeight: 800, color: iv.kind === "WORK" ? "#10b981" : "#f59e0b" }}>{iv.kind}</span>
                  <span style={{ fontSize: 10, fontWeight: 700, color: "var(--text-secondary)" }}>{iv.source}</span>
                  <span>{start.toLocaleTimeString()}</span>
                  <span>{end ? end.toLocaleTimeString() : "…"}</span>
                  <span style={{ textAlign: "right", fontVariantNumeric: "tabular-nums", fontWeight: 700 }}>{end ? fmtHMS(dur) : "open"}</span>
                </div>
              );
            })}
          </div>
        </details>
      )}
    </div>
  );
}

function Mini({ label, value, accent }: { label: string; value: string; accent?: string }) {
  return (
    <div style={{ background: "var(--bg-base)", padding: "0.5rem 0.6rem", borderRadius: 8 }}>
      <div style={{ fontSize: 10, color: "var(--text-secondary)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.05em" }}>{label}</div>
      <div style={{ fontSize: 16, fontWeight: 800, fontVariantNumeric: "tabular-nums", marginTop: 2, color: accent ?? "var(--text-primary)" }}>{value}</div>
    </div>
  );
}

function StatusPill({ status }: { status: "ACTIVE" | "ON_BREAK" | "ENDED" }) {
  const meta = status === "ACTIVE"
    ? { label: "Working", color: "#10b981", bg: "#d1fae5" }
    : status === "ON_BREAK"
    ? { label: "On Break", color: "#f59e0b", bg: "#fef3c7" }
    : { label: "Ended", color: "#64748b", bg: "#f1f5f9" };
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "4px 10px", borderRadius: 999, fontSize: 11, fontWeight: 800, color: meta.color, background: meta.bg }}>
      {status === "ENDED" ? <CheckCircle2 size={12} /> : <span style={{ width: 6, height: 6, borderRadius: "50%", background: meta.color }} />}
      {meta.label}
    </span>
  );
}

function endReasonLabel(r: string): string {
  switch (r) {
    case "MANUAL_END": return "Ended by you";
    case "AUTO_MIDNIGHT": return "Rolled past midnight";
    case "AUTO_INACTIVE_EOD": return "Ended by system (inactive)";
    default: return r;
  }
}

function BackfillBreakModal({ dateCST, onClose, onSaved }: { dateCST: string; onClose: () => void; onSaved: () => void }) {
  const [startTime, setStartTime] = useState("12:00");
  const [endTime, setEndTime] = useState("13:00");
  const [note, setNote] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const startAt = new Date(`${dateCST}T${startTime}:00`);
      const endAt = new Date(`${dateCST}T${endTime}:00`);
      const res = await fetch("/api/sales/time/backfill-break", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ startAt: startAt.toISOString(), endAt: endAt.toISOString(), note: note || undefined }),
      });
      const body = await res.json();
      if (!res.ok) { setError(body?.error || "Could not save break"); return; }
      onSaved();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unknown error");
    } finally { setSubmitting(false); }
  }

  return (
    <div style={overlay} onClick={onClose}>
      <form onSubmit={submit} style={modal} onClick={(e) => e.stopPropagation()}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 }}>
          <div>
            <div style={{ fontSize: 11, color: "var(--text-secondary)", fontWeight: 800, letterSpacing: "0.08em", textTransform: "uppercase" }}>Add a Break</div>
            <div style={{ fontSize: 18, fontWeight: 800 }}>{dateCST}</div>
          </div>
          <button type="button" onClick={onClose} style={{ background: "transparent", border: "none", fontSize: 24, cursor: "pointer", color: "var(--text-secondary)", lineHeight: 1 }}>×</button>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
          <label style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            <span style={{ fontSize: 12, fontWeight: 700 }}>Start</span>
            <input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} required style={inputStyle} />
          </label>
          <label style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            <span style={{ fontSize: 12, fontWeight: 700 }}>End</span>
            <input type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} required style={inputStyle} />
          </label>
        </div>

        <label style={{ display: "flex", flexDirection: "column", gap: 6, marginBottom: 16 }}>
          <span style={{ fontSize: 12, fontWeight: 700 }}>Note (optional)</span>
          <input type="text" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Lunch, errand, etc." style={inputStyle} />
        </label>

        <div style={{ fontSize: 11, color: "var(--text-secondary)", display: "flex", alignItems: "flex-start", gap: 6, marginBottom: 16 }}>
          <AlertCircle size={14} style={{ flexShrink: 0, marginTop: 1 }} />
          <span>The break window must fall inside one of today's logged work intervals. If it crosses a break you already took, talk to Juan to have it adjusted.</span>
        </div>

        {error && <div style={{ color: "#b91c1c", background: "#fef2f2", padding: "0.6rem 0.8rem", borderRadius: 8, fontSize: 12, marginBottom: 12 }}>{error}</div>}

        <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
          <button type="button" onClick={onClose} className="btn btn-secondary" disabled={submitting}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={submitting}>{submitting ? "Saving…" : "Save Break"}</button>
        </div>
      </form>
    </div>
  );
}

const overlay: React.CSSProperties = { position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 80 };
const modal: React.CSSProperties = { background: "var(--bg-surface, white)", borderRadius: 14, padding: "1.5rem", width: "min(440px, 92vw)", boxShadow: "0 30px 80px -20px rgba(0,0,0,0.4)" };
const inputStyle: React.CSSProperties = { padding: "0.6rem 0.8rem", borderRadius: 8, border: "1.5px solid var(--border-hover, #cbd5e1)", fontSize: 14, fontFamily: "var(--font-sans)" };
