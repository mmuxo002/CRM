"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { DollarSign, TrendingUp, Clock, CheckCircle2 } from "lucide-react";

type Commission = {
  id: string;
  serviceType: string | null;
  source: string | null;
  onboardingAmount: number;
  rate: number;
  commissionAmount: number;
  earnedAt: string;
  dateCST: string;
  weekOfCST: string;
  monthOfCST: string;
  status: "PENDING" | "PAID" | "VOID";
  paidAt: string | null;
  notes: string | null;
  contact: { id: string; name: string; email: string | null } | null;
  lead: { id: string; name: string; source: string | null } | null;
  project: { id: string; name: string; serviceType: string | null } | null;
};

type Payload = {
  thisWeek: string;
  thisMonth: string;
  filter: { weekOf: string | null; monthOf: string | null };
  totals: { onboardingTotal: number; commissionTotal: number; paidTotal: number; pendingTotal: number };
  commissions: Commission[];
};

const fmtUSD = (n: number) => `$${n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

export default function MyCommissionsPage() {
  const [view, setView] = useState<"recent" | "week" | "month">("recent");
  const [data, setData] = useState<Payload | null>(null);
  const [loading, setLoading] = useState(false);

  const params = useMemo(() => {
    const current = new URLSearchParams();
    if (view === "week") {
      const d = new Date();
      const c = new Date(d.getTime() - 6 * 3600 * 1000);
      const t = new Date(Date.UTC(c.getUTCFullYear(), c.getUTCMonth(), c.getUTCDate()));
      const dayNum = t.getUTCDay() || 7;
      t.setUTCDate(t.getUTCDate() + 4 - dayNum);
      const yearStart = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
      const weekNo = Math.ceil(((t.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
      current.set("weekOf", `${t.getUTCFullYear()}-W${String(weekNo).padStart(2, "0")}`);
    }
    if (view === "month") {
      const d = new Date();
      const c = new Date(d.getTime() - 6 * 3600 * 1000);
      current.set("monthOf", `${c.getUTCFullYear()}-${String(c.getUTCMonth() + 1).padStart(2, "0")}`);
    }
    return current.toString();
  }, [view]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/sales/commissions/me${params ? `?${params}` : ""}`, { cache: "no-store" });
      if (res.ok) setData(await res.json());
    } finally { setLoading(false); }
  }, [params]);

  useEffect(() => { load(); }, [load]);

  return (
    <div className="animate-slide-up">
      <div className="row-between" style={{ marginBottom: "1.25rem" }}>
        <div>
          <h1 className="page-title" style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <DollarSign size={22} color="#10b981" /> My Commissions
          </h1>
          <p className="page-subtitle">Commissions earned from your closed deals. Questions? Contact Juan.</p>
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          <TabButton active={view === "recent"} onClick={() => setView("recent")}>Recent</TabButton>
          <TabButton active={view === "week"} onClick={() => setView("week")}>This Week</TabButton>
          <TabButton active={view === "month"} onClick={() => setView("month")}>This Month</TabButton>
        </div>
      </div>

      <div className="card" style={{ marginBottom: "1.25rem" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 16 }}>
          <Stat label="Total Commission" value={data ? fmtUSD(data.totals.commissionTotal) : "—"} accent="#10b981" icon={<TrendingUp size={14} />} />
          <Stat label="Paid Out" value={data ? fmtUSD(data.totals.paidTotal) : "—"} accent="#059669" icon={<CheckCircle2 size={14} />} />
          <Stat label="Pending" value={data ? fmtUSD(data.totals.pendingTotal) : "—"} accent="#f59e0b" icon={<Clock size={14} />} />
          <Stat label="Onboarding Volume" value={data ? fmtUSD(data.totals.onboardingTotal) : "—"} />
        </div>
      </div>

      <div className="card">
        <h2 style={{ fontSize: "1rem", fontWeight: 800, marginBottom: "0.75rem" }}>Commissions</h2>
        {loading && !data && <div style={{ color: "var(--text-secondary)" }}>Loading…</div>}
        {data && data.commissions.length === 0 && (
          <div style={{ textAlign: "center", padding: "2rem", color: "var(--text-secondary)" }}>
            No commissions in this range yet.
          </div>
        )}
        {data && data.commissions.length > 0 && (
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
              <thead>
                <tr style={{ borderBottom: "1px solid var(--border-color)", textAlign: "left" }}>
                  <Th>Earned</Th>
                  <Th>Contact / Lead</Th>
                  <Th>Service</Th>
                  <Th>Source</Th>
                  <Th style={{ textAlign: "right" }}>Onboarding</Th>
                  <Th style={{ textAlign: "right" }}>Rate</Th>
                  <Th style={{ textAlign: "right" }}>Commission</Th>
                  <Th style={{ textAlign: "center" }}>Status</Th>
                </tr>
              </thead>
              <tbody>
                {data.commissions.map((c) => (
                  <tr key={c.id} style={{ borderBottom: "1px solid var(--border-color)" }}>
                    <Td>{new Date(c.earnedAt).toLocaleDateString()}</Td>
                    <Td>
                      <div style={{ fontWeight: 700 }}>{c.contact?.name || c.lead?.name || "—"}</div>
                      {c.project && <div style={{ fontSize: 11, color: "var(--text-secondary)" }}>{c.project.name}</div>}
                    </Td>
                    <Td>{c.serviceType || c.project?.serviceType || "—"}</Td>
                    <Td>{c.source || c.lead?.source || "—"}</Td>
                    <Td style={{ textAlign: "right", fontVariantNumeric: "tabular-nums" }}>{fmtUSD(c.onboardingAmount)}</Td>
                    <Td style={{ textAlign: "right", fontVariantNumeric: "tabular-nums", color: "var(--text-secondary)" }}>{(c.rate * 100).toFixed(1)}%</Td>
                    <Td style={{ textAlign: "right", fontVariantNumeric: "tabular-nums", fontWeight: 800, color: "#10b981" }}>{fmtUSD(c.commissionAmount)}</Td>
                    <Td style={{ textAlign: "center" }}><StatusPill status={c.status} /></Td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

function Stat({ label, value, accent, icon }: { label: string; value: string; accent?: string; icon?: React.ReactNode }) {
  return (
    <div>
      <div style={{ fontSize: 11, color: "var(--text-secondary)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.05em", display: "flex", alignItems: "center", gap: 6 }}>
        {icon} {label}
      </div>
      <div style={{ fontSize: 24, fontWeight: 900, fontVariantNumeric: "tabular-nums", marginTop: 4, color: accent ?? "var(--text-primary)" }}>{value}</div>
    </div>
  );
}

function TabButton({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button onClick={onClick} style={{
      padding: "0.5rem 0.9rem",
      borderRadius: 8,
      border: active ? "none" : "1px solid var(--border-color)",
      background: active ? "var(--accent-primary, #4318ff)" : "var(--bg-surface)",
      color: active ? "white" : "var(--text-primary)",
      fontSize: 12,
      fontWeight: 700,
      cursor: "pointer",
    }}>{children}</button>
  );
}

function Th({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) {
  return <th style={{ padding: "0.5rem 0.6rem", fontSize: 11, fontWeight: 800, color: "var(--text-secondary)", textTransform: "uppercase", letterSpacing: "0.05em", ...style }}>{children}</th>;
}
function Td({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) {
  return <td style={{ padding: "0.6rem 0.6rem", verticalAlign: "top", ...style }}>{children}</td>;
}

function StatusPill({ status }: { status: "PENDING" | "PAID" | "VOID" }) {
  const meta = status === "PAID"
    ? { color: "#059669", bg: "#d1fae5" }
    : status === "PENDING"
    ? { color: "#f59e0b", bg: "#fef3c7" }
    : { color: "#64748b", bg: "#f1f5f9" };
  return (
    <span style={{ padding: "3px 10px", borderRadius: 999, fontSize: 10, fontWeight: 800, color: meta.color, background: meta.bg, letterSpacing: "0.04em" }}>{status}</span>
  );
}
