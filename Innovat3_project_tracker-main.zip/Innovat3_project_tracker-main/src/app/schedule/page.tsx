import { requireSession } from "@/lib/rbac";
import { db } from "@/lib/db";
import { ScheduleCalendar } from "@/components/schedule/ScheduleCalendar";

export const dynamic = "force-dynamic";

export default async function SchedulePage({ searchParams }: { searchParams: Promise<{ team?: string }> }) {
  await requireSession();
  const { team: teamParam } = await searchParams;

  const attendees = await db.user.findMany({
    where: { isActive: true },
    select: { id: true, name: true, email: true, image: true },
    orderBy: { name: "asc" },
  });

  const validTeams = new Set(["APPS", "CRM", "SALES"]);
  const siloed = teamParam && validTeams.has(teamParam) ? teamParam as "APPS" | "CRM" | "SALES" : null;
  const defaultTeam = siloed || "ALL";

  return (
    <div className="animate-slide-up" style={{ padding: "1.5rem" }}>
      <ScheduleCalendar
        defaultTeam={defaultTeam}
        lockedTeam={siloed}
        attendees={attendees.map((a) => ({ id: a.id, name: a.name, email: a.email, image: a.image }))}
      />
    </div>
  );
}
