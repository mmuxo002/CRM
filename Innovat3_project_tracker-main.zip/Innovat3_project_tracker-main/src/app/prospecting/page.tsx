import { requireSession } from "@/lib/rbac";
import { db } from "@/lib/db";
import Link from "next/link";
import { Plus, Flame, Trophy, Target, Zap, FolderSearch, ArrowRight } from "lucide-react";

export const dynamic = "force-dynamic";

const STAGES = [
  { id: "PROSPECT", label: "Prospect", color: "#3b82f6" },
  { id: "OUTREACHED", label: "Outreached", color: "#10b981" },
  { id: "SCHEDULED", label: "Scheduled Appt", color: "#8b5cf6" },
  { id: "CLOSED", label: "Closed", color: "#f59e0b" },
  { id: "NOT_INTERESTED", label: "Not Interested", color: "#ef4444" },
];

const QUARTER_GOAL = 500_000;

export default async function SalesCommandCenter() {
  await requireSession();

  const [leads, hot, interestedCount, stageCounts, deals, reps, recentProjects, recentPipelineMoves] = await Promise.all([
    db.lead.findMany({ orderBy: { qualificationScore: "desc" }, include: { company: true, assignee: true, salesProject: { select: { niche: true } } }, take: 6 }),
    db.lead.count({ where: { qualificationScore: { gte: 70 } } }),
    db.lead.count({ where: { status: "OUTREACHED" } }),
    Promise.all(STAGES.map((s) => db.lead.count({ where: { status: s.id } }))),
    db.deal.findMany({ include: { company: true } }),
    db.user.findMany({ where: { role: { in: ["SALES", "ADMIN"] } }, include: { leads: true } }),
    db.salesProject.findMany({ orderBy: { createdAt: "desc" }, take: 8, include: { creator: true } }),
    db.lead.findMany({
      where: { status: { in: ["PROSPECT", "OUTREACHED", "SCHEDULED", "CLOSED", "NOT_INTERESTED"] }, salesProjectId: { not: null } },
      orderBy: { updatedAt: "desc" },
      take: 8,
      include: { salesProject: true },
    }),
  ]);

  // Build unified activity feed from real pipeline events
  type FeedItem = { id: string; kind: "project_created" | "pipeline_move"; title: string; subtitle: string; time: Date; initial: string };
  const feedItems: FeedItem[] = [
    ...recentProjects.map((p) => ({
      id: `proj-${p.id}`,
      kind: "project_created" as const,
      title: `New sales project created`,
      subtitle: `${p.name} · ${p.niche} · ${p.targetLocation}`,
      time: p.createdAt,
      initial: (p.creator?.name || p.name || "S").slice(0, 1).toUpperCase(),
    })),
    ...recentPipelineMoves.map((l) => ({
      id: `move-${l.id}`,
      kind: "pipeline_move" as const,
      title: `${l.name} moved to ${l.status.replace(/_/g, " ")}`,
      subtitle: l.salesProject?.name || "Sales Pipeline",
      time: l.updatedAt,
      initial: l.name.slice(0, 1).toUpperCase(),
    })),
  ].sort((a, b) => b.time.getTime() - a.time.getTime()).slice(0, 8);

  const pipelineValue = deals.reduce((s, d) => s + d.value, 0);
  const wonValue = deals.filter((d) => d.stage === "CLOSED_WON").reduce((s, d) => s + d.value, 0);
  const forecast = deals.reduce((s, d) => s + d.value * (d.probability / 100), 0);
  const quotaPct = Math.min(100, Math.round((wonValue / QUARTER_GOAL) * 100));
  const avgDealSize = deals.length ? pipelineValue / deals.length : 0;
  const winRate = deals.length ? Math.round((deals.filter((d) => d.stage === "CLOSED_WON").length / deals.length) * 100) : 0;

  const maxStage = Math.max(...stageCounts, 1);

  const leaderboard = reps
    .map((r) => ({
      id: r.id,
      name: r.name || r.email,
      image: r.image,
      deals: r.leads.filter((l) => l.status === "SCHEDULED" || l.status === "CLOSED").length,
      pipeline: r.leads.reduce((s, l) => s + (l.projectedValue || 0), 0),
    }))
    .sort((a, b) => b.pipeline - a.pipeline)
    .slice(0, 5);
  const maxRepPipe = Math.max(...leaderboard.map((r) => r.pipeline), 1);

  const fmt = (n: number) => n >= 1_000_000 ? `$${(n / 1_000_000).toFixed(1)}M` : n >= 1_000 ? `$${(n / 1_000).toFixed(1)}K` : `$${n.toFixed(0)}`;

  return (
    <div className="animate-slide-up">
      <div className="row-between" style={{ marginBottom: "1.25rem" }}>
        <div>
          <h1 className="page-title" style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <span className="dept-dot" style={{ background: "#f59e0b", width: 12, height: 12 }} />
            Sales · Cockpit
          </h1>
          <p className="page-subtitle">Quota, funnel, and hot leads — everything you need to close.</p>
        </div>
        <div className="flex-gap">
          <Link href="/prospecting/projects/new" className="btn btn-primary" style={{ display: "flex", alignItems: "center", gap: 6 }}><Plus size={14} /> New Lead</Link>
        </div>
      </div>

      {/* Hero: Quota + forecast KPIs */}
      <div className="sales-hero">
        <div style={{ position: "relative", zIndex: 1 }}>
          <div className="hero-label">Q2 Quota Progress</div>
          <div className="hero-value">{fmt(wonValue)} <span style={{ fontSize: "1rem", opacity: 0.7, fontWeight: 600 }}>/ {fmt(QUARTER_GOAL)}</span></div>
          <div className="hero-sub">{quotaPct}% to goal · Forecast {fmt(forecast)} · {deals.length} active deals</div>
          <div className="quota-bar"><div className="quota-fill" style={{ width: `${quotaPct}%` }} /></div>
          <div style={{ display: "flex", gap: "0.5rem", marginTop: "1rem", flexWrap: "wrap" }}>
            <span style={{ background: "rgba(255,255,255,0.18)", padding: "0.35rem 0.7rem", borderRadius: 999, fontSize: "0.75rem", fontWeight: 700 }}><Flame size={12} style={{ display: "inline", marginRight: 4 }} />{hot} hot</span>
            <span style={{ background: "rgba(255,255,255,0.18)", padding: "0.35rem 0.7rem", borderRadius: 999, fontSize: "0.75rem", fontWeight: 700 }}><Target size={12} style={{ display: "inline", marginRight: 4 }} />{interestedCount} outreached</span>
            <span style={{ background: "rgba(255,255,255,0.18)", padding: "0.35rem 0.7rem", borderRadius: 999, fontSize: "0.75rem", fontWeight: 700 }}><Target size={12} style={{ display: "inline", marginRight: 4 }} />{winRate}% win rate</span>
          </div>
        </div>
        <div className="hero-kpis">
          <div className="hero-kpi">
            <div className="k-label">Pipeline Value</div>
            <div className="k-value">{fmt(pipelineValue)}</div>
            <div className="k-delta">Across {deals.length} deals</div>
          </div>
          <div className="hero-kpi">
            <div className="k-label">Weighted Forecast</div>
            <div className="k-value">{fmt(forecast)}</div>
            <div className="k-delta">Probability-adjusted</div>
          </div>
          <div className="hero-kpi">
            <div className="k-label">Avg Deal Size</div>
            <div className="k-value">{fmt(avgDealSize)}</div>
            <div className="k-delta">Rolling 90d</div>
          </div>
          <div className="hero-kpi">
            <div className="k-label">Leads in Pipeline</div>
            <div className="k-value">{stageCounts.reduce((a, b) => a + b, 0)}</div>
            <div className="k-delta">Across all stages</div>
          </div>
        </div>
      </div>

      {/* Funnel + Hot leads */}
      <div className="sales-split">
        <div className="card">
          <div className="row-between" style={{ marginBottom: "0.5rem" }}>
            <h2 style={{ fontSize: "1rem", fontWeight: 800 }}>Sales Funnel</h2>
            <Link href="/prospecting/pipeline" style={{ fontSize: "0.8rem", color: "#f59e0b", fontWeight: 700 }}>Open Board →</Link>
          </div>
          <div className="funnel">
            {STAGES.map((s, i) => {
              const pct = stageCounts[i] / maxStage;
              const width = 55 + pct * 45;
              const conv = i > 0 && stageCounts[i - 1] > 0 ? Math.round((stageCounts[i] / stageCounts[i - 1]) * 100) : null;
              return (
                <div key={s.id}>
                  {conv !== null && <div className="funnel-conv">↓ {conv}% conversion</div>}
                  <div className="funnel-stage" style={{ width: `${width}%`, background: `linear-gradient(90deg, ${s.color}, ${s.color}dd)` }}>
                    <span className="stage-name">{s.label}</span>
                    <span className="stage-count">{stageCounts[i]}</span>
                  </div>
                </div>
              );
            })}
          </div>
          <div style={{ marginTop: "1rem", padding: "0.75rem", background: "var(--bg-base)", borderRadius: 10, fontSize: "0.75rem", color: "var(--text-secondary)", display: "flex", justifyContent: "space-between" }}>
            <span><strong style={{ color: "var(--text-primary)" }}>Total in pipeline:</strong> {stageCounts.reduce((a, b) => a + b, 0)} leads</span>
            <span><strong style={{ color: "var(--text-primary)" }}>Top → Close:</strong> {stageCounts[0] ? Math.round((stageCounts[4] / stageCounts[0]) * 100) : 0}%</span>
          </div>
        </div>

        <div className="card">
          <div className="row-between" style={{ marginBottom: "0.75rem" }}>
            <h2 style={{ fontSize: "1rem", fontWeight: 800, display: "flex", alignItems: "center", gap: 6 }}><Flame size={16} color="#f59e0b" /> Hot Leads Queue</h2>
            <Link href="/prospecting/contacts" style={{ fontSize: "0.8rem", color: "#f59e0b", fontWeight: 700 }}>View All →</Link>
          </div>
          {leads.map((l) => {
            const color = l.score >= 80 ? "linear-gradient(135deg, #ef4444, #f59e0b)" : l.score >= 60 ? "linear-gradient(135deg, #f59e0b, #fbbf24)" : "linear-gradient(135deg, #94a3b8, #cbd5e1)";
            return (
              <Link key={l.id} href={`/prospecting/contacts/${l.id}`} className="hot-lead-row">
                <div className="score-chip" style={{ background: color }}>{l.score}</div>
                <div className="lead-info">
                  <div className="lead-name">{l.name}</div>
                  <div className="lead-meta">{l.company?.name || "—"} · {l.title || "Prospect"}</div>
                </div>
                <span className={`badge ${l.status === "OUTREACHED" ? "badge-green" : l.status === "SCHEDULED" ? "badge-purple" : l.status === "NOT_INTERESTED" ? "badge-red" : l.status === "CLOSED" ? "badge-orange" : "badge-blue"}`} style={{ fontSize: 10 }}>{l.status.replace(/_/g, " ")}</span>
              </Link>
            );
          })}
        </div>
      </div>

      {/* Leaderboard + Today's activity */}
      <div className="sales-split-2">
        <div className="card">
          <div className="row-between" style={{ marginBottom: "0.75rem" }}>
            <h2 style={{ fontSize: "1rem", fontWeight: 800, display: "flex", alignItems: "center", gap: 6 }}><Trophy size={16} color="#f59e0b" /> Rep Leaderboard</h2>
            <span style={{ fontSize: "0.75rem", color: "var(--text-muted)" }}>This quarter</span>
          </div>
          {leaderboard.length === 0 && <div style={{ color: "var(--text-muted)", fontSize: "0.85rem" }}>No reps found.</div>}
          {leaderboard.map((r, i) => (
            <div key={r.id} className="rep-row">
              <div className={`rep-rank ${i === 0 ? "top" : ""}`}>{i + 1}</div>
              {r.image ? <img src={r.image} alt={r.name || ""} /> : <div className="avatar-fallback">{(r.name || "?").slice(0, 1).toUpperCase()}</div>}
              <div style={{ minWidth: 0, flex: "0 0 110px" }}>
                <div className="rep-name" style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{r.name}</div>
                <div className="rep-meta">{r.deals} converted</div>
              </div>
              <div className="rep-bar"><div className="rep-bar-fill" style={{ width: `${(r.pipeline / maxRepPipe) * 100}%` }} /></div>
              <div className="rep-value">{fmt(r.pipeline)}</div>
            </div>
          ))}
        </div>

        <div className="card">
          <div className="row-between" style={{ marginBottom: "0.75rem" }}>
            <h2 style={{ fontSize: "1rem", fontWeight: 800, display: "flex", alignItems: "center", gap: 6 }}><Zap size={16} color="#f59e0b" /> Live Activity</h2>
            <Link href="/prospecting/pipeline" style={{ fontSize: "0.8rem", color: "#f59e0b", fontWeight: 700 }}>Pipeline →</Link>
          </div>
          {feedItems.length === 0 && <div style={{ color: "var(--text-muted)", fontSize: "0.85rem" }}>No recent pipeline activity yet.</div>}
          {feedItems.map((item) => (
            <div key={item.id} className="activity-item">
              <div style={{
                width: 36, height: 36, borderRadius: "50%", flexShrink: 0,
                background: item.kind === "project_created"
                  ? "linear-gradient(135deg, #3b82f6, #6366f1)"
                  : "linear-gradient(135deg, #f59e0b, #ef4444)",
                color: "white", display: "flex", alignItems: "center", justifyContent: "center",
                fontWeight: 800, fontSize: "0.8rem",
              }}>
                {item.kind === "project_created" ? <FolderSearch size={16} /> : item.initial}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 700, fontSize: "0.85rem", display: "flex", alignItems: "center", gap: 6 }}>
                  {item.title}
                  {item.kind === "pipeline_move" && <ArrowRight size={12} style={{ color: "#f59e0b" }} />}
                </div>
                <div style={{ fontSize: "0.8rem", color: "var(--text-secondary)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                  {item.subtitle}
                </div>
              </div>
              <div style={{ fontSize: "0.7rem", color: "var(--text-muted)", whiteSpace: "nowrap" }}>{timeAgo(item.time)}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function timeAgo(d: Date) {
  const ms = Date.now() - d.getTime();
  const m = Math.floor(ms / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}
