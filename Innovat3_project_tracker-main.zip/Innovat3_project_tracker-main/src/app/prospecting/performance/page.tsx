import { requireAdmin } from "@/lib/rbac";
import { db } from "@/lib/db";
import { parseAccess } from "@/lib/departments";
import { commissionTotalsForUsers, thisMonthCST, thisWeekCST, timesheetForUsers } from "@/lib/sales/timesheet";
import { PerformanceDashboard } from "@/components/admin/PerformanceDashboard";

export const dynamic = "force-dynamic";

export default async function AdminPerformancePage() {
  await requireAdmin();

  const users = await db.user.findMany({
    where: { isActive: true },
    select: { id: true, name: true, email: true, image: true, role: true, accessDepartments: true, isActive: true, lastSeenAt: true },
    orderBy: [{ name: "asc" }],
  });
  const reps = users.filter((u) => {
    if (!u.isActive) return false;
    if (u.role === "SALES") return true;
    const access = parseAccess(u.accessDepartments);
    if (access === "all") return u.role !== "ADMIN";
    return access.has("sales");
  });

  const weekOf = thisWeekCST();
  const monthOf = thisMonthCST();
  const period = { kind: "week" as const, weekOf };
  const repIds = reps.map((u) => u.id);

  const [hours, commissions] = await Promise.all([
    timesheetForUsers(repIds, period),
    commissionTotalsForUsers(repIds, period),
  ]);

  const rows = reps.map((u) => ({
    id: u.id,
    name: u.name,
    email: u.email,
    image: u.image,
    role: u.role,
    lastSeenAt: u.lastSeenAt ? u.lastSeenAt.toISOString() : null,
    hours: hours.get(u.id)!,
    commissions: commissions.get(u.id)!,
  }));

  const totals = rows.reduce(
    (acc, r) => {
      acc.workMs += r.hours.workMs;
      acc.breakMs += r.hours.breakMs;
      acc.sessionCount += r.hours.sessionCount;
      acc.commissionTotal += r.commissions.commissionTotal;
      acc.paidTotal += r.commissions.paidTotal;
      acc.pendingTotal += r.commissions.pendingTotal;
      acc.onboardingTotal += r.commissions.onboardingTotal;
      acc.commissionCount += r.commissions.count;
      return acc;
    },
    { workMs: 0, breakMs: 0, sessionCount: 0, commissionTotal: 0, paidTotal: 0, pendingTotal: 0, onboardingTotal: 0, commissionCount: 0 },
  );

  return <PerformanceDashboard initial={{ ok: true, period, thisWeek: weekOf, thisMonth: monthOf, rows, totals }} />;
}
