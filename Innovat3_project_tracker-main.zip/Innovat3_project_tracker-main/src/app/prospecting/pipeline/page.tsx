import { requireRole } from "@/lib/rbac";
import { db } from "@/lib/db";
import { KanbanBoard, type KanbanColumn } from "@/components/kanban/KanbanBoard";

export const dynamic = "force-dynamic";

const STAGES = [
  { id: "PROSPECT", title: "Prospect", color: "#3b82f6" },
  { id: "OUTREACHED", title: "Outreached", color: "#10b981" },
  { id: "SCHEDULED", title: "Scheduled Appointment", color: "#8b5cf6" },
  { id: "CLOSED", title: "Closed", color: "#f59e0b" },
  { id: "NOT_INTERESTED", title: "Not Interested", color: "#ef4444" },
];

export default async function SalesPipeline() {
  await requireRole("SALES");
  const leads = await db.lead.findMany({
    where: { status: { in: STAGES.map((s) => s.id) } },
    include: { assignee: true, company: true },
    orderBy: { updatedAt: "desc" },
  });

  const columns: KanbanColumn[] = STAGES.map((s) => ({
    id: s.id,
    title: s.title,
    color: s.color,
    cards: leads.filter((l) => l.status === s.id).map((l) => ({
      id: l.id,
      title: l.company?.name || l.name,
      description: l.name,
      source: l.source,
      probability: l.probability,
      projectedValue: l.projectedValue,
      dueDate: l.nextAction?.toISOString() ?? null,
      assignees: l.assignee ? [{ id: l.assignee.id, name: l.assignee.name, image: l.assignee.image }] : [],
      progressBarMode: "probability" as const,
      href: `/prospecting/contacts/${l.id}`,
    })),
  }));

  return (
    <div className="animate-slide-up">
      <div className="row-between" style={{ marginBottom: "1.5rem" }}>
        <div>
          <h1 className="page-title">Sales Pipeline</h1>
          <p className="page-subtitle">Drag leads between stages — Prospect → Outreached → Scheduled → Closed</p>
        </div>
      </div>
      <KanbanBoard columns={columns} moveEndpoint="/api/leads/move" />
    </div>
  );
}
