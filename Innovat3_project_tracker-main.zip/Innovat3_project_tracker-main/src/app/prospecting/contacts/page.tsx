import { requireRole } from "@/lib/rbac";
import { db } from "@/lib/db";
import ContactsList from "./ContactsList";

export const dynamic = "force-dynamic";

export default async function ContactsListPage() {
  await requireRole("SALES");

  const leads = await db.lead.findMany({
    where: {
      OR: [
        { assignedTo: { not: null } },
        { status: { in: ["PROSPECT", "OUTREACHED", "SCHEDULED", "CLOSED", "NOT_INTERESTED"] } },
      ],
    },
    orderBy: { updatedAt: "desc" },
    include: { assignee: true, salesProject: { select: { id: true, name: true, niche: true } } },
    take: 200,
  });

  // Get unique niches and projects for filter options
  const niches = [...new Set(leads.map((l) => l.salesProject?.niche).filter(Boolean))] as string[];
  const projects = [...new Map(leads.filter((l) => l.salesProject).map((l) => [l.salesProject!.id, { id: l.salesProject!.id, name: l.salesProject!.name }])).values()];

  return <ContactsList leads={JSON.parse(JSON.stringify(leads))} niches={niches} projects={projects} />;
}
