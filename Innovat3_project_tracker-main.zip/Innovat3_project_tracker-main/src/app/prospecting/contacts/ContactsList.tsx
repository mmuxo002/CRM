"use client";

import { useState, useMemo } from "react";
import Link from "next/link";
import { Search, Filter, ChevronDown, X } from "lucide-react";

const STATUS_CONFIG: Record<string, { label: string; color: string; bg: string }> = {
  PROSPECT: { label: "Prospect", color: "#3b82f6", bg: "#3b82f618" },
  OUTREACHED: { label: "Outreached", color: "#10b981", bg: "#10b98118" },
  SCHEDULED: { label: "Scheduled Appt", color: "#8b5cf6", bg: "#8b5cf618" },
  CLOSED: { label: "Closed", color: "#f59e0b", bg: "#f59e0b18" },
  NOT_INTERESTED: { label: "Not Interested", color: "#ef4444", bg: "#ef444418" },
  NEW: { label: "New", color: "#94a3b8", bg: "#94a3b818" },
};

interface ContactsListProps {
  leads: any[];
  niches: string[];
  projects: { id: string; name: string }[];
}

export default function ContactsList({ leads, niches, projects }: ContactsListProps) {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("");
  const [nicheFilter, setNicheFilter] = useState<string>("");
  const [projectFilter, setProjectFilter] = useState<string>("");
  const [showFilters, setShowFilters] = useState(false);

  const filtered = useMemo(() => {
    let result = leads;
    if (search) {
      const q = search.toLowerCase();
      result = result.filter((l: any) =>
        l.name.toLowerCase().includes(q) ||
        (l.email && l.email.toLowerCase().includes(q)) ||
        (l.phone && l.phone.includes(q)) ||
        (l.salesProject?.name || "").toLowerCase().includes(q)
      );
    }
    if (statusFilter) result = result.filter((l: any) => l.status === statusFilter);
    if (nicheFilter) result = result.filter((l: any) => l.salesProject?.niche === nicheFilter);
    if (projectFilter) result = result.filter((l: any) => l.salesProject?.id === projectFilter);
    return result;
  }, [leads, search, statusFilter, nicheFilter, projectFilter]);

  const activeFilters = [statusFilter, nicheFilter, projectFilter].filter(Boolean).length;
  const clearFilters = () => { setStatusFilter(""); setNicheFilter(""); setProjectFilter(""); };

  // Counts
  const counts = {
    prospect: leads.filter((l: any) => l.status === "PROSPECT").length,
    outreached: leads.filter((l: any) => l.status === "OUTREACHED").length,
    scheduled: leads.filter((l: any) => l.status === "SCHEDULED").length,
    closed: leads.filter((l: any) => l.status === "CLOSED").length,
  };

  return (
    <div className="animate-slide-up" style={{ padding: "2rem", maxWidth: 1200, margin: "0 auto" }}>
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "1rem" }}>
        <div>
          <h1 style={{ fontSize: "1.4rem", fontWeight: 800, color: "var(--text-primary)", margin: 0 }}>
            Pipeline Contacts
          </h1>
          <div style={{ display: "flex", gap: 12, marginTop: 6, fontSize: "0.72rem" }}>
            <span style={{ color: "var(--text-secondary)" }}>{leads.length} total</span>
            <span style={{ color: "#3b82f6", fontWeight: 600 }}>{counts.prospect} prospects</span>
            <span style={{ color: "#10b981", fontWeight: 600 }}>{counts.outreached} outreached</span>
            <span style={{ color: "#8b5cf6", fontWeight: 600 }}>{counts.scheduled} scheduled</span>
            <span style={{ color: "#f59e0b", fontWeight: 600 }}>{counts.closed} closed</span>
          </div>
        </div>
      </div>

      {/* Search + Filters */}
      <div style={{ display: "flex", gap: 8, marginBottom: "0.75rem", alignItems: "center" }}>
        <div style={{ flex: 1, position: "relative" }}>
          <Search size={14} style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", color: "var(--text-muted)" }} />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name, email, phone, or project…"
            style={{
              width: "100%", padding: "0.5rem 0.75rem 0.5rem 2rem",
              borderRadius: 8, border: "1.5px solid var(--border-color)",
              fontSize: "0.78rem", outline: "none", background: "var(--bg-surface)",
              color: "var(--text-primary)",
            }}
          />
        </div>
        <button
          onClick={() => setShowFilters(!showFilters)}
          style={{
            display: "flex", alignItems: "center", gap: 4,
            padding: "0.5rem 0.75rem", borderRadius: 8,
            border: activeFilters > 0 ? "1.5px solid var(--accent-primary)" : "1.5px solid var(--border-color)",
            background: activeFilters > 0 ? "var(--accent-primary)08" : "var(--bg-surface)",
            color: activeFilters > 0 ? "var(--accent-primary)" : "var(--text-secondary)",
            fontSize: "0.78rem", fontWeight: 600, cursor: "pointer",
          }}
        >
          <Filter size={13} /> Filters {activeFilters > 0 && `(${activeFilters})`}
        </button>
        {activeFilters > 0 && (
          <button
            onClick={clearFilters}
            style={{ display: "flex", alignItems: "center", gap: 3, padding: "0.5rem 0.6rem", borderRadius: 8, border: "none", background: "none", color: "var(--text-muted)", fontSize: "0.72rem", cursor: "pointer" }}
          >
            <X size={12} /> Clear
          </button>
        )}
      </div>

      {/* Filter dropdowns */}
      {showFilters && (
        <div style={{ display: "flex", gap: 8, marginBottom: "0.75rem", flexWrap: "wrap" }}>
          <FilterDropdown
            label="Status"
            value={statusFilter}
            onChange={setStatusFilter}
            options={[
              { value: "", label: "All Statuses" },
              { value: "PROSPECT", label: "Prospect" },
              { value: "OUTREACHED", label: "Outreached" },
              { value: "SCHEDULED", label: "Scheduled Appt" },
              { value: "CLOSED", label: "Closed" },
              { value: "NOT_INTERESTED", label: "Not Interested" },
            ]}
          />
          <FilterDropdown
            label="Niche"
            value={nicheFilter}
            onChange={setNicheFilter}
            options={[{ value: "", label: "All Niches" }, ...niches.map((n) => ({ value: n, label: n }))]}
          />
          <FilterDropdown
            label="Sales Project"
            value={projectFilter}
            onChange={setProjectFilter}
            options={[{ value: "", label: "All Projects" }, ...projects.map((p) => ({ value: p.id, label: p.name }))]}
          />
        </div>
      )}

      {/* Results count */}
      <div style={{ fontSize: "0.7rem", color: "var(--text-muted)", marginBottom: "0.5rem" }}>
        Showing {filtered.length} of {leads.length} contacts
      </div>

      {/* Table */}
      <div className="card" style={{ overflow: "hidden", padding: 0 }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.78rem" }}>
          <thead>
            <tr style={{ background: "#f8fafc", borderBottom: "1px solid var(--border-color)" }}>
              {["Name", "Niche", "Sales Project", "Score", "Stage", "Owner"].map((h) => (
                <th key={h} style={{
                  padding: "0.5rem 0.75rem", textAlign: "left",
                  fontWeight: 700, color: "var(--text-secondary)",
                  fontSize: "0.65rem", textTransform: "uppercase", letterSpacing: "0.04em",
                }}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr>
                <td colSpan={6} style={{ padding: "2rem", textAlign: "center", color: "var(--text-muted)" }}>
                  {leads.length === 0
                    ? "No pipeline contacts yet. Add leads from a Sales Project to get started."
                    : "No contacts match your filters."
                  }
                </td>
              </tr>
            )}
            {filtered.map((l: any) => {
              const cfg = STATUS_CONFIG[l.status] || { label: l.status, color: "#94a3b8", bg: "#94a3b818" };
              const score = l.qualificationScore || l.score || 0;
              const scoreColor = score >= 70 ? "#10b981" : score >= 40 ? "#f59e0b" : "#94a3b8";

              return (
                <tr
                  key={l.id}
                  style={{ borderBottom: "1px solid var(--border-color)", cursor: "pointer", transition: "background 0.1s" }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = "#f8fafc")}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                >
                  <td style={{ padding: "0.5rem 0.75rem" }}>
                    <Link href={`/prospecting/contacts/${l.id}`} style={{ textDecoration: "none", display: "flex", alignItems: "center", gap: 8 }}>
                      <div style={{
                        width: 28, height: 28, borderRadius: "50%",
                        background: "linear-gradient(135deg, #3b82f6, #8b5cf6)",
                        color: "white", display: "flex", alignItems: "center", justifyContent: "center",
                        fontSize: "0.65rem", fontWeight: 800, flexShrink: 0,
                      }}>
                        {l.name.slice(0, 1).toUpperCase()}
                      </div>
                      <div style={{ minWidth: 0 }}>
                        <div style={{ fontWeight: 600, color: "var(--text-primary)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: 180 }}>
                          {l.name}
                        </div>
                        <div style={{ fontSize: "0.65rem", color: "var(--text-muted)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: 180 }}>
                          {l.email && l.email !== "" ? l.email : l.phone || "—"}
                        </div>
                      </div>
                    </Link>
                  </td>
                  <td style={{ padding: "0.5rem 0.75rem" }}>
                    {l.salesProject?.niche ? (
                      <span style={{ padding: "2px 6px", borderRadius: 4, fontSize: "0.65rem", fontWeight: 600, background: "#f1f5f9", color: "var(--text-primary)" }}>
                        {l.salesProject.niche}
                      </span>
                    ) : (
                      <span style={{ color: "var(--text-muted)" }}>—</span>
                    )}
                  </td>
                  <td style={{ padding: "0.5rem 0.75rem" }}>
                    {l.salesProject ? (
                      <Link href={`/prospecting/projects/${l.salesProject.id}`} style={{ textDecoration: "none", fontSize: "0.73rem", color: "var(--accent-primary)", fontWeight: 600 }} onClick={(e) => e.stopPropagation()}>
                        {l.salesProject.name}
                      </Link>
                    ) : (
                      <span style={{ color: "var(--text-muted)" }}>—</span>
                    )}
                  </td>
                  <td style={{ padding: "0.5rem 0.75rem" }}>
                    <span style={{
                      padding: "2px 7px", borderRadius: 5, fontSize: "0.7rem", fontWeight: 700,
                      background: `${scoreColor}18`, color: scoreColor,
                    }}>
                      {score}
                    </span>
                  </td>
                  <td style={{ padding: "0.5rem 0.75rem" }}>
                    <span style={{
                      padding: "2px 8px", borderRadius: 5, fontSize: "0.65rem", fontWeight: 700,
                      background: cfg.bg, color: cfg.color,
                    }}>
                      {cfg.label}
                    </span>
                  </td>
                  <td style={{ padding: "0.5rem 0.75rem" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 5, fontSize: "0.73rem" }}>
                      <div style={{
                        width: 22, height: 22, borderRadius: "50%",
                        background: "linear-gradient(135deg, #f59e0b, #ef4444)",
                        color: "white", display: "flex", alignItems: "center", justifyContent: "center",
                        fontSize: "0.58rem", fontWeight: 800, flexShrink: 0,
                      }}>
                        {(l.assignee?.name || "?").slice(0, 1).toUpperCase()}
                      </div>
                      <span style={{ color: "var(--text-secondary)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: 100 }}>
                        {l.assignee?.name || "Unassigned"}
                      </span>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function FilterDropdown({ label, value, onChange, options }: {
  label: string; value: string; onChange: (v: string) => void;
  options: { value: string; label: string }[];
}) {
  return (
    <div style={{ position: "relative" }}>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        style={{
          padding: "0.4rem 1.8rem 0.4rem 0.6rem",
          borderRadius: 8, border: "1.5px solid var(--border-color)",
          fontSize: "0.73rem", fontWeight: 600,
          color: value ? "var(--text-primary)" : "var(--text-muted)",
          background: "var(--bg-surface)",
          cursor: "pointer",
          appearance: "none",
          WebkitAppearance: "none",
        }}
      >
        {options.map((o) => (
          <option key={o.value} value={o.value}>{o.label}</option>
        ))}
      </select>
      <ChevronDown size={12} style={{ position: "absolute", right: 8, top: "50%", transform: "translateY(-50%)", pointerEvents: "none", color: "var(--text-muted)" }} />
    </div>
  );
}
