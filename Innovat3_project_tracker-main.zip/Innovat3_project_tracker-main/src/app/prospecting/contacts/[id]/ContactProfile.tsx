"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  Mail, Phone, MapPin, Globe, Clock, FileText, Calendar, MoreHorizontal,
  Sparkles, Pin, CheckSquare, MessageCircle, DollarSign, Tag,
  RefreshCw, Monitor, Smartphone, ExternalLink, Share2, Link2,
  Loader2, ChevronDown, ChevronUp, Star, Zap, Package,
} from "lucide-react";
import { WebsitePreview } from "@/components/sales/WebsitePreview";
import { SocialMediaPreview } from "@/components/sales/SocialMediaPreview";
import { LeadIntelligencePanel } from "@/components/sales/LeadIntelligencePanel";
import { ReadyToCall } from "@/components/sales/ReadyToCall";
import { GenerateFullProposalButton } from "@/components/sales/GenerateFullProposalButton";
import { SendIntroOfferButton } from "@/components/sales/SendIntroOfferButton";
import { DecisionMakerPanel } from "@/components/sales/DecisionMakerPanel";

// ── A La Carte Service Catalog ──
const SERVICE_CATALOG = [
  { id: "landing-page", name: "Landing Page", price: "$800", monthly: null, category: "Digital Presence", description: "Custom landing page built in 32 hours — mobile responsive, SEO foundation, and lead capture forms." },
  { id: "website-redesign", name: "Website Redesign", price: "$1,000 – $2,500", monthly: null, category: "Digital Presence", description: "Modernize existing website with updated design, faster load times, and conversion optimization." },
  { id: "crm-platform", name: "CRM Platform", price: "$1,500 setup", monthly: "$250/mo", category: "Operations", description: "Full CRM implementation — lead tracking, pipeline management, conversion workflows, form automation, and triggers. Includes a custom landing page." },
  { id: "google-business", name: "Google My Business", price: "$350", monthly: null, category: "Local SEO", description: "Full Google Business Profile optimization — photos, descriptions, categories, and review strategy." },
  { id: "phone-integration", name: "Phone System Integration", price: "$500 setup", monthly: "$99/mo", category: "Automation", description: "Business phone system tied into CRM — call tracking, routing, and lead attribution." },
  { id: "review-mgmt", name: "Review Management", price: "$200 setup", monthly: "$99/mo", category: "Reputation", description: "Automated review requests, monitoring, and response management to build 5-star reputation." },
  { id: "sms-marketing", name: "SMS Marketing", price: "$300 setup", monthly: "$149/mo", category: "Marketing", description: "Automated text message campaigns — follow-ups, appointment reminders, and promotional blasts." },
  { id: "email-marketing", name: "Email Marketing", price: "$300 setup", monthly: "$149/mo", category: "Marketing", description: "Newsletter campaigns, drip sequences, and promotional emails to nurture your customer base." },
  { id: "voice-ai", name: "Voice AI Agent", price: "$750 setup", monthly: "$149/mo", category: "Automation", description: "AI-powered phone agent answers calls 24/7, qualifies leads, schedules appointments, and never misses a call." },
  { id: "social-media", name: "Social Media Marketing", price: "$300 setup", monthly: "$399/mo", category: "Marketing", description: "Content creation, scheduling, and community management across Instagram, Facebook, and LinkedIn." },
  { id: "seo", name: "SEO Package", price: "$500 setup", monthly: "$299/mo", category: "Local SEO", description: "Local SEO targeting — keyword optimization, citation building, and monthly performance reporting." },
  { id: "paid-ads", name: "Google/Meta Ads", price: "$500 setup", monthly: "$299/mo + ad spend", category: "Marketing", description: "Targeted ad campaigns on Google and Meta platforms with conversion tracking and optimization." },
];

// ── Strategic Bundle Tiers ──
const BUNDLES = [
  {
    id: "starter",
    name: "Starter",
    tagline: "Get Online Fast",
    setup: 800,
    monthly: 0,
    delivery: "32-hour delivery",
    badge: null,
    color: "#64748b",
    includes: [
      "Custom landing page",
      "Mobile responsive design",
      "SEO foundation",
      "Lead capture forms",
    ],
    alaCarte: 800,          // what it'd cost individually
    services: ["landing-page"],
  },
  {
    id: "growth",
    name: "Growth",
    tagline: "Capture & Convert Leads",
    setup: 1500,
    monthly: 250,
    delivery: null,
    badge: "MOST POPULAR",
    color: "#3b82f6",
    includes: [
      "Everything in Starter",
      "CRM platform setup",
      "Lead tracking & pipeline",
      "Form automation & triggers",
      "Google My Business optimization",
      "Phone system integration",
    ],
    alaCarte: 800 + 1500 + 350 + 500,  // $3,150
    services: ["landing-page", "crm-platform", "google-business", "phone-integration"],
  },
  {
    id: "accelerate",
    name: "Accelerate",
    tagline: "Automate & Scale",
    setup: 2800,
    monthly: 499,
    delivery: null,
    badge: "BEST VALUE",
    color: "#8b5cf6",
    includes: [
      "Everything in Growth",
      "Review management",
      "SMS marketing",
      "Email marketing",
      "Voice AI agent",
    ],
    alaCarte: 800 + 1500 + 350 + 500 + 200 + 300 + 300 + 750,  // $4,700
    services: ["landing-page", "crm-platform", "google-business", "phone-integration", "review-mgmt", "sms-marketing", "email-marketing", "voice-ai"],
  },
  {
    id: "dominate",
    name: "Dominate",
    tagline: "Full-Stack Growth",
    setup: 4200,
    monthly: 899,
    delivery: null,
    badge: null,
    color: "#f59e0b",
    includes: [
      "Everything in Accelerate",
      "Social media marketing",
      "SEO package",
      "Google/Meta ads management",
      "Dedicated account manager",
    ],
    alaCarte: 800 + 1500 + 350 + 500 + 200 + 300 + 300 + 750 + 300 + 500 + 500,  // $6,000
    services: ["landing-page", "crm-platform", "google-business", "phone-integration", "review-mgmt", "sms-marketing", "email-marketing", "voice-ai", "social-media", "seo", "paid-ads"],
  },
];

const COMMISSION_RATE = 0.20;

interface ContactProfileProps {
  lead: any;
}

export default function ContactProfile({ lead }: ContactProfileProps) {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState("overview");
  const [webKey, setWebKey] = useState(0); // for refresh
  const [socialKey, setSocialKey] = useState(0);

  const tabs = [
    { id: "overview", label: "Overview" },
    { id: "offers", label: "Offers" },
    { id: "web-social", label: "Web & Social" },
    { id: "activity", label: "Activity" },
  ];

  const recommendedServices = safeJson(lead.recommendedServices, []);
  const persona = lead.persona;
  const painPoints = safeJson(persona?.painPoints, []);

  return (
    <div className="animate-slide-up">
      {/* Breadcrumb */}
      <div className="row-between" style={{ marginBottom: "1.25rem", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
        <div className="flex-gap" style={{ fontSize: "0.85rem", color: "var(--text-secondary)" }}>
          <span>Contacts</span>
          <span>/</span>
          <span style={{ color: "var(--text-primary)", fontWeight: 700 }}>{lead.name}</span>
        </div>
        <div style={{ display: "inline-flex", gap: 8, flexWrap: "wrap" }}>
          <SendIntroOfferButton leadId={lead.id} leadName={lead.name} leadEmail={lead.email ?? null} />
          <GenerateFullProposalButton leadId={lead.id} leadName={lead.name} leadEmail={lead.email ?? null} />
        </div>
      </div>

      <div className="contact-layout">
        {/* LEFT SIDEBAR — Contact Identity */}
        <div className="contact-left">
          <div className="card">
            <div className="identity">
              <div style={{ width: 80, height: 80, borderRadius: "50%", background: "linear-gradient(135deg, #3b82f6, #8b5cf6)", color: "white", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.8rem", fontWeight: 800, margin: "0 auto 8px" }}>
                {lead.name.slice(0, 1).toUpperCase()}
              </div>
              <h2>{lead.name}</h2>
              <div className="title">{lead.title || lead.persona?.decisionMakerTitle || "Business Owner"}</div>
              {lead.qualificationScore > 0 && (
                <div style={{ display: "flex", justifyContent: "center", marginTop: 6 }}>
                  <span style={{
                    padding: "2px 10px", borderRadius: 6, fontSize: "0.72rem", fontWeight: 700,
                    background: lead.qualificationScore >= 70 ? "#10b98118" : lead.qualificationScore >= 40 ? "#f59e0b18" : "#94a3b818",
                    color: lead.qualificationScore >= 70 ? "#10b981" : lead.qualificationScore >= 40 ? "#f59e0b" : "#94a3b8",
                  }}>
                    Score: {lead.qualificationScore}/100
                  </span>
                </div>
              )}
            </div>

            {/* Business Owner / Decision Maker */}
            {persona?.decisionMakerName && (
              <div style={{
                margin: "0.75rem 0", padding: "0.65rem 0.75rem", borderRadius: 10,
                background: "linear-gradient(135deg, #f5f3ff, #ede9fe)",
                border: "1px solid #ddd6fe",
              }}>
                <div style={{ fontSize: "0.62rem", fontWeight: 800, color: "#7c3aed", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 4 }}>
                  {persona.decisionMakerTitle || "Business Owner"}
                </div>
                <div style={{ fontWeight: 700, fontSize: "0.95rem", color: "var(--text-primary)" }}>
                  {persona.decisionMakerName}
                </div>
                {persona.decisionMakerStyle && (
                  <div style={{ fontSize: "0.68rem", color: "#7c3aed", marginTop: 3, fontWeight: 500 }}>
                    {persona.decisionMakerStyle}
                  </div>
                )}
              </div>
            )}

            <div className="detail-section">
              <h4>Contact Details</h4>
              {lead.email && lead.email !== "" && <div className="detail-row"><Mail size={14} /><span>{lead.email}</span></div>}
              {lead.phone && <div className="detail-row"><Phone size={14} /><span>{lead.phone}</span></div>}
              {(lead.address || lead.location) && <div className="detail-row"><MapPin size={14} /><span>{lead.address || lead.location}</span></div>}
              {lead.website && (
                <div className="detail-row">
                  <Globe size={14} />
                  <a href={lead.website.startsWith("http") ? lead.website : `https://${lead.website}`} target="_blank" rel="noopener noreferrer" style={{ color: "#3b82f6", textDecoration: "none", fontSize: "0.8rem" }}>
                    {lead.website.replace(/^https?:\/\//, "").slice(0, 30)}
                  </a>
                </div>
              )}
              {lead.instagramHandle && <div className="detail-row"><Share2 size={14} style={{ color: "#e4405f" }} /><span>{lead.instagramHandle}</span></div>}
              {lead.linkedinUrl && <div className="detail-row"><Link2 size={14} style={{ color: "#0077b5" }} /><span>LinkedIn</span></div>}
              <div className="detail-row"><Calendar size={14} /><span>Added {new Date(lead.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</span></div>
            </div>

            {lead.googleRating && (
              <div className="detail-section">
                <h4>Google Reviews</h4>
                <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: "0.82rem" }}>
                  <Star size={14} style={{ color: "#f59e0b" }} />
                  <span style={{ fontWeight: 700 }}>{lead.googleRating}</span>
                  <span style={{ color: "var(--text-muted)" }}>({lead.googleReviewCount || 0} reviews)</span>
                </div>
              </div>
            )}

            <div style={{ marginTop: "0.75rem" }}>
              <ReadyToCall leadId={lead.id} initial={lead.status} />
            </div>
          </div>
        </div>

        {/* CENTER — Tabbed Content */}
        <div className="contact-center">
          <div className="tabbar">
            {tabs.map((t) => (
              <div
                key={t.id}
                className={`record-tab ${activeTab === t.id ? "active" : ""}`}
                onClick={() => setActiveTab(t.id)}
                style={{ cursor: "pointer" }}
              >
                {t.label}
              </div>
            ))}
          </div>

          {/* OVERVIEW TAB */}
          {activeTab === "overview" && (
            <>
              {/* Decision Maker — live lookup via Sunbiz & Apollo */}
              <DecisionMakerPanel
                leadId={lead.id}
                currentName={persona?.decisionMakerName || null}
                currentTitle={persona?.decisionMakerTitle || null}
              />

              <div className="card" style={{ marginBottom: "1rem" }}>
                <h4 style={{ fontSize: "0.7rem", textTransform: "uppercase", color: "var(--text-secondary)", letterSpacing: "0.05em", fontWeight: 700, marginBottom: "0.75rem" }}>Profile Overview</h4>
                <div style={{ display: "grid", gridTemplateColumns: "140px 1fr", rowGap: "0.6rem", fontSize: "0.85rem" }}>
                  {persona?.businessSummary && <><span style={{ color: "var(--text-secondary)" }}>About</span><span>{persona.businessSummary}</span></>}
                  <span style={{ color: "var(--text-secondary)" }}>Source</span><span>{lead.source || "—"}</span>
                  <span style={{ color: "var(--text-secondary)" }}>Niche</span><span>{lead.salesProject?.niche || "—"}</span>
                  <span style={{ color: "var(--text-secondary)" }}>Location</span><span>{lead.address || lead.location || "—"}</span>
                  <span style={{ color: "var(--text-secondary)" }}>Status</span><span style={{ fontWeight: 600 }}>{lead.status.replace(/_/g, " ")}</span>
                  <span style={{ color: "var(--text-secondary)" }}>Owner</span>
                  <span style={{ display: "flex", alignItems: "center", gap: 6 }}>
                    <div style={{ width: 20, height: 20, borderRadius: "50%", background: "linear-gradient(135deg, #f59e0b, #ef4444)", color: "white", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.6rem", fontWeight: 800 }}>
                      {(lead.assignee?.name || "?").slice(0, 1).toUpperCase()}
                    </div>
                    {lead.assignee?.name || "Unassigned"}
                  </span>
                </div>
              </div>

              {/* Intelligence Panel */}
              {lead.salesProjectId && <LeadIntelligencePanel lead={lead} />}

              {/* Pinned Notes */}
              {lead.notes?.length > 0 && (
                <div className="card" style={{ marginTop: "1rem", background: "#fffbeb", border: "1px solid #fde68a" }}>
                  <h4 style={{ fontSize: "0.7rem", textTransform: "uppercase", color: "#b45309", letterSpacing: "0.05em", fontWeight: 700, marginBottom: "0.75rem", display: "flex", alignItems: "center", gap: 4 }}><Pin size={12} /> Pinned Notes</h4>
                  {lead.notes.map((n: any) => <div key={n.id} style={{ fontSize: "0.85rem", lineHeight: 1.5 }}>{n.body}</div>)}
                </div>
              )}
            </>
          )}

          {/* OFFERS TAB */}
          {activeTab === "offers" && (
            <OffersTab recommendedServices={recommendedServices} painPoints={painPoints} niche={lead.salesProject?.niche || ""} />
          )}

          {/* WEB & SOCIAL TAB */}
          {activeTab === "web-social" && (
            <div>
              {/* Website Section */}
              <div className="card" style={{ marginBottom: "1rem" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                  <h4 style={{ fontSize: "0.78rem", fontWeight: 700, color: "var(--text-primary)", margin: 0 }}>Website</h4>
                  {lead.website && (
                    <button
                      onClick={() => setWebKey((k) => k + 1)}
                      style={{
                        display: "flex", alignItems: "center", gap: 4,
                        padding: "0.3rem 0.6rem", borderRadius: 6,
                        border: "1px solid var(--border-color)", background: "var(--bg-surface)",
                        fontSize: "0.68rem", fontWeight: 600, cursor: "pointer", color: "var(--text-secondary)",
                      }}
                    >
                      <RefreshCw size={11} /> Refresh
                    </button>
                  )}
                </div>
                {lead.website ? (
                  <div key={`web-${webKey}`}>
                    <WebsitePreview url={lead.website} />
                  </div>
                ) : (
                  <div style={{ padding: "2rem", textAlign: "center", color: "var(--text-muted)", fontSize: "0.82rem", background: "#fef2f2", borderRadius: 10 }}>
                    <Globe size={24} style={{ color: "#ef4444", marginBottom: 8 }} />
                    <div style={{ fontWeight: 600, color: "#ef4444" }}>No Website</div>
                    <div style={{ fontSize: "0.72rem", marginTop: 4 }}>This business doesn't have a website — a key opportunity.</div>
                  </div>
                )}
              </div>

              {/* Social Media Section */}
              <div className="card">
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                  <h4 style={{ fontSize: "0.78rem", fontWeight: 700, color: "var(--text-primary)", margin: 0 }}>Social Media</h4>
                  {(lead.instagramHandle || lead.facebookUrl || lead.twitterHandle || lead.linkedinUrl) && (
                    <button
                      onClick={() => setSocialKey((k) => k + 1)}
                      style={{
                        display: "flex", alignItems: "center", gap: 4,
                        padding: "0.3rem 0.6rem", borderRadius: 6,
                        border: "1px solid var(--border-color)", background: "var(--bg-surface)",
                        fontSize: "0.68rem", fontWeight: 600, cursor: "pointer", color: "var(--text-secondary)",
                      }}
                    >
                      <RefreshCw size={11} /> Refresh
                    </button>
                  )}
                </div>
                {(lead.instagramHandle || lead.facebookUrl || lead.twitterHandle || lead.linkedinUrl) ? (
                  <div key={`social-${socialKey}`}>
                    <SocialMediaPreview
                      instagramHandle={lead.instagramHandle}
                      facebookUrl={lead.facebookUrl}
                      twitterHandle={lead.twitterHandle}
                      linkedinUrl={lead.linkedinUrl}
                    />
                  </div>
                ) : (
                  <div style={{ padding: "2rem", textAlign: "center", color: "var(--text-muted)", fontSize: "0.82rem", background: "#f8fafc", borderRadius: 10 }}>
                    <Share2 size={24} style={{ color: "var(--text-muted)", marginBottom: 8 }} />
                    <div style={{ fontWeight: 600 }}>No Social Profiles Found</div>
                    <div style={{ fontSize: "0.72rem", marginTop: 4 }}>No Instagram, Facebook, Twitter, or LinkedIn detected.</div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ACTIVITY TAB */}
          {activeTab === "activity" && (
            <div className="card">
              <h4 style={{ fontSize: "0.7rem", textTransform: "uppercase", color: "var(--text-secondary)", letterSpacing: "0.05em", fontWeight: 700, marginBottom: "0.75rem" }}>Activity</h4>
              {lead.activities?.length === 0 && (
                <div style={{ padding: "1.5rem", textAlign: "center", color: "var(--text-muted)", fontSize: "0.82rem" }}>
                  No activity yet.
                </div>
              )}
              <div className="timeline">
                {lead.activities?.map((a: any) => (
                  <div key={a.id} className="timeline-item">
                    <div className="icon" style={{ background: a.kind === "CALL" ? "#4318ff" : a.kind === "MEETING" ? "#7c3aed" : a.kind === "TASK" ? "#f59e0b" : "#94a3b8" }}>
                      {a.kind === "CALL" ? <Phone size={14} /> : a.kind === "MEETING" ? <Calendar size={14} /> : a.kind === "TASK" ? <CheckSquare size={14} /> : <FileText size={14} />}
                    </div>
                    <div className="body">
                      <h5>{a.title}</h5>
                      {a.body && <p>{a.body}</p>}
                    </div>
                    <div className="date">{new Date(a.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* RIGHT SIDEBAR */}
        <div className="contact-right">
          <div className="ai-panel">
            <h4><Sparkles size={12} style={{ display: "inline", marginRight: 4 }} /> Contact Summary</h4>
            <p>{lead.summary || lead.persona?.businessSummary || "AI summary will appear after research is run."}</p>
          </div>

          {lead.company && (
            <div className="card">
              <h4 style={{ fontSize: "0.7rem", textTransform: "uppercase", color: "var(--text-secondary)", letterSpacing: "0.05em", fontWeight: 700, marginBottom: "0.75rem" }}>Company · {lead.company.name}</h4>
              <div style={{ display: "grid", gridTemplateColumns: "90px 1fr", rowGap: "0.5rem", fontSize: "0.8rem" }}>
                <span style={{ color: "var(--text-secondary)" }}>Industry</span><span>{lead.company.industry || lead.salesProject?.niche || "—"}</span>
                <span style={{ color: "var(--text-secondary)" }}>Phone</span><span>{lead.company.phone || lead.phone || "—"}</span>
                <span style={{ color: "var(--text-secondary)" }}>HQ</span><span>{lead.company.address || lead.address || "—"}</span>
              </div>
            </div>
          )}

          {/* Quick Stats */}
          {recommendedServices.length > 0 && (
            <div className="card">
              <h4 style={{ fontSize: "0.7rem", textTransform: "uppercase", color: "var(--text-secondary)", letterSpacing: "0.05em", fontWeight: 700, marginBottom: "0.75rem" }}>Quick Services</h4>
              <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                {recommendedServices.slice(0, 4).map((s: any, i: number) => {
                  const name = typeof s === "string" ? s : s.name;
                  const tier = typeof s === "string" ? "secondary" : s.tier;
                  const tierColor = tier === "primary" ? "#ef4444" : tier === "secondary" ? "#f59e0b" : "#94a3b8";
                  return (
                    <div key={i} style={{ display: "flex", alignItems: "center", gap: 6, fontSize: "0.73rem" }}>
                      <span style={{ width: 6, height: 6, borderRadius: "50%", background: tierColor, flexShrink: 0 }} />
                      <span style={{ color: "var(--text-primary)", fontWeight: 500 }}>{name}</span>
                    </div>
                  );
                })}
                {recommendedServices.length > 4 && (
                  <button onClick={() => setActiveTab("offers")} style={{ fontSize: "0.68rem", color: "var(--accent-primary)", fontWeight: 600, background: "none", border: "none", cursor: "pointer", textAlign: "left", padding: 0, marginTop: 2 }}>
                    View all {recommendedServices.length} services →
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// --- OFFERS TAB COMPONENT ---
function OffersTab({ recommendedServices, painPoints }: { recommendedServices: any[]; painPoints: string[]; niche: string }) {
  const [expandedService, setExpandedService] = useState<string | null>(null);
  const [expandedBundle, setExpandedBundle] = useState<string | null>("growth");

  const recNames = new Set(recommendedServices.map((s: any) => typeof s === "string" ? s : s.name));

  // Match recommended services to a best-fit bundle
  const bestBundle = (() => {
    if (recommendedServices.length === 0) return null;
    // Find the smallest bundle that covers the most recommended services
    let best = BUNDLES[0];
    for (const b of BUNDLES) {
      const covered = recommendedServices.filter((s: any) => {
        const name = (typeof s === "string" ? s : s.name).toLowerCase();
        return b.services.some((sid) => {
          const cat = SERVICE_CATALOG.find((c) => c.id === sid);
          return cat && cat.name.toLowerCase().includes(name.split(" ")[0]);
        });
      });
      if (covered.length > 0) best = b;
    }
    return best;
  })();

  return (
    <div>
      {/* Pain Points Context */}
      {painPoints.length > 0 && (
        <div className="card" style={{ marginBottom: "0.75rem", background: "#fef2f2", border: "1px solid #fecaca" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 6 }}>
            <Zap size={13} style={{ color: "#dc2626" }} />
            <span style={{ fontSize: "0.72rem", fontWeight: 700, color: "#dc2626", textTransform: "uppercase", letterSpacing: "0.04em" }}>Pain Points Identified</span>
          </div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
            {painPoints.slice(0, 5).map((p, i) => (
              <span key={i} style={{ padding: "3px 8px", borderRadius: 6, background: "#fff", border: "1px solid #fecaca", fontSize: "0.72rem", color: "#991b1b", fontWeight: 500 }}>{p}</span>
            ))}
          </div>
        </div>
      )}

      {/* ── STRATEGIC BUNDLES ── */}
      <div className="card" style={{ marginBottom: "1rem" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <Package size={16} style={{ color: "var(--accent-primary)" }} />
            <h4 style={{ fontSize: "0.85rem", fontWeight: 800, color: "var(--text-primary)", margin: 0 }}>Service Packages</h4>
          </div>
          {bestBundle && (
            <span style={{ fontSize: "0.62rem", fontWeight: 700, color: "#10b981", background: "#10b98114", padding: "3px 8px", borderRadius: 6 }}>
              AI RECOMMENDS: {bestBundle.name.toUpperCase()}
            </span>
          )}
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {BUNDLES.map((bundle) => {
            const isExpanded = expandedBundle === bundle.id;
            const savings = bundle.alaCarte - bundle.setup;
            const savingsMonthly = bundle.id === "accelerate" ? 147 : bundle.id === "dominate" ? 744 : 0;
            const commission = Math.round(bundle.setup * COMMISSION_RATE);
            const isRecommended = bestBundle?.id === bundle.id;

            return (
              <div key={bundle.id} style={{
                borderRadius: 12,
                border: isRecommended ? `2px solid ${bundle.color}` : "1.5px solid var(--border-color)",
                overflow: "hidden",
                position: "relative",
              }}>
                {/* Badge */}
                {bundle.badge && (
                  <div style={{
                    position: "absolute", top: 0, right: 16,
                    padding: "2px 10px", borderRadius: "0 0 6px 6px",
                    background: bundle.color, color: "#fff",
                    fontSize: "0.58rem", fontWeight: 800, letterSpacing: "0.06em",
                  }}>
                    {bundle.badge}
                  </div>
                )}

                {/* Header row */}
                <div
                  onClick={() => setExpandedBundle(isExpanded ? null : bundle.id)}
                  style={{
                    display: "flex", alignItems: "center", justifyContent: "space-between",
                    padding: "0.75rem 1rem",
                    cursor: "pointer",
                    background: isExpanded ? "#f8fafc" : "transparent",
                  }}
                >
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <div style={{
                      width: 36, height: 36, borderRadius: 10,
                      background: `linear-gradient(135deg, ${bundle.color}, ${bundle.color}aa)`,
                      color: "#fff", display: "flex", alignItems: "center", justifyContent: "center",
                      fontWeight: 900, fontSize: "0.7rem",
                    }}>
                      {bundle.name.slice(0, 1)}
                    </div>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: "0.88rem", color: "var(--text-primary)" }}>{bundle.name}</div>
                      <div style={{ fontSize: "0.68rem", color: "var(--text-muted)", fontWeight: 500 }}>{bundle.tagline}</div>
                    </div>
                  </div>

                  <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                    <div style={{ textAlign: "right" }}>
                      <div style={{ fontWeight: 800, fontSize: "1rem", color: "var(--text-primary)" }}>
                        ${bundle.setup.toLocaleString()}
                      </div>
                      {bundle.monthly > 0 && (
                        <div style={{ fontSize: "0.68rem", color: "var(--text-muted)", fontWeight: 600 }}>
                          + ${bundle.monthly}/mo
                        </div>
                      )}
                    </div>
                    {isExpanded ? <ChevronUp size={14} style={{ color: "var(--text-muted)" }} /> : <ChevronDown size={14} style={{ color: "var(--text-muted)" }} />}
                  </div>
                </div>

                {/* Expanded details */}
                {isExpanded && (
                  <div style={{ borderTop: "1px solid var(--border-color)", padding: "0.75rem 1rem" }}>
                    {/* What's included */}
                    <div style={{ marginBottom: 12 }}>
                      <div style={{ fontSize: "0.65rem", fontWeight: 700, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 6 }}>Includes</div>
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "4px 16px" }}>
                        {bundle.includes.map((item, i) => (
                          <div key={i} style={{ display: "flex", alignItems: "center", gap: 6, fontSize: "0.75rem", color: "var(--text-primary)" }}>
                            <CheckSquare size={11} style={{ color: bundle.color, flexShrink: 0 }} />
                            <span>{item}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {bundle.delivery && (
                      <div style={{ marginBottom: 12, display: "flex", alignItems: "center", gap: 5, fontSize: "0.72rem", color: bundle.color, fontWeight: 600 }}>
                        <Clock size={11} /> {bundle.delivery}
                      </div>
                    )}

                    {/* Savings bar */}
                    {savings > 0 && (
                      <div style={{
                        padding: "0.5rem 0.75rem", borderRadius: 8,
                        background: "#f0fdf4", border: "1px solid #bbf7d0",
                        display: "flex", justifyContent: "space-between", alignItems: "center",
                        marginBottom: 10,
                      }}>
                        <div style={{ fontSize: "0.72rem", color: "#166534" }}>
                          <span style={{ fontWeight: 700 }}>You save ${savings.toLocaleString()}</span> vs. a la carte
                          {savingsMonthly > 0 && <span> + ${savingsMonthly}/mo</span>}
                        </div>
                        <div style={{ fontSize: "0.65rem", color: "#16a34a", fontWeight: 700 }}>
                          {Math.round((savings / bundle.alaCarte) * 100)}% OFF
                        </div>
                      </div>
                    )}

                    {/* Commission breakdown (visible to sales) */}
                    <div style={{
                      padding: "0.5rem 0.75rem", borderRadius: 8,
                      background: "#eff6ff", border: "1px solid #bfdbfe",
                      display: "flex", justifyContent: "space-between", alignItems: "center",
                    }}>
                      <div style={{ fontSize: "0.68rem", color: "#1e40af", fontWeight: 600 }}>
                        <DollarSign size={11} style={{ display: "inline", marginRight: 2 }} />
                        Sales Commission (20%)
                      </div>
                      <div style={{ fontSize: "0.78rem", color: "#1d4ed8", fontWeight: 800 }}>
                        ${commission.toLocaleString()}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* ── AI-RECOMMENDED SERVICES ── */}
      {recommendedServices.length > 0 && (
        <div className="card" style={{ marginBottom: "1rem", border: "1.5px solid #10b98140" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
            <Sparkles size={14} style={{ color: "#10b981" }} />
            <h4 style={{ fontSize: "0.78rem", fontWeight: 700, color: "var(--text-primary)", margin: 0 }}>
              AI-Recommended for This Business
            </h4>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
            {recommendedServices.map((svc: any, i: number) => {
              const name = typeof svc === "string" ? svc : svc.name;
              const tier = typeof svc === "string" ? "secondary" : svc.tier;
              const reason = typeof svc === "string" ? "" : svc.reason;
              const tierLabel = tier === "primary" ? "CRITICAL" : tier === "secondary" ? "HIGH" : "OPTIONAL";
              const tierColor = tier === "primary" ? "#ef4444" : tier === "secondary" ? "#f59e0b" : "#94a3b8";
              return (
                <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 8, padding: "0.4rem 0.5rem", borderRadius: 8, background: i % 2 === 0 ? "#f8fafb" : "transparent" }}>
                  <span style={{ padding: "2px 5px", borderRadius: 4, fontSize: "0.55rem", fontWeight: 800, background: `${tierColor}14`, color: tierColor, flexShrink: 0, marginTop: 2 }}>{tierLabel}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 600, fontSize: "0.78rem", color: "var(--text-primary)" }}>{name}</div>
                    {reason && <div style={{ fontSize: "0.68rem", color: "var(--text-secondary)", marginTop: 2, lineHeight: 1.4 }}>{reason}</div>}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ── A LA CARTE CATALOG ── */}
      <div className="card">
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
          <Tag size={14} style={{ color: "var(--accent-primary)" }} />
          <h4 style={{ fontSize: "0.78rem", fontWeight: 700, color: "var(--text-primary)", margin: 0 }}>
            A La Carte Services
          </h4>
        </div>

        {["Digital Presence", "Operations", "Automation", "Local SEO", "Marketing", "Reputation"].map((cat) => {
          const catServices = SERVICE_CATALOG.filter((s) => s.category === cat);
          if (catServices.length === 0) return null;

          return (
            <div key={cat} style={{ marginBottom: 12 }}>
              <div style={{ fontSize: "0.65rem", fontWeight: 700, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 6 }}>
                {cat}
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                {catServices.map((svc) => {
                  const isRecommended = Array.from(recNames).some((name: any) => {
                    const n = (typeof name === "string" ? name : name).toLowerCase();
                    return svc.name.toLowerCase().includes(n.split(" ")[0]) || n.includes(svc.name.toLowerCase().split(" ")[0]);
                  });
                  const isExpanded = expandedService === `cat-${svc.id}`;

                  return (
                    <div key={svc.id} style={{
                      borderRadius: 8, border: "1px solid var(--border-color)",
                      borderLeft: isRecommended ? "3px solid #10b981" : "3px solid transparent",
                      overflow: "hidden",
                    }}>
                      <div
                        onClick={() => setExpandedService(isExpanded ? null : `cat-${svc.id}`)}
                        style={{
                          display: "flex", alignItems: "center", justifyContent: "space-between",
                          padding: "0.45rem 0.65rem", cursor: "pointer",
                        }}
                      >
                        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                          <span style={{ fontWeight: 600, fontSize: "0.78rem", color: "var(--text-primary)" }}>{svc.name}</span>
                          {isRecommended && <span style={{ padding: "1px 5px", borderRadius: 4, fontSize: "0.55rem", fontWeight: 700, background: "#10b98118", color: "#10b981" }}>REC</span>}
                        </div>
                        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                          <span style={{ fontSize: "0.7rem", fontWeight: 600, color: "var(--accent-primary)" }}>{svc.price}</span>
                          {svc.monthly && <span style={{ fontSize: "0.62rem", color: "var(--text-muted)" }}>+ {svc.monthly}</span>}
                          {isExpanded ? <ChevronUp size={12} style={{ color: "var(--text-muted)" }} /> : <ChevronDown size={12} style={{ color: "var(--text-muted)" }} />}
                        </div>
                      </div>
                      {isExpanded && (
                        <div style={{ padding: "0.4rem 0.65rem", borderTop: "1px solid var(--border-color)", fontSize: "0.72rem", color: "var(--text-secondary)", lineHeight: 1.5 }}>
                          {svc.description}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function safeJson(str: any, fallback: any) {
  if (!str) return fallback;
  if (typeof str !== "string") return str;
  try { return JSON.parse(str); } catch { return fallback; }
}
