import { requireRole } from "@/lib/rbac";
import { db } from "@/lib/db";
import { notFound } from "next/navigation";
import ContactProfile from "./ContactProfile";

export const dynamic = "force-dynamic";

export default async function ContactPage({ params }: { params: Promise<{ id: string }> }) {
  await requireRole("SALES");
  const { id } = await params;

  const lead = await db.lead.findUnique({
    where: { id },
    include: {
      company: true,
      assignee: true,
      activities: { orderBy: { createdAt: "desc" }, include: { actor: true } },
      notes: { where: { pinned: true } },
      persona: true,
      preCallBrief: true,
      outreaches: { orderBy: { createdAt: "desc" } },
      salesProject: true,
    },
  });
  if (!lead) notFound();

  return <ContactProfile lead={JSON.parse(JSON.stringify(lead))} />;
}
