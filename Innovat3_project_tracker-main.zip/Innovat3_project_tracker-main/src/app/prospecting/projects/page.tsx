export const dynamic = "force-dynamic";

import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";
import Link from "next/link";
import { Plus, FolderSearch } from "lucide-react";
import { ProjectListToggle } from "./ProjectListToggle";

const PHASE_LABELS: Record<number, string> = {
  1: "Created",
  2: "Discovering",
  3: "Enriching",
  4: "Researching",
  5: "Qualifying",
  6: "Generating Outreach",
  7: "Briefs Ready",
  8: "Complete",
};

const STATUS_COLORS: Record<string, string> = {
  CREATED: "#94a3b8",
  DISCOVERING: "#f59e0b",
  ENRICHING: "#3b82f6",
  RESEARCHING: "#8b5cf6",
  QUALIFYING: "#ec4899",
  GENERATING: "#f97316",
  COMPLETE: "#10b981",
};

export default async function SalesProjectsPage() {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN") return null;

  const projects = await db.salesProject.findMany({
    orderBy: { createdAt: "desc" },
    include: {
      creator: { select: { name: true } },
      _count: { select: { leads: true } },
    },
  });

  const qualifiedCounts = await Promise.all(
    projects.map((p) =>
      db.lead.count({ where: { salesProjectId: p.id, qualified: true } })
    )
  );

  return (
    <div className="animate-slide-up" style={{ padding: "2rem", maxWidth: 1200, margin: "0 auto" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "1.5rem" }}>
        <div>
          <h1 className="page-title" style={{ fontSize: "1.5rem", fontWeight: 800, color: "var(--text-primary)", margin: 0 }}>Sales Projects</h1>
          <p style={{ color: "var(--text-secondary)", fontSize: "0.8rem", marginTop: 4 }}>
            AI-powered prospecting campaigns — find, qualify, and engage leads
          </p>
        </div>
        <Link
          href="/prospecting/projects/new"
          className="btn-primary"
          style={{ display: "flex", alignItems: "center", gap: 6, padding: "0.6rem 1.1rem", fontSize: "0.8rem", borderRadius: 10, textDecoration: "none" }}
        >
          <Plus size={16} /> New Project
        </Link>
      </div>

      {projects.length === 0 ? (
        <div className="card" style={{ padding: "3rem", textAlign: "center" }}>
          <FolderSearch size={48} style={{ color: "var(--text-muted)", marginBottom: "1rem" }} />
          <h3 style={{ color: "var(--text-primary)", fontWeight: 700, fontSize: "1.1rem", marginBottom: 8 }}>
            No sales projects yet
          </h3>
          <p style={{ color: "var(--text-secondary)", fontSize: "0.8rem", marginBottom: "1.5rem" }}>
            Create your first project to start discovering and qualifying leads
          </p>
          <Link
            href="/prospecting/projects/new"
            className="btn-primary"
            style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "0.6rem 1.1rem", fontSize: "0.8rem", borderRadius: 10, textDecoration: "none" }}
          >
            <Plus size={16} /> Create Project
          </Link>
        </div>
      ) : (
        <ProjectListToggle
          projects={JSON.parse(JSON.stringify(projects))}
          qualifiedCounts={qualifiedCounts}
          phaseLabels={PHASE_LABELS}
          statusColors={STATUS_COLORS}
          isAdmin={user.role === "ADMIN"}
        />
      )}
    </div>
  );
}
