export const dynamic = "force-dynamic";

import { requireSession } from "@/lib/rbac";
import ProjectWizard from "./ProjectWizard";

export default async function NewSalesProjectPage() {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN") return null;

  return (
    <div className="animate-slide-up" style={{ padding: "2rem", maxWidth: 640, margin: "0 auto" }}>
      <div style={{ marginBottom: "1.5rem" }}>
        <h1 style={{ fontSize: "1.5rem", fontWeight: 800, color: "var(--text-primary)", margin: 0 }}>
          New Sales Project
        </h1>
        <p style={{ color: "var(--text-secondary)", fontSize: "0.8rem", marginTop: 4 }}>
          Define your target niche, location, and lead count to start prospecting
        </p>
      </div>
      <ProjectWizard />
    </div>
  );
}
