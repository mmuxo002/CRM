"use client";

import { useState, useRef, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Search, MapPin, ArrowRight, Loader2, ChevronDown, Award, Globe } from "lucide-react";
import { NICHE_OPTIONS } from "@/lib/sales/niche-config";
import { DBPR_NICHES, DBPR_COUNTIES } from "@/lib/sales/dbpr-license-types";

type Path = "GOOGLE_GENERAL" | "DBPR_LICENSED";
type DbprKind = "contractor" | "supplier";

const DBPR_NICHE_OPTIONS = Object.keys(DBPR_NICHES).map((k) => ({
  value: k,
  label: k.charAt(0).toUpperCase() + k.slice(1),
}));

const DBPR_COUNTY_OPTIONS = Object.entries(DBPR_COUNTIES)
  // Drop alias rows ("miami", "miami-dade") so each county shows once.
  .filter((_, i, all) => all.findIndex((row) => row[1] === all[i][1]) === i)
  .map(([name, code]) => ({ value: code, label: name.charAt(0).toUpperCase() + name.slice(1) }))
  .sort((a, b) => a.label.localeCompare(b.label));

export default function ProjectWizard() {
  const router = useRouter();
  const [path, setPath] = useState<Path>("GOOGLE_GENERAL");

  // Google-path form
  const [form, setForm] = useState({ niche: "", city: "", zipCode: "", targetLeadCount: 50 });
  const [nicheOpen, setNicheOpen] = useState(false);
  const [nicheSearch, setNicheSearch] = useState("");
  const nicheRef = useRef<HTMLDivElement>(null);
  const nicheInputRef = useRef<HTMLInputElement>(null);

  // DBPR-path form
  const [dbpr, setDbpr] = useState<{ kind: DbprKind; niche: string; countyCode: string; activeOnly: boolean }>({
    kind: "contractor",
    niche: "",
    countyCode: "",
    activeOnly: true,
  });

  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  // Close dropdown on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (nicheRef.current && !nicheRef.current.contains(e.target as Node)) {
        setNicheOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const filteredNiches = NICHE_OPTIONS.filter((n) =>
    n.toLowerCase().includes(nicheSearch.toLowerCase())
  );

  const selectNiche = (value: string) => {
    setForm((prev) => ({ ...prev, niche: value }));
    setNicheSearch("");
    setNicheOpen(false);
  };

  const update = (key: string, value: string | number) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  const handleSubmit = async () => {
    setError("");

    if (path === "GOOGLE_GENERAL") {
      const niche = form.niche.trim();
      if (!niche) return setError("Select or type a niche / industry");
      if (!form.city.trim() && !form.zipCode.trim()) return setError("Enter a city or ZIP code (or both)");
      if (form.targetLeadCount < 1 || form.targetLeadCount > 300) return setError("Lead count must be 1-300");

      const parts = [form.city.trim(), form.zipCode.trim()].filter(Boolean);
      const targetLocation = parts.join(", ");

      setLoading(true);
      try {
        const res = await fetch("/api/sales-projects", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            source: "GOOGLE_GENERAL",
            niche,
            targetLocation,
            targetLeadCount: form.targetLeadCount,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Failed to create project");
        router.push(`/prospecting/projects/${data.id}`);
      } catch (e) {
        setError(e instanceof Error ? e.message : "Failed to create project");
        setLoading(false);
      }
      return;
    }

    // DBPR licensed path
    if (!dbpr.niche) return setError("Select a license type");
    if (!dbpr.countyCode) return setError("Select a county");

    const cfg = DBPR_NICHES[dbpr.niche];
    if (!cfg) return setError("Unknown license type");

    const countyLabel = DBPR_COUNTY_OPTIONS.find((c) => c.value === dbpr.countyCode)?.label ?? "";

    setLoading(true);
    try {
      const res = await fetch("/api/sales-projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          source: "DBPR_LICENSED",
          niche: cfg.boardName + " · " + dbpr.niche,
          // Store the DBPR-niche key in `niche` so the existing scraper config
          // resolution still works downstream.
          dbprNicheKey: dbpr.niche,
          targetLocation: countyLabel ? `${countyLabel} County, FL` : "",
          targetLeadCount: 100, // hard cap on the licensed path
          dbprFilters: {
            kind: dbpr.kind,
            boardCode: cfg.boardCode,
            licenseTypeCodes: cfg.licenseTypeCodes,
            countyCode: dbpr.countyCode,
            countyLabel,
            activeOnly: dbpr.activeOnly,
          },
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to create project");
      router.push(`/prospecting/projects/${data.id}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to create project");
      setLoading(false);
    }
  };

  return (
    <div className="card" style={{ padding: "1.5rem" }}>
      {/* Path selector */}
      <div style={{ marginBottom: "1.5rem" }}>
        <div style={{ fontSize: "0.82rem", fontWeight: 700, color: "var(--text-primary)", marginBottom: 10 }}>
          How are we sourcing prospects?
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <PathCard
            active={path === "DBPR_LICENSED"}
            onClick={() => setPath("DBPR_LICENSED")}
            icon={<Award size={18} />}
            title="Licensed Industry"
            sub="Florida DBPR — contractors & suppliers (HVAC, plumbing, roofing). Pulls 100 actively-licensed businesses, then sends to deep research."
          />
          <PathCard
            active={path === "GOOGLE_GENERAL"}
            onClick={() => setPath("GOOGLE_GENERAL")}
            icon={<Globe size={18} />}
            title="General Search"
            sub="Google Places — any niche by city or ZIP. Great for restaurants, salons, retail, anything not on a license roster."
          />
        </div>
      </div>

      {path === "DBPR_LICENSED" ? (
        <DbprForm dbpr={dbpr} setDbpr={setDbpr} />
      ) : (
        <GoogleForm
          form={form}
          update={update}
          nicheOpen={nicheOpen}
          setNicheOpen={setNicheOpen}
          nicheSearch={nicheSearch}
          setNicheSearch={setNicheSearch}
          nicheRef={nicheRef}
          nicheInputRef={nicheInputRef}
          filteredNiches={filteredNiches}
          selectNiche={selectNiche}
        />
      )}

      {error && (
        <div style={{
          padding: "0.5rem 0.75rem", borderRadius: 8, marginBottom: "1rem",
          background: "#fef2f2", color: "#dc2626", fontSize: "0.75rem", fontWeight: 600,
        }}>
          {error}
        </div>
      )}

      <div style={{ display: "flex", justifyContent: "flex-end", gap: 8 }}>
        <button
          className="btn"
          onClick={() => router.push("/prospecting/projects")}
          style={{ padding: "0.55rem 1rem", fontSize: "0.8rem", borderRadius: 10 }}
        >
          Cancel
        </button>
        <button
          className="btn-primary"
          onClick={handleSubmit}
          disabled={loading}
          style={{
            display: "flex", alignItems: "center", gap: 6,
            padding: "0.55rem 1.2rem", fontSize: "0.8rem", borderRadius: 10,
            opacity: loading ? 0.7 : 1,
          }}
        >
          {loading ? (
            <><Loader2 size={14} className="spin" /> Creating...</>
          ) : (
            <><ArrowRight size={14} /> Create & Start</>
          )}
        </button>
      </div>

      <style>{`
        .spin { animation: spin 1s linear infinite; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}

function PathCard({ active, onClick, icon, title, sub }: {
  active: boolean; onClick: () => void; icon: React.ReactNode; title: string; sub: string;
}) {
  return (
    <div
      onClick={onClick}
      style={{
        cursor: "pointer",
        padding: "0.85rem",
        borderRadius: 12,
        border: active ? "2px solid var(--accent-primary)" : "1.5px solid var(--border-color)",
        background: active ? "var(--accent-primary)08" : "var(--bg-surface)",
        transition: "all 0.15s",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
        <div style={{ color: active ? "var(--accent-primary)" : "var(--text-secondary)" }}>{icon}</div>
        <div style={{ fontSize: "0.85rem", fontWeight: 700, color: "var(--text-primary)" }}>{title}</div>
      </div>
      <div style={{ fontSize: "0.72rem", color: "var(--text-secondary)", lineHeight: 1.4 }}>{sub}</div>
    </div>
  );
}

function DbprForm({
  dbpr, setDbpr,
}: {
  dbpr: { kind: DbprKind; niche: string; countyCode: string; activeOnly: boolean };
  setDbpr: React.Dispatch<React.SetStateAction<{ kind: DbprKind; niche: string; countyCode: string; activeOnly: boolean }>>;
}) {
  return (
    <>
      <FieldLabel n={1}>Search Type</FieldLabel>
      <div style={{ display: "flex", gap: 8, marginBottom: "1.25rem" }}>
        {(["contractor", "supplier"] as DbprKind[]).map((k) => (
          <button
            key={k}
            type="button"
            onClick={() => setDbpr((p) => ({ ...p, kind: k }))}
            style={{
              flex: 1,
              padding: "0.55rem 0.75rem",
              borderRadius: 10,
              border: dbpr.kind === k ? "2px solid var(--accent-primary)" : "1.5px solid var(--border-color)",
              background: dbpr.kind === k ? "var(--accent-primary)08" : "var(--bg-surface)",
              color: dbpr.kind === k ? "var(--accent-primary)" : "var(--text-primary)",
              fontWeight: 700, fontSize: "0.8rem",
              cursor: "pointer",
              textTransform: "capitalize",
            }}
          >
            {k}
          </button>
        ))}
      </div>

      <FieldLabel n={2}>License Type</FieldLabel>
      <select
        value={dbpr.niche}
        onChange={(e) => setDbpr((p) => ({ ...p, niche: e.target.value }))}
        style={{
          width: "100%", padding: "0.55rem 0.75rem",
          borderRadius: 10, border: "1.5px solid var(--border-color)",
          background: "var(--bg-surface)", color: "var(--text-primary)",
          fontSize: "0.8rem", marginBottom: "1.25rem", cursor: "pointer",
        }}
      >
        <option value="">Select a license type…</option>
        {DBPR_NICHE_OPTIONS.map((opt) => (
          <option key={opt.value} value={opt.value}>{opt.label}</option>
        ))}
      </select>

      <FieldLabel n={3}>County</FieldLabel>
      <select
        value={dbpr.countyCode}
        onChange={(e) => setDbpr((p) => ({ ...p, countyCode: e.target.value }))}
        style={{
          width: "100%", padding: "0.55rem 0.75rem",
          borderRadius: 10, border: "1.5px solid var(--border-color)",
          background: "var(--bg-surface)", color: "var(--text-primary)",
          fontSize: "0.8rem", marginBottom: "1.25rem", cursor: "pointer",
        }}
      >
        <option value="">Select a county…</option>
        {DBPR_COUNTY_OPTIONS.map((c) => (
          <option key={c.value} value={c.value}>{c.label}</option>
        ))}
      </select>

      <label style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: "1rem", cursor: "pointer" }}>
        <input
          type="checkbox"
          checked={dbpr.activeOnly}
          onChange={(e) => setDbpr((p) => ({ ...p, activeOnly: e.target.checked }))}
          style={{ accentColor: "var(--accent-primary)" }}
        />
        <span style={{ fontSize: "0.78rem", color: "var(--text-primary)", fontWeight: 600 }}>
          Active licenses only
        </span>
      </label>

      <div style={{
        padding: "0.6rem 0.75rem", borderRadius: 8, background: "#f8fafc",
        border: "1px solid var(--border-color)", marginBottom: "1rem",
        fontSize: "0.72rem", color: "var(--text-secondary)",
      }}>
        Pulls up to <strong>100</strong> licensees. After kickoff you&rsquo;ll see the list and can send any selection to deep research.
      </div>
    </>
  );
}

function GoogleForm({
  form, update,
  nicheOpen, setNicheOpen, nicheSearch, setNicheSearch,
  nicheRef, nicheInputRef, filteredNiches, selectNiche,
}: {
  form: { niche: string; city: string; zipCode: string; targetLeadCount: number };
  update: (k: string, v: string | number) => void;
  nicheOpen: boolean; setNicheOpen: (b: boolean) => void;
  nicheSearch: string; setNicheSearch: (s: string) => void;
  nicheRef: React.RefObject<HTMLDivElement | null>;
  nicheInputRef: React.RefObject<HTMLInputElement | null>;
  filteredNiches: readonly string[];
  selectNiche: (v: string) => void;
}) {
  return (
    <>
      <FieldLabel n={1}>Niche / Industry</FieldLabel>
      <div ref={nicheRef} style={{ position: "relative", marginBottom: "1.5rem" }}>
        <div
          onClick={() => { setNicheOpen(!nicheOpen); setTimeout(() => nicheInputRef.current?.focus(), 50); }}
          style={{
            display: "flex", alignItems: "center", justifyContent: "space-between",
            padding: "0.55rem 0.75rem",
            borderRadius: 10,
            border: nicheOpen ? "1.5px solid var(--accent-primary)" : "1.5px solid var(--border-color)",
            background: "var(--bg-surface)",
            cursor: "pointer",
            transition: "border-color 0.15s",
          }}
        >
          <span style={{
            fontSize: "0.8rem",
            color: form.niche ? "var(--text-primary)" : "var(--text-muted)",
            fontWeight: form.niche ? 600 : 400,
          }}>
            {form.niche || "Select or type a niche..."}
          </span>
          <ChevronDown size={14} style={{
            color: "var(--text-muted)",
            transition: "transform 0.15s",
            transform: nicheOpen ? "rotate(180deg)" : "none",
          }} />
        </div>

        {nicheOpen && (
          <div style={{
            position: "absolute", top: "calc(100% + 4px)", left: 0, right: 0,
            background: "var(--bg-surface)",
            border: "1.5px solid var(--border-color)",
            borderRadius: 10,
            boxShadow: "0 8px 24px rgba(0,0,0,0.12)",
            zIndex: 50,
            overflow: "hidden",
          }}>
            <div style={{ padding: "0.5rem", borderBottom: "1px solid var(--border-color)" }}>
              <div style={{ position: "relative" }}>
                <Search size={13} style={{ position: "absolute", left: 8, top: "50%", transform: "translateY(-50%)", color: "var(--text-muted)" }} />
                <input
                  ref={nicheInputRef}
                  value={nicheSearch}
                  onChange={(e) => setNicheSearch(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && nicheSearch.trim()) {
                      const match = filteredNiches.find((n) => n.toLowerCase() === nicheSearch.toLowerCase());
                      selectNiche(match || nicheSearch.trim());
                    }
                  }}
                  placeholder="Search or type custom..."
                  style={{
                    width: "100%", padding: "0.45rem 0.5rem 0.45rem 1.8rem",
                    border: "1.5px solid var(--border-color)", borderRadius: 8,
                    fontSize: "0.78rem", outline: "none", background: "#f8fafc",
                    color: "var(--text-primary)",
                  }}
                />
              </div>
            </div>

            <div style={{ maxHeight: 220, overflowY: "auto" }}>
              {filteredNiches.map((n) => (
                <div
                  key={n}
                  onClick={() => selectNiche(n)}
                  style={{
                    padding: "0.5rem 0.75rem",
                    fontSize: "0.78rem",
                    color: form.niche === n ? "var(--accent-primary)" : "var(--text-primary)",
                    fontWeight: form.niche === n ? 700 : 500,
                    background: form.niche === n ? "var(--accent-primary)08" : "transparent",
                    cursor: "pointer",
                    transition: "background 0.1s",
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = "#f1f5f9")}
                  onMouseLeave={(e) => (e.currentTarget.style.background = form.niche === n ? "var(--accent-primary)08" : "transparent")}
                >
                  {n}
                </div>
              ))}

              {nicheSearch.trim() && !filteredNiches.some((n) => n.toLowerCase() === nicheSearch.toLowerCase()) && (
                <div
                  onClick={() => selectNiche(nicheSearch.trim())}
                  style={{
                    padding: "0.5rem 0.75rem",
                    fontSize: "0.78rem",
                    color: "var(--accent-primary)",
                    fontWeight: 600,
                    cursor: "pointer",
                    borderTop: "1px solid var(--border-color)",
                    display: "flex", alignItems: "center", gap: 6,
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = "#f1f5f9")}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                >
                  Use &ldquo;{nicheSearch.trim()}&rdquo; as custom niche
                </div>
              )}

              {filteredNiches.length === 0 && !nicheSearch.trim() && (
                <div style={{ padding: "0.75rem", textAlign: "center", fontSize: "0.75rem", color: "var(--text-muted)" }}>
                  No matches found
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      <FieldLabel n={2} hint="Enter a city, ZIP code, or both">Target Location</FieldLabel>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 140px", gap: 10, marginBottom: "1.5rem" }}>
        <div style={{ position: "relative" }}>
          <MapPin size={14} style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "var(--text-muted)" }} />
          <input
            className="input"
            placeholder="City, e.g. Miami, FL"
            value={form.city}
            onChange={(e) => update("city", e.target.value)}
            style={{ width: "100%", padding: "0.55rem 0.75rem 0.55rem 2rem", fontSize: "0.8rem", borderRadius: 10 }}
          />
        </div>
        <input
          className="input"
          placeholder="ZIP code"
          value={form.zipCode}
          onChange={(e) => update("zipCode", e.target.value)}
          style={{ width: "100%", padding: "0.55rem 0.75rem", fontSize: "0.8rem", borderRadius: 10, textAlign: "center" }}
        />
      </div>

      <FieldLabel n={3}>Number of Leads</FieldLabel>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: "0.5rem" }}>
        <input
          type="range"
          min={1}
          max={300}
          value={form.targetLeadCount}
          onChange={(e) => update("targetLeadCount", Number(e.target.value))}
          style={{ flex: 1, accentColor: "var(--accent-primary)" }}
        />
        <div style={{
          minWidth: 56, textAlign: "center", padding: "0.4rem 0.6rem",
          borderRadius: 8, background: "var(--accent-primary)12",
          color: "var(--accent-primary)", fontWeight: 800, fontSize: "0.85rem",
        }}>
          {form.targetLeadCount}
        </div>
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.65rem", color: "var(--text-muted)", marginTop: 4, padding: "0 2px", marginBottom: "1rem" }}>
        <span>1</span>
        <span>150</span>
        <span>300</span>
      </div>

      {form.niche && (form.city || form.zipCode) && (
        <div style={{
          padding: "0.75rem", borderRadius: 10, background: "#f8fafc",
          border: "1px solid var(--border-color)", marginBottom: "1rem",
          fontSize: "0.75rem", color: "var(--text-secondary)",
        }}>
          <strong style={{ color: "var(--text-primary)" }}>Project:</strong>{" "}
          {form.niche} in {[form.city.trim(), form.zipCode.trim()].filter(Boolean).join(", ")} — {form.targetLeadCount} leads
        </div>
      )}
    </>
  );
}

function FieldLabel({ n, hint, children }: { n: number; hint?: string; children: React.ReactNode }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
      <div style={{
        width: 24, height: 24, borderRadius: "50%",
        background: "linear-gradient(135deg, #4318ff, #868cff)",
        color: "white", display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: "0.7rem", fontWeight: 700,
      }}>{n}</div>
      <label style={{ fontSize: "0.82rem", fontWeight: 700, color: "var(--text-primary)" }}>
        {children}
      </label>
      {hint && <span style={{ fontSize: "0.7rem", color: "var(--text-muted)", fontWeight: 400 }}>{hint}</span>}
    </div>
  );
}
