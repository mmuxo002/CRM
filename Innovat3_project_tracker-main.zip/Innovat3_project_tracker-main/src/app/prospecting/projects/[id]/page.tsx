export const dynamic = "force-dynamic";

import { db } from "@/lib/db";
import { requireSession } from "@/lib/rbac";
import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import ProjectDashboard from "./ProjectDashboard";

export default async function SalesProjectPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { user } = await requireSession();
  if (user.role !== "SALES" && user.role !== "ADMIN") return null;

  const { id } = await params;

  const project = await db.salesProject.findUnique({
    where: { id },
    include: {
      creator: { select: { id: true, name: true, email: true } },
      leads: {
        orderBy: { qualificationScore: "desc" },
        include: {
          persona: true,
          preCallBrief: { select: { id: true, headline: true, callOutcome: true, callNotes: true } },
          _count: { select: { outreaches: true } },
          claims: {
            orderBy: { claimedAt: "desc" },
            select: {
              id: true, claimedAt: true, releasedAt: true, releaseReason: true,
              projectNameSnapshot: true, claimedByNameSnapshot: true, lastActivityAt: true,
            },
          },
        },
      },
    },
  });

  if (!project) notFound();

  const stats = {
    total: project.leads.length,
    enriched: project.leads.filter((l) => l.pipelinePhase >= 2).length,
    researched: project.leads.filter((l) => l.persona).length,
    qualified: project.leads.filter((l) => l.qualified).length,
    withOutreach: project.leads.filter((l) => l._count.outreaches > 0).length,
    withBrief: project.leads.filter((l) => l.preCallBrief?.headline).length,
    avgScore:
      project.leads.length > 0
        ? Math.round(project.leads.reduce((sum, l) => sum + l.qualificationScore, 0) / project.leads.length)
        : 0,
  };

  return (
    <div className="animate-slide-up" style={{ padding: "2rem", maxWidth: 1400, margin: "0 auto" }}>
      <div style={{ marginBottom: "1.25rem" }}>
        <Link
          href="/prospecting/projects"
          style={{ display: "inline-flex", alignItems: "center", gap: 4, fontSize: "0.72rem", color: "var(--text-secondary)", textDecoration: "none", marginBottom: 8 }}
        >
          <ArrowLeft size={12} /> Back to Projects
        </Link>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <h1 style={{ fontSize: "1.4rem", fontWeight: 800, color: "var(--text-primary)", margin: 0 }}>
              {project.name}
            </h1>
            <p style={{ color: "var(--text-secondary)", fontSize: "0.78rem", marginTop: 4 }}>
              {project.niche} &middot; {project.targetLocation} &middot; Target: {project.targetLeadCount} leads
              {project.creator?.name && <> &middot; Created by <strong style={{ color: "var(--text-primary)" }}>{project.creator.name}</strong></>}
            </p>
          </div>
        </div>
      </div>

      <ProjectDashboard
        project={JSON.parse(JSON.stringify(project))}
        stats={stats}
      />
    </div>
  );
}
