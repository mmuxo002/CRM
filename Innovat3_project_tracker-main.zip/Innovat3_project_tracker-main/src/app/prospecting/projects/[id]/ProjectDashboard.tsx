"use client";

import { useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import LeadTable from "./components/LeadTable";
import LeadProfileDrawer from "./components/LeadProfileDrawer";
import OpenPoolPanel from "./components/OpenPoolPanel";
import DeepResearchPanel from "./components/DeepResearchPanel";
import {
  Search, Loader2, AlertCircle, Users, Target,
  Brain, Zap, BarChart3, RefreshCw, UserPlus,
} from "lucide-react";

interface ProjectDashboardProps {
  project: any;
  stats: {
    total: number;
    enriched: number;
    researched: number;
    qualified: number;
    withOutreach: number;
    withBrief: number;
    avgScore: number;
  };
}

export default function ProjectDashboard({ project, stats }: ProjectDashboardProps) {
  const router = useRouter();
  const [tab, setTab] = useState<"leads" | "pool">("leads");
  const [selectedLeadId, setSelectedLeadId] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [discoveryStatus, setDiscoveryStatus] = useState<"idle" | "running" | "done" | "error">(
    project.leads.length > 0 ? "done" : "idle"
  );
  const [discoveryMsg, setDiscoveryMsg] = useState("");
  const [batchAction, setBatchAction] = useState<string | null>(null);

  const refresh = useCallback(() => router.refresh(), [router]);
  const selectedLead = project.leads.find((l: any) => l.id === selectedLeadId);

  // --- Multi-select ---
  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const selectAll = () => {
    if (selectedIds.size === project.leads.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(project.leads.map((l: any) => l.id)));
    }
  };

  // --- Discovery + Enrichment ---
  const runDiscovery = async () => {
    setDiscoveryStatus("running");
    setDiscoveryMsg("Discovering businesses & enriching profiles...");
    try {
      const res = await fetch(`/api/sales-projects/${project.id}/discover`, { method: "POST" });
      const data = await res.json();
      if (!res.ok) { setDiscoveryStatus("error"); setDiscoveryMsg(data.error); return; }
      setDiscoveryMsg(data.message);
      setDiscoveryStatus("done");
      refresh();
    } catch (e: any) {
      setDiscoveryStatus("error");
      setDiscoveryMsg(e.message);
    }
  };

  // --- Batch Research All ---
  const researchAll = async () => {
    setBatchAction("research");
    try {
      await fetch(`/api/sales-projects/${project.id}/research`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      refresh();
    } catch {} finally { setBatchAction(null); }
  };

  // --- Batch Qualify All ---
  const qualifyAll = async () => {
    setBatchAction("qualify");
    try {
      await fetch(`/api/sales-projects/${project.id}/qualify`, { method: "POST" });
      refresh();
    } catch {} finally { setBatchAction(null); }
  };

  // --- Add selected leads to pipeline ---
  const addToPipeline = async () => {
    if (selectedIds.size === 0) return;
    setBatchAction("pipeline");
    try {
      const res = await fetch("/api/leads/add-to-pipeline", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ leadIds: [...selectedIds] }),
      });
      const data = await res.json();
      if (res.ok) {
        setSelectedIds(new Set());
        refresh();
      }
    } catch {} finally { setBatchAction(null); }
  };

  const hasLeads = project.leads.length > 0;
  const pipelineCount = project.leads.filter((l: any) =>
    ["PROSPECT", "OUTREACHED", "SCHEDULED", "CLOSED", "NOT_INTERESTED"].includes(l.status)
  ).length;
  // Licensed-path projects park here after kickoff so the rep can pick which
  // leads to push through Google Places + qualification.
  const awaitingDeepResearch =
    project.source === "DBPR_LICENSED" && project.status === "AWAITING_DEEP_RESEARCH";

  return (
    <div>
      {/* Discovery Section */}
      {!hasLeads && discoveryStatus !== "running" && (
        <div className="card" style={{ padding: "2rem", textAlign: "center", marginBottom: "1.25rem" }}>
          <Search size={36} style={{ color: "var(--text-muted)", marginBottom: 12 }} />
          <h3 style={{ fontSize: "1rem", fontWeight: 700, color: "var(--text-primary)", marginBottom: 6 }}>
            Ready to Discover Leads
          </h3>
          <p style={{ fontSize: "0.78rem", color: "var(--text-secondary)", marginBottom: 16, maxWidth: 400, margin: "0 auto 16px" }}>
            Find real businesses in {project.targetLocation}, grab their contact info, emails, and social profiles — all in one step.
          </p>
          <button className="btn-primary" onClick={runDiscovery} style={{
            padding: "0.65rem 1.3rem", fontSize: "0.85rem", borderRadius: 10,
            display: "inline-flex", alignItems: "center", gap: 6,
          }}>
            <Search size={16} /> Discover & Enrich Leads
          </button>
        </div>
      )}

      {/* Status messages */}
      {discoveryStatus === "running" && (
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0.75rem 1rem", borderRadius: 10, background: "#eff6ff", border: "1px solid #bfdbfe", marginBottom: "1.25rem" }}>
          <Loader2 size={16} style={{ color: "#3b82f6", animation: "spin 1s linear infinite" }} />
          <div style={{ fontSize: "0.8rem", fontWeight: 600, color: "#1e40af" }}>{discoveryMsg}</div>
        </div>
      )}

      {discoveryStatus === "error" && (
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0.75rem 1rem", borderRadius: 10, background: "#fef2f2", border: "1px solid #fecaca", marginBottom: "1.25rem" }}>
          <AlertCircle size={16} style={{ color: "#ef4444" }} />
          <div style={{ fontSize: "0.8rem", fontWeight: 600, color: "#991b1b" }}>{discoveryMsg}</div>
        </div>
      )}

      {/* Stats Row */}
      {hasLeads && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: "0.75rem", marginBottom: "1rem" }}>
          {[
            { label: "Discovered", value: stats.total, icon: Users, color: "#3b82f6" },
            { label: "Researched", value: stats.researched, icon: Brain, color: "#8b5cf6" },
            { label: "Qualified", value: stats.qualified, icon: Target, color: "#10b981" },
            { label: "In Pipeline", value: pipelineCount, icon: UserPlus, color: "#f59e0b" },
            { label: "Briefs", value: stats.withBrief, icon: BarChart3, color: "#3b82f6" },
            { label: "Avg Score", value: stats.avgScore, icon: Zap, color: "#ec4899" },
          ].map((s) => (
            <div key={s.label} className="card" style={{ padding: "0.7rem", textAlign: "center" }}>
              <s.icon size={16} style={{ color: s.color, marginBottom: 3 }} />
              <div style={{ fontSize: "1.2rem", fontWeight: 800, color: "var(--text-primary)" }}>{s.value}</div>
              <div style={{ fontSize: "0.63rem", color: "var(--text-secondary)", fontWeight: 600 }}>{s.label}</div>
            </div>
          ))}
        </div>
      )}

      {/* Tab switcher */}
      {hasLeads && (
        <div style={{ display: "flex", gap: 4, marginBottom: "0.75rem", borderBottom: "1px solid var(--border-color)" }}>
          <TabButton active={tab === "leads"} onClick={() => setTab("leads")} label={`Your leads (${project.leads.length})`} />
          <TabButton active={tab === "pool"} onClick={() => setTab("pool")} label="Open Pool" />
        </div>
      )}

      {tab === "pool" && hasLeads && (
        <OpenPoolPanel projectId={project.id} onClaimed={refresh} />
      )}

      {/* Licensed path: pick which DBPR leads to send to deep research */}
      {awaitingDeepResearch && tab === "leads" && (
        <div style={{ marginBottom: "1rem" }}>
          <DeepResearchPanel
            projectId={project.id}
            leads={project.leads}
            onComplete={refresh}
          />
        </div>
      )}

      {/* Action Bar */}
      {hasLeads && tab === "leads" && (
        <div style={{
          display: "flex", alignItems: "center", justifyContent: "space-between",
          marginBottom: "0.75rem", gap: 8, flexWrap: "wrap",
        }}>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            {/* Pipeline action — prominent when items selected */}
            {selectedIds.size > 0 && (
              <button
                onClick={addToPipeline}
                disabled={batchAction === "pipeline"}
                className="btn-primary"
                style={{
                  display: "flex", alignItems: "center", gap: 5,
                  padding: "0.45rem 0.85rem", borderRadius: 8,
                  fontSize: "0.75rem", fontWeight: 700,
                  opacity: batchAction === "pipeline" ? 0.6 : 1,
                }}
              >
                {batchAction === "pipeline" ? <Loader2 size={13} className="spin" /> : <UserPlus size={13} />}
                Add {selectedIds.size} to My Pipeline
              </button>
            )}

            <button onClick={researchAll} disabled={batchAction === "research"} style={{
              display: "flex", alignItems: "center", gap: 4, padding: "0.4rem 0.75rem", borderRadius: 8,
              border: "1.5px solid var(--border-color)", background: "var(--bg-surface)",
              color: "var(--text-primary)", fontSize: "0.73rem", fontWeight: 600, cursor: "pointer",
              opacity: batchAction === "research" ? 0.6 : 1,
            }}>
              {batchAction === "research" ? <Loader2 size={12} className="spin" /> : <Brain size={12} />} Research All
            </button>
            <button onClick={qualifyAll} disabled={batchAction === "qualify"} style={{
              display: "flex", alignItems: "center", gap: 4, padding: "0.4rem 0.75rem", borderRadius: 8,
              border: "1.5px solid var(--border-color)", background: "var(--bg-surface)",
              color: "var(--text-primary)", fontSize: "0.73rem", fontWeight: 600, cursor: "pointer",
              opacity: batchAction === "qualify" ? 0.6 : 1,
            }}>
              {batchAction === "qualify" ? <Loader2 size={12} className="spin" /> : <Target size={12} />} Qualify All
            </button>
            <button onClick={runDiscovery} disabled={discoveryStatus === "running"} style={{
              display: "flex", alignItems: "center", gap: 4, padding: "0.4rem 0.75rem", borderRadius: 8,
              border: "1.5px solid var(--border-color)", background: "var(--bg-surface)",
              color: "var(--text-secondary)", fontSize: "0.73rem", fontWeight: 600, cursor: "pointer",
            }}>
              <RefreshCw size={12} /> Re-discover
            </button>
          </div>
          <span style={{ fontSize: "0.7rem", color: "var(--text-muted)" }}>
            {selectedIds.size > 0
              ? `${selectedIds.size} selected`
              : `${project.leads.length} leads · Click row to view profile`
            }
          </span>
        </div>
      )}

      {/* Lead Table */}
      {hasLeads && tab === "leads" && (
        <LeadTable
          leads={project.leads}
          selectedLeadId={selectedLeadId}
          onSelectLead={(id) => setSelectedLeadId(id === selectedLeadId ? null : id)}
          selectedIds={selectedIds}
          onToggleSelect={toggleSelect}
          onSelectAll={selectAll}
        />
      )}

      {/* Lead Profile Drawer */}
      {selectedLead && (
        <LeadProfileDrawer
          lead={selectedLead}
          projectId={project.id}
          niche={project.niche}
          onClose={() => setSelectedLeadId(null)}
          onRefresh={refresh}
        />
      )}

      <style>{`
        .spin { animation: spin 1s linear infinite; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}

function TabButton({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: "0.5rem 0.9rem", border: "none", background: "transparent",
        color: active ? "var(--text-primary)" : "var(--text-secondary)",
        fontSize: "0.8rem", fontWeight: active ? 700 : 600, cursor: "pointer",
        borderBottom: active ? "2px solid var(--accent-primary)" : "2px solid transparent",
        marginBottom: -1,
      }}
    >
      {label}
    </button>
  );
}
