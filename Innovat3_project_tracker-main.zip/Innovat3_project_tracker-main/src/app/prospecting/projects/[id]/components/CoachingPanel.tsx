"use client";

import { useState } from "react";
import { Loader2, CheckCircle, AlertCircle, Headphones, Save, ChevronDown, ChevronUp, MessageSquare, DollarSign, TrendingUp, Shield } from "lucide-react";

interface CoachingPanelProps {
  project: any;
  selectedLeadId: string | null;
  onSelectLead: (id: string) => void;
  onComplete: () => void;
}

export default function CoachingPanel({ project, selectedLeadId, onSelectLead, onComplete }: CoachingPanelProps) {
  const [status, setStatus] = useState<"idle" | "running" | "done" | "error">("idle");
  const [message, setMessage] = useState("");
  const [coaching, setCoaching] = useState<any>(null);
  const [loadingId, setLoadingId] = useState<string | null>(null);
  const [callNotes, setCallNotes] = useState("");
  const [callOutcome, setCallOutcome] = useState("");
  const [saving, setSaving] = useState(false);
  const [activeSection, setActiveSection] = useState<string>("script");

  const withBrief = project.leads.filter((l: any) => l.preCallBrief);
  const selectedLead = project.leads.find((l: any) => l.id === selectedLeadId);

  const loadCoaching = async (leadId: string) => {
    setLoadingId(leadId);
    onSelectLead(leadId);
    try {
      const res = await fetch(`/api/sales-projects/${project.id}/coach/${leadId}`, { method: "POST" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to load coaching");
      setCoaching(data);
      setCallNotes(data.callNotes || "");
      setCallOutcome(data.callOutcome || "");
    } catch (e: any) {
      setMessage(e.message);
    } finally {
      setLoadingId(null);
    }
  };

  const saveNotes = async () => {
    if (!selectedLeadId) return;
    setSaving(true);
    try {
      await fetch(`/api/sales-projects/${project.id}/coach/${selectedLeadId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ callNotes, callOutcome }),
      });
      onComplete();
    } catch {} finally {
      setSaving(false);
    }
  };

  const OUTCOMES = [
    { value: "OUTREACHED", label: "Outreached", color: "#10b981" },
    { value: "SCHEDULED", label: "Scheduled Appt", color: "#8b5cf6" },
    { value: "NOT_INTERESTED", label: "Not Interested", color: "#ef4444" },
    { value: "CALLBACK", label: "Callback", color: "#f59e0b" },
  ];

  const SECTIONS = [
    { id: "script", label: "Call Script", icon: MessageSquare },
    { id: "objections", label: "Objections", icon: Shield },
    { id: "pricing", label: "Pricing", icon: DollarSign },
    { id: "roi", label: "ROI", icon: TrendingUp },
  ];

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <div>
          <h3 style={{ fontSize: "1rem", fontWeight: 700, color: "var(--text-primary)", margin: 0 }}>
            Sales Coaching
          </h3>
          <p style={{ fontSize: "0.78rem", color: "var(--text-secondary)", marginTop: 4 }}>
            Dynamic call scripts, objection handling, pricing guidance, and ROI projections
          </p>
        </div>
      </div>

      {withBrief.length === 0 && (
        <div style={{ textAlign: "center", padding: "2rem", color: "var(--text-muted)", fontSize: "0.82rem" }}>
          Generate Pre-Call Briefs (Phase 7) first to unlock coaching materials.
        </div>
      )}

      {withBrief.length > 0 && !selectedLeadId && (
        <div>
          <div style={{ fontWeight: 700, fontSize: "0.82rem", color: "var(--text-primary)", marginBottom: 10 }}>
            Select a lead to coach on:
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
            {withBrief.map((lead: any) => (
              <button
                key={lead.id}
                onClick={() => loadCoaching(lead.id)}
                disabled={loadingId === lead.id}
                style={{
                  display: "flex", alignItems: "center", gap: 8,
                  padding: "0.6rem 0.85rem", borderRadius: 8, border: "1px solid var(--border-color)",
                  background: "var(--bg-surface)", cursor: "pointer", textAlign: "left",
                  width: "100%",
                }}
              >
                {loadingId === lead.id ? (
                  <Loader2 size={14} style={{ animation: "spin 1s linear infinite", color: "var(--accent-primary)" }} />
                ) : (
                  <Headphones size={14} style={{ color: "var(--accent-primary)" }} />
                )}
                <span style={{ fontWeight: 600, fontSize: "0.82rem", color: "var(--text-primary)", flex: 1 }}>{lead.name}</span>
                <span style={{
                  padding: "2px 6px", borderRadius: 4, fontSize: "0.65rem", fontWeight: 600,
                  background: lead.preCallBrief?.callOutcome ? "#10b98118" : "#f1f5f9",
                  color: lead.preCallBrief?.callOutcome ? "#10b981" : "var(--text-muted)",
                }}>
                  {lead.preCallBrief?.callOutcome || "Not called"}
                </span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Coaching Interface */}
      {selectedLeadId && coaching && (
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16 }}>
            <button
              onClick={() => { onSelectLead(""); setCoaching(null); }}
              style={{ padding: "0.3rem 0.6rem", borderRadius: 6, border: "1px solid var(--border-color)", background: "var(--bg-surface)", fontSize: "0.72rem", cursor: "pointer", color: "var(--text-secondary)" }}
            >
              Back to list
            </button>
            <span style={{ fontWeight: 700, fontSize: "0.9rem", color: "var(--text-primary)" }}>
              {selectedLead?.name}
            </span>
          </div>

          {/* Section tabs */}
          <div style={{ display: "flex", gap: 4, marginBottom: 16 }}>
            {SECTIONS.map((s) => {
              const Icon = s.icon;
              return (
                <button
                  key={s.id}
                  onClick={() => setActiveSection(s.id)}
                  style={{
                    display: "flex", alignItems: "center", gap: 4,
                    padding: "0.4rem 0.7rem", borderRadius: 8,
                    border: activeSection === s.id ? "2px solid var(--accent-primary)" : "1.5px solid var(--border-color)",
                    background: activeSection === s.id ? "var(--accent-primary)08" : "var(--bg-surface)",
                    color: activeSection === s.id ? "var(--accent-primary)" : "var(--text-secondary)",
                    fontSize: "0.72rem", fontWeight: 600, cursor: "pointer",
                  }}
                >
                  <Icon size={13} /> {s.label}
                </button>
              );
            })}
          </div>

          {/* Content area */}
          <div style={{ padding: "1rem", borderRadius: 10, background: "#f8fafc", border: "1px solid var(--border-color)", marginBottom: 16, minHeight: 200, fontSize: "0.8rem", lineHeight: 1.7, color: "var(--text-secondary)", whiteSpace: "pre-wrap" }}>
            {activeSection === "script" && (coaching.callScript || "Call script will be generated when coaching data is available.")}
            {activeSection === "objections" && (coaching.objectionHandlers || "Objection handlers will appear here.")}
            {activeSection === "pricing" && (coaching.pricingGuidance || "Pricing guidance will appear here.")}
            {activeSection === "roi" && (coaching.roiProjections || "ROI projections will appear here.")}
          </div>

          {/* Call outcome */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontWeight: 700, fontSize: "0.78rem", color: "var(--text-primary)", marginBottom: 8 }}>Call Outcome</div>
            <div style={{ display: "flex", gap: 6 }}>
              {OUTCOMES.map((o) => (
                <button
                  key={o.value}
                  onClick={() => setCallOutcome(o.value)}
                  style={{
                    padding: "0.4rem 0.7rem", borderRadius: 8,
                    border: callOutcome === o.value ? `2px solid ${o.color}` : "1.5px solid var(--border-color)",
                    background: callOutcome === o.value ? `${o.color}12` : "var(--bg-surface)",
                    color: callOutcome === o.value ? o.color : "var(--text-secondary)",
                    fontSize: "0.72rem", fontWeight: 600, cursor: "pointer",
                  }}
                >
                  {o.label}
                </button>
              ))}
            </div>
          </div>

          {/* Call notes */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontWeight: 700, fontSize: "0.78rem", color: "var(--text-primary)", marginBottom: 8 }}>Call Notes</div>
            <textarea
              value={callNotes}
              onChange={(e) => setCallNotes(e.target.value)}
              placeholder="Enter notes from your call..."
              style={{
                width: "100%", minHeight: 120, padding: "0.75rem",
                borderRadius: 10, border: "1.5px solid var(--border-color)",
                fontSize: "0.8rem", lineHeight: 1.5, resize: "vertical",
                fontFamily: "inherit", color: "var(--text-primary)",
              }}
            />
          </div>

          <div style={{ display: "flex", justifyContent: "flex-end" }}>
            <button
              className="btn-primary"
              onClick={saveNotes}
              disabled={saving}
              style={{ display: "flex", alignItems: "center", gap: 5, padding: "0.5rem 1rem", fontSize: "0.78rem", borderRadius: 10 }}
            >
              {saving ? <Loader2 size={13} style={{ animation: "spin 1s linear infinite" }} /> : <Save size={13} />}
              {saving ? "Saving..." : "Save Notes"}
            </button>
          </div>
        </div>
      )}

      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
