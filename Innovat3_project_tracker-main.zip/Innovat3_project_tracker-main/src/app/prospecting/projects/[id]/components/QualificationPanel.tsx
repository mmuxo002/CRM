"use client";

import { useState } from "react";
import { Loader2, CheckCircle, AlertCircle, Target, RefreshCw, Filter } from "lucide-react";

interface QualificationPanelProps {
  project: any;
  onComplete: () => void;
}

export default function QualificationPanel({ project, onComplete }: QualificationPanelProps) {
  const [status, setStatus] = useState<"idle" | "running" | "done" | "error">("idle");
  const [message, setMessage] = useState("");
  const [showQualifiedOnly, setShowQualifiedOnly] = useState(false);

  const qualified = project.leads.filter((l: any) => l.qualified);
  const scored = project.leads.filter((l: any) => l.qualificationScore > 0);
  const hasLeads = project.leads.length > 0;

  const startQualification = async () => {
    setStatus("running");
    setMessage("Scoring and qualifying leads...");

    try {
      const res = await fetch(`/api/sales-projects/${project.id}/qualify`, { method: "POST" });
      const data = await res.json();

      if (!res.ok) {
        setStatus("error");
        setMessage(data.error || "Qualification failed");
        return;
      }

      setStatus("done");
      setMessage(`Scored ${data.scored} leads — ${data.qualified} qualified (threshold: 40+)`);
      onComplete();
    } catch (e: any) {
      setStatus("error");
      setMessage(e.message);
    }
  };

  const displayLeads = showQualifiedOnly
    ? project.leads.filter((l: any) => l.qualified)
    : project.leads.filter((l: any) => l.qualificationScore > 0);

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <div>
          <h3 style={{ fontSize: "1rem", fontWeight: 700, color: "var(--text-primary)", margin: 0 }}>
            Auto-Qualification
          </h3>
          <p style={{ fontSize: "0.78rem", color: "var(--text-secondary)", marginTop: 4 }}>
            Score leads 0-100 based on digital gaps — higher score = bigger opportunity
          </p>
        </div>
        {hasLeads && (
          <button
            className="btn-primary"
            onClick={startQualification}
            disabled={status === "running"}
            style={{ display: "flex", alignItems: "center", gap: 5, padding: "0.5rem 1rem", fontSize: "0.78rem", borderRadius: 10, opacity: status === "running" ? 0.7 : 1 }}
          >
            {status === "running" ? (
              <><Loader2 size={13} style={{ animation: "spin 1s linear infinite" }} /> Qualifying...</>
            ) : scored.length > 0 ? (
              <><RefreshCw size={13} /> Re-qualify</>
            ) : (
              <><Target size={13} /> Run Qualification</>
            )}
          </button>
        )}
      </div>

      {!hasLeads && (
        <div style={{ textAlign: "center", padding: "2rem", color: "var(--text-muted)", fontSize: "0.82rem" }}>
          Run Lead Discovery first.
        </div>
      )}

      {status === "running" && (
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0.75rem 1rem", borderRadius: 10, background: "#fdf2f8", border: "1px solid #fbcfe8", marginBottom: 16 }}>
          <Loader2 size={16} style={{ color: "#ec4899", animation: "spin 1s linear infinite" }} />
          <span style={{ fontSize: "0.8rem", fontWeight: 600, color: "#9d174d" }}>{message}</span>
        </div>
      )}

      {status === "done" && (
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0.75rem 1rem", borderRadius: 10, background: "#f0fdf4", border: "1px solid #bbf7d0", marginBottom: 16 }}>
          <CheckCircle size={16} style={{ color: "#10b981" }} />
          <span style={{ fontSize: "0.8rem", fontWeight: 600, color: "#166534" }}>{message}</span>
        </div>
      )}

      {status === "error" && (
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0.75rem 1rem", borderRadius: 10, background: "#fef2f2", border: "1px solid #fecaca", marginBottom: 16 }}>
          <AlertCircle size={16} style={{ color: "#ef4444" }} />
          <span style={{ fontSize: "0.8rem", fontWeight: 600, color: "#991b1b" }}>{message}</span>
        </div>
      )}

      {/* Stats */}
      {scored.length > 0 && (
        <>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "0.75rem", marginBottom: 16 }}>
            <div style={{ padding: "0.7rem", borderRadius: 10, background: "#10b98112", textAlign: "center" }}>
              <div style={{ fontSize: "1.3rem", fontWeight: 800, color: "#10b981" }}>{qualified.length}</div>
              <div style={{ fontSize: "0.68rem", color: "#166534" }}>Qualified</div>
            </div>
            <div style={{ padding: "0.7rem", borderRadius: 10, background: "#ef444412", textAlign: "center" }}>
              <div style={{ fontSize: "1.3rem", fontWeight: 800, color: "#ef4444" }}>{scored.length - qualified.length}</div>
              <div style={{ fontSize: "0.68rem", color: "#991b1b" }}>Not Qualified</div>
            </div>
            <div style={{ padding: "0.7rem", borderRadius: 10, background: "#3b82f612", textAlign: "center" }}>
              <div style={{ fontSize: "1.3rem", fontWeight: 800, color: "#3b82f6" }}>
                {scored.length > 0 ? Math.round(scored.reduce((s: number, l: any) => s + l.qualificationScore, 0) / scored.length) : 0}
              </div>
              <div style={{ fontSize: "0.68rem", color: "#1e40af" }}>Avg Score</div>
            </div>
            <div style={{ padding: "0.7rem", borderRadius: 10, background: "#f59e0b12", textAlign: "center" }}>
              <div style={{ fontSize: "1.3rem", fontWeight: 800, color: "#f59e0b" }}>
                {qualified.length > 0 ? Math.round((qualified.length / scored.length) * 100) : 0}%
              </div>
              <div style={{ fontSize: "0.68rem", color: "#92400e" }}>Qual Rate</div>
            </div>
          </div>

          {/* Filter toggle */}
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
            <button
              onClick={() => setShowQualifiedOnly(!showQualifiedOnly)}
              style={{
                display: "flex", alignItems: "center", gap: 4,
                padding: "0.35rem 0.7rem", borderRadius: 6, border: "1px solid var(--border-color)",
                background: showQualifiedOnly ? "#10b98118" : "var(--bg-surface)",
                color: showQualifiedOnly ? "#10b981" : "var(--text-secondary)",
                fontSize: "0.72rem", fontWeight: 600, cursor: "pointer",
              }}
            >
              <Filter size={11} /> {showQualifiedOnly ? "Qualified Only" : "Show All"}
            </button>
            <span style={{ fontSize: "0.7rem", color: "var(--text-muted)" }}>
              Showing {displayLeads.length} leads
            </span>
          </div>

          {/* Scored lead list */}
          <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
            {displayLeads.slice(0, 20).map((lead: any) => {
              const services = safeJsonParse(lead.recommendedServices, []);
              return (
                <div key={lead.id} style={{
                  display: "flex", alignItems: "center", gap: 10,
                  padding: "0.55rem 0.75rem", borderRadius: 8, background: "#f8fafc",
                  fontSize: "0.75rem",
                }}>
                  <span style={{
                    padding: "2px 7px", borderRadius: 6, fontWeight: 700, fontSize: "0.72rem",
                    background: lead.qualificationScore >= 70 ? "#10b98118" : lead.qualificationScore >= 40 ? "#f59e0b18" : "#94a3b818",
                    color: lead.qualificationScore >= 70 ? "#10b981" : lead.qualificationScore >= 40 ? "#f59e0b" : "#94a3b8",
                    minWidth: 32, textAlign: "center",
                  }}>
                    {lead.qualificationScore}
                  </span>
                  <span style={{ fontWeight: 600, color: "var(--text-primary)", flex: 1 }}>{lead.name}</span>
                  {lead.qualified && <CheckCircle size={13} style={{ color: "#10b981" }} />}
                  {services.length > 0 && (
                    <span style={{ fontSize: "0.65rem", color: "var(--text-muted)", maxWidth: 200, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                      {services.slice(0, 2).map((s: any) => typeof s === "string" ? s : s.name).join(", ")}
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </>
      )}

      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

function safeJsonParse(str: string | null | undefined, fallback: any) {
  if (!str) return fallback;
  try { return JSON.parse(str); } catch { return fallback; }
}
