"use client";

import { useState } from "react";
import { Loader2, CheckCircle, AlertCircle, Mail, Share2, Link2, RefreshCw } from "lucide-react";

interface EnrichmentPanelProps {
  project: any;
  onComplete: () => void;
}

export default function EnrichmentPanel({ project, onComplete }: EnrichmentPanelProps) {
  const [status, setStatus] = useState<"idle" | "running" | "done" | "error">("idle");
  const [message, setMessage] = useState("");
  const [progress, setProgress] = useState({ current: 0, total: 0 });

  const enriched = project.leads.filter((l: any) => l.pipelinePhase >= 2);
  const needsEnrichment = project.leads.filter((l: any) => l.pipelinePhase < 2 && l.pipelinePhase >= 1);

  const startEnrichment = async () => {
    setStatus("running");
    setMessage("Enriching social profiles...");
    setProgress({ current: 0, total: needsEnrichment.length || project.leads.length });

    try {
      const res = await fetch(`/api/sales-projects/${project.id}/enrich`, { method: "POST" });
      const data = await res.json();

      if (!res.ok) {
        setStatus("error");
        setMessage(data.error || "Enrichment failed");
        return;
      }

      setStatus("done");
      setMessage(`Enriched ${data.enriched} leads — ${data.emailsFound} emails, ${data.socialsFound} social profiles found`);
      onComplete();
    } catch (e: any) {
      setStatus("error");
      setMessage(e.message);
    }
  };

  const hasLeads = project.leads.length > 0;

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <div>
          <h3 style={{ fontSize: "1rem", fontWeight: 700, color: "var(--text-primary)", margin: 0 }}>
            Social Profile Enrichment
          </h3>
          <p style={{ fontSize: "0.78rem", color: "var(--text-secondary)", marginTop: 4 }}>
            Scrape websites + AI discovery to find emails, LinkedIn, and Instagram profiles
          </p>
        </div>
        {hasLeads && (
          <button
            className="btn-primary"
            onClick={startEnrichment}
            disabled={status === "running"}
            style={{ display: "flex", alignItems: "center", gap: 5, padding: "0.5rem 1rem", fontSize: "0.78rem", borderRadius: 10, opacity: status === "running" ? 0.7 : 1 }}
          >
            {status === "running" ? (
              <><Loader2 size={13} style={{ animation: "spin 1s linear infinite" }} /> Enriching...</>
            ) : enriched.length > 0 ? (
              <><RefreshCw size={13} /> Re-enrich</>
            ) : (
              <><Mail size={13} /> Start Enrichment</>
            )}
          </button>
        )}
      </div>

      {!hasLeads && (
        <div style={{ textAlign: "center", padding: "2rem", color: "var(--text-muted)", fontSize: "0.82rem" }}>
          Run Lead Discovery (Phase 2) first to generate leads for enrichment.
        </div>
      )}

      {status === "running" && (
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0.75rem 1rem", borderRadius: 10, background: "#f5f3ff", border: "1px solid #ddd6fe", marginBottom: 16 }}>
          <Loader2 size={16} style={{ color: "#8b5cf6", animation: "spin 1s linear infinite" }} />
          <span style={{ fontSize: "0.8rem", fontWeight: 600, color: "#5b21b6" }}>{message}</span>
        </div>
      )}

      {status === "done" && (
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0.75rem 1rem", borderRadius: 10, background: "#f0fdf4", border: "1px solid #bbf7d0", marginBottom: 16 }}>
          <CheckCircle size={16} style={{ color: "#10b981" }} />
          <span style={{ fontSize: "0.8rem", fontWeight: 600, color: "#166534" }}>{message}</span>
        </div>
      )}

      {status === "error" && (
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0.75rem 1rem", borderRadius: 10, background: "#fef2f2", border: "1px solid #fecaca", marginBottom: 16 }}>
          <AlertCircle size={16} style={{ color: "#ef4444" }} />
          <span style={{ fontSize: "0.8rem", fontWeight: 600, color: "#991b1b" }}>{message}</span>
        </div>
      )}

      {/* Enrichment results summary */}
      {hasLeads && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "0.75rem" }}>
          <div style={{ padding: "0.85rem", borderRadius: 10, background: "#f8fafc", textAlign: "center" }}>
            <Mail size={18} style={{ color: "#6366f1", marginBottom: 4 }} />
            <div style={{ fontSize: "1.2rem", fontWeight: 800, color: "var(--text-primary)" }}>
              {project.leads.filter((l: any) => l.email && l.email !== "").length}
            </div>
            <div style={{ fontSize: "0.68rem", color: "var(--text-secondary)" }}>Emails Found</div>
          </div>
          <div style={{ padding: "0.85rem", borderRadius: 10, background: "#f8fafc", textAlign: "center" }}>
            <Link2 size={18} style={{ color: "#0077b5", marginBottom: 4 }} />
            <div style={{ fontSize: "1.2rem", fontWeight: 800, color: "var(--text-primary)" }}>
              {project.leads.filter((l: any) => l.linkedinUrl).length}
            </div>
            <div style={{ fontSize: "0.68rem", color: "var(--text-secondary)" }}>LinkedIn Found</div>
          </div>
          <div style={{ padding: "0.85rem", borderRadius: 10, background: "#f8fafc", textAlign: "center" }}>
            <Share2 size={18} style={{ color: "#e4405f", marginBottom: 4 }} />
            <div style={{ fontSize: "1.2rem", fontWeight: 800, color: "var(--text-primary)" }}>
              {project.leads.filter((l: any) => l.instagramHandle).length}
            </div>
            <div style={{ fontSize: "0.68rem", color: "var(--text-secondary)" }}>Instagram Found</div>
          </div>
        </div>
      )}

      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
