"use client";

import { Check } from "lucide-react";

interface Phase {
  id: number;
  label: string;
  short: string;
}

interface PhaseTrackerProps {
  phases: Phase[];
  currentPhase: number;
  activeTab: number;
  onTabChange: (phase: number) => void;
}

export default function PhaseTracker({ phases, currentPhase, activeTab, onTabChange }: PhaseTrackerProps) {
  return (
    <div style={{ marginBottom: "1.25rem" }}>
      <div style={{
        display: "flex", gap: 2, borderRadius: 12, overflow: "hidden",
        background: "var(--bg-surface)", border: "1px solid var(--border-color)",
        padding: 3,
      }}>
        {phases.map((phase) => {
          const isComplete = currentPhase > phase.id;
          const isCurrent = currentPhase === phase.id;
          const isActive = activeTab === phase.id;
          const isAccessible = phase.id <= currentPhase + 1;

          return (
            <button
              key={phase.id}
              onClick={() => isAccessible && onTabChange(phase.id)}
              style={{
                flex: 1,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 5,
                padding: "0.55rem 0.4rem",
                border: "none",
                borderRadius: 9,
                cursor: isAccessible ? "pointer" : "not-allowed",
                opacity: isAccessible ? 1 : 0.4,
                fontSize: "0.68rem",
                fontWeight: isActive ? 700 : 600,
                transition: "all 0.15s",
                background: isActive
                  ? "linear-gradient(135deg, #4318ff, #868cff)"
                  : isComplete
                  ? "#10b98118"
                  : "transparent",
                color: isActive
                  ? "white"
                  : isComplete
                  ? "#10b981"
                  : isCurrent
                  ? "var(--accent-primary)"
                  : "var(--text-secondary)",
              }}
            >
              {isComplete && !isActive ? (
                <Check size={11} strokeWidth={3} />
              ) : (
                <span style={{
                  width: 16, height: 16, borderRadius: "50%",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: "0.6rem", fontWeight: 800,
                  background: isActive ? "rgba(255,255,255,0.25)" : isCurrent ? "var(--accent-primary)18" : "var(--border-color)",
                  color: isActive ? "white" : isCurrent ? "var(--accent-primary)" : "var(--text-muted)",
                }}>
                  {phase.id}
                </span>
              )}
              <span style={{ whiteSpace: "nowrap" }}>{phase.short}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
