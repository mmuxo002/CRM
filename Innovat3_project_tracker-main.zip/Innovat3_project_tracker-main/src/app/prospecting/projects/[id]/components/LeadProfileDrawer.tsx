"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  X, Phone, Mail, Globe, MapPin, Link2, Share2, AtSign, UserPlus,
  Brain, Loader2, CheckCircle, Target, FileText, Send,
  MessageSquare, Headphones, Save, ChevronDown, ChevronUp,
  ExternalLink, Copy, Check, Shield, DollarSign, TrendingUp, Eye,
  History, Clock,
} from "lucide-react";
import { WebsitePreview } from "@/components/sales/WebsitePreview";
import { SocialMediaPreview } from "@/components/sales/SocialMediaPreview";

interface LeadProfileDrawerProps {
  lead: any;
  projectId: string;
  niche: string;
  onClose: () => void;
  onRefresh: () => void;
}

type Section = "research" | "qualification" | "brief" | "outreach" | "coaching" | "digital-presence" | "history";

export default function LeadProfileDrawer({ lead, projectId, niche, onClose, onRefresh }: LeadProfileDrawerProps) {
  const router = useRouter();
  const [openSections, setOpenSections] = useState<Set<Section>>(new Set(["research", "qualification"]));
  const [loadingAction, setLoadingAction] = useState<string | null>(null);
  const [coaching, setCoaching] = useState<any>(null);
  const [callNotes, setCallNotes] = useState(lead.preCallBrief?.callNotes || "");
  const [callOutcome, setCallOutcome] = useState(lead.preCallBrief?.callOutcome || "");
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const toggleSection = (s: Section) => {
    setOpenSections((prev) => {
      const next = new Set(prev);
      next.has(s) ? next.delete(s) : next.add(s);
      return next;
    });
  };

  const persona = lead.persona;
  const painPoints = safeJson(persona?.painPoints, []);
  const opportunities = safeJson(persona?.opportunities, []);
  const services = safeJson(lead.recommendedServices, []);
  const brief = lead.preCallBrief;

  // --- Actions ---
  const runResearch = async () => {
    setLoadingAction("research");
    try {
      await fetch(`/api/sales-projects/${projectId}/research`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ leadId: lead.id }),
      });
      onRefresh();
    } catch {} finally { setLoadingAction(null); }
  };

  const generateBrief = async () => {
    setLoadingAction("brief");
    try {
      await fetch(`/api/sales-projects/${projectId}/brief/${lead.id}`, { method: "POST" });
      onRefresh();
    } catch {} finally { setLoadingAction(null); }
  };

  const generateOutreach = async () => {
    setLoadingAction("outreach");
    try {
      await fetch(`/api/sales-projects/${projectId}/outreach`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ leadId: lead.id }),
      });
      onRefresh();
    } catch {} finally { setLoadingAction(null); }
  };

  const loadCoaching = async () => {
    setLoadingAction("coaching");
    try {
      const res = await fetch(`/api/sales-projects/${projectId}/coach/${lead.id}`, { method: "POST" });
      const data = await res.json();
      setCoaching(data);
      setCallNotes(data.callNotes || "");
      setCallOutcome(data.callOutcome || "");
    } catch {} finally { setLoadingAction(null); }
  };

  const saveNotes = async () => {
    setLoadingAction("saving");
    try {
      await fetch(`/api/sales-projects/${projectId}/coach/${lead.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ callNotes, callOutcome }),
      });
      onRefresh();
    } catch {} finally { setLoadingAction(null); }
  };

  const addToPipeline = async () => {
    setLoadingAction("pipeline");
    try {
      await fetch("/api/leads/add-to-pipeline", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ leadIds: [lead.id] }),
      });
      onRefresh();
    } catch {} finally { setLoadingAction(null); }
  };

  const inPipeline = ["PROSPECT", "OUTREACHED", "SCHEDULED", "CLOSED", "NOT_INTERESTED"].includes(lead.status);

  const copyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <>
      {/* Backdrop */}
      <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.3)", zIndex: 98 }} />

      {/* Drawer */}
      <div style={{
        position: "fixed", top: 0, right: 0, bottom: 0, width: 520,
        background: "var(--bg-surface)", zIndex: 99,
        boxShadow: "-8px 0 32px rgba(0,0,0,0.12)",
        display: "flex", flexDirection: "column",
        animation: "slideIn 0.2s ease",
      }}>
        {/* Header */}
        <div style={{
          padding: "1rem 1.25rem", borderBottom: "1px solid var(--border-color)",
          display: "flex", justifyContent: "space-between", alignItems: "center",
        }}>
          <div>
            <h2 style={{ fontSize: "1.05rem", fontWeight: 800, color: "var(--text-primary)", margin: 0 }}>
              {lead.name}
            </h2>
            <div style={{ fontSize: "0.72rem", color: "var(--text-secondary)", marginTop: 3, display: "flex", alignItems: "center", gap: 8 }}>
              {lead.address && <span style={{ display: "flex", alignItems: "center", gap: 3 }}><MapPin size={10} /> {lead.address}</span>}
              {lead.qualificationScore > 0 && (
                <span style={{
                  padding: "1px 6px", borderRadius: 4, fontWeight: 700, fontSize: "0.68rem",
                  background: lead.qualificationScore >= 70 ? "#10b98118" : lead.qualificationScore >= 40 ? "#f59e0b18" : "#94a3b818",
                  color: lead.qualificationScore >= 70 ? "#10b981" : lead.qualificationScore >= 40 ? "#f59e0b" : "#94a3b8",
                }}>
                  Score: {lead.qualificationScore}
                </span>
              )}
            </div>
          </div>
          <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", padding: 4 }}>
            <X size={18} style={{ color: "var(--text-muted)" }} />
          </button>
        </div>

        {/* Pipeline action bar */}
        <div style={{
          padding: "0.6rem 1.25rem", borderBottom: "1px solid var(--border-color)",
          display: "flex", alignItems: "center", justifyContent: "space-between",
          background: inPipeline ? "#3b82f608" : "transparent",
        }}>
          {inPipeline ? (
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <span style={{ padding: "2px 8px", borderRadius: 5, fontSize: "0.7rem", fontWeight: 700, background: "#3b82f618", color: "#3b82f6" }}>
                IN PIPELINE
              </span>
              <span style={{ fontSize: "0.7rem", color: "var(--text-muted)" }}>Status: {lead.status.replace("_", " ")}</span>
            </div>
          ) : (
            <button
              onClick={addToPipeline}
              disabled={loadingAction === "pipeline"}
              className="btn-primary"
              style={{ display: "flex", alignItems: "center", gap: 5, padding: "0.4rem 0.85rem", fontSize: "0.75rem", borderRadius: 8, opacity: loadingAction === "pipeline" ? 0.6 : 1 }}
            >
              {loadingAction === "pipeline" ? <Loader2 size={12} className="spin" /> : <UserPlus size={12} />}
              Add to My Pipeline
            </button>
          )}
        </div>

        {/* Scrollable body */}
        <div style={{ flex: 1, overflowY: "auto", padding: "1rem 1.25rem" }}>

          {/* Ask For — decision maker name front and center */}
          {persona?.decisionMakerName && (
            <div style={{
              marginBottom: 12, padding: "0.65rem 0.75rem", borderRadius: 10,
              background: "linear-gradient(135deg, #f5f3ff, #ede9fe)",
              border: "1.5px solid #c4b5fd",
            }}>
              <div style={{ fontSize: "0.6rem", fontWeight: 800, color: "#7c3aed", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 4 }}>
                Ask For
              </div>
              <div style={{ fontWeight: 800, fontSize: "1rem", color: "var(--text-primary)", lineHeight: 1.2 }}>
                {persona.decisionMakerName}
              </div>
              <div style={{ fontSize: "0.7rem", color: "#6d28d9", fontWeight: 600, marginTop: 3 }}>
                {persona.decisionMakerTitle || "Business Owner / Decision Maker"}
              </div>
            </div>
          )}

          {/* Contact Info */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, fontSize: "0.75rem" }}>
              {lead.phone && (
                <div style={{ display: "flex", alignItems: "center", gap: 6, padding: "0.4rem 0.6rem", borderRadius: 8, background: "#f8fafc" }}>
                  <Phone size={12} style={{ color: "#10b981" }} />
                  <span style={{ color: "var(--text-primary)", fontWeight: 500 }}>{lead.phone}</span>
                </div>
              )}
              {lead.email && lead.email !== "" && (
                <div style={{ display: "flex", alignItems: "center", gap: 6, padding: "0.4rem 0.6rem", borderRadius: 8, background: "#f8fafc" }}>
                  <Mail size={12} style={{ color: "#6366f1" }} />
                  <span style={{ color: "var(--text-primary)", fontWeight: 500, overflow: "hidden", textOverflow: "ellipsis" }}>{lead.email}</span>
                </div>
              )}
              {lead.website && (
                <a href={lead.website} target="_blank" rel="noopener noreferrer" style={{ display: "flex", alignItems: "center", gap: 6, padding: "0.4rem 0.6rem", borderRadius: 8, background: "#f8fafc", textDecoration: "none" }}>
                  <Globe size={12} style={{ color: "#3b82f6" }} />
                  <span style={{ color: "#3b82f6", fontWeight: 500, overflow: "hidden", textOverflow: "ellipsis" }}>Website</span>
                  <ExternalLink size={9} style={{ color: "#3b82f6" }} />
                </a>
              )}
              {!lead.website && (
                <div style={{ display: "flex", alignItems: "center", gap: 6, padding: "0.4rem 0.6rem", borderRadius: 8, background: "#fef2f2" }}>
                  <Globe size={12} style={{ color: "#ef4444" }} />
                  <span style={{ color: "#ef4444", fontWeight: 600 }}>No website</span>
                </div>
              )}
              {lead.instagramHandle && (
                <div style={{ display: "flex", alignItems: "center", gap: 6, padding: "0.4rem 0.6rem", borderRadius: 8, background: "#f8fafc" }}>
                  <Share2 size={12} style={{ color: "#e4405f" }} />
                  <span style={{ color: "var(--text-primary)", fontWeight: 500 }}>{lead.instagramHandle}</span>
                </div>
              )}
              {lead.linkedinUrl && (
                <a href={lead.linkedinUrl} target="_blank" rel="noopener noreferrer" style={{ display: "flex", alignItems: "center", gap: 6, padding: "0.4rem 0.6rem", borderRadius: 8, background: "#f8fafc", textDecoration: "none" }}>
                  <Link2 size={12} style={{ color: "#0077b5" }} />
                  <span style={{ color: "#0077b5", fontWeight: 500 }}>LinkedIn</span>
                </a>
              )}
            </div>
            {lead.googleRating && (
              <div style={{ marginTop: 8, fontSize: "0.7rem", color: "var(--text-muted)" }}>
                Google: {lead.googleRating}/5 ({lead.googleReviewCount || 0} reviews)
              </div>
            )}
          </div>

          {/* === DIGITAL PRESENCE (Website & Social Previews) === */}
          {(lead.website || lead.instagramHandle || lead.facebookUrl || lead.twitterHandle || lead.linkedinUrl) && (
            <CollapsibleSection
              title="Digital Presence"
              icon={<Eye size={14} />}
              color="#3b82f6"
              open={openSections.has("digital-presence")}
              onToggle={() => toggleSection("digital-presence")}
              badge={[lead.website && "Web", (lead.instagramHandle || lead.facebookUrl || lead.twitterHandle || lead.linkedinUrl) && "Social"].filter(Boolean).join(" + ") || undefined}
            >
              {lead.website && (
                <WebsitePreview url={lead.website} compact />
              )}
              <SocialMediaPreview
                instagramHandle={lead.instagramHandle}
                facebookUrl={lead.facebookUrl}
                twitterHandle={lead.twitterHandle}
                linkedinUrl={lead.linkedinUrl}
                compact
              />
            </CollapsibleSection>
          )}

          {/* === RESEARCH SECTION === */}
          <CollapsibleSection
            title="Research"
            icon={<Brain size={14} />}
            color="#8b5cf6"
            open={openSections.has("research")}
            onToggle={() => toggleSection("research")}
            badge={persona ? "Done" : undefined}
          >
            {!persona ? (
              <div style={{ textAlign: "center", padding: "1rem" }}>
                <p style={{ fontSize: "0.78rem", color: "var(--text-muted)", marginBottom: 10 }}>
                  Run AI research to analyze this business — pain points, opportunities, decision maker profile
                </p>
                <button className="btn-primary" onClick={runResearch} disabled={loadingAction === "research"} style={{ padding: "0.45rem 1rem", fontSize: "0.78rem", borderRadius: 8, display: "inline-flex", alignItems: "center", gap: 5, opacity: loadingAction === "research" ? 0.7 : 1 }}>
                  {loadingAction === "research" ? <><Loader2 size={13} className="spin" /> Researching...</> : <><Brain size={13} /> Run Research</>}
                </button>
              </div>
            ) : (
              <div style={{ fontSize: "0.75rem" }}>
                {persona.businessSummary && (
                  <p style={{ color: "var(--text-secondary)", lineHeight: 1.5, marginBottom: 10 }}>{persona.businessSummary}</p>
                )}
                {persona.decisionMakerTitle && (
                  <div style={{ marginBottom: 10, padding: "0.4rem 0.6rem", borderRadius: 6, background: "#f5f3ff" }}>
                    <span style={{ fontWeight: 700, color: "#7c3aed", fontSize: "0.68rem" }}>DECISION MAKER: </span>
                    <span style={{ color: "var(--text-primary)", fontWeight: 600 }}>{persona.decisionMakerTitle}</span>
                    {persona.decisionMakerStyle && <span style={{ color: "var(--text-muted)" }}> · {persona.decisionMakerStyle}</span>}
                  </div>
                )}
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                  {painPoints.length > 0 && (
                    <div>
                      <div style={{ fontWeight: 700, color: "#ef4444", fontSize: "0.68rem", marginBottom: 4 }}>PAIN POINTS</div>
                      <ul style={{ margin: 0, paddingLeft: 14, color: "var(--text-secondary)", fontSize: "0.7rem", lineHeight: 1.6 }}>
                        {painPoints.map((p: string, i: number) => <li key={i}>{p}</li>)}
                      </ul>
                    </div>
                  )}
                  {opportunities.length > 0 && (
                    <div>
                      <div style={{ fontWeight: 700, color: "#10b981", fontSize: "0.68rem", marginBottom: 4 }}>OPPORTUNITIES</div>
                      <ul style={{ margin: 0, paddingLeft: 14, color: "var(--text-secondary)", fontSize: "0.7rem", lineHeight: 1.6 }}>
                        {opportunities.map((o: string, i: number) => <li key={i}>{o}</li>)}
                      </ul>
                    </div>
                  )}
                </div>
                <button onClick={runResearch} disabled={loadingAction === "research"} style={{ marginTop: 8, background: "none", border: "1px solid var(--border-color)", borderRadius: 6, padding: "0.3rem 0.6rem", fontSize: "0.68rem", color: "var(--text-muted)", cursor: "pointer", display: "flex", alignItems: "center", gap: 4 }}>
                  {loadingAction === "research" ? <Loader2 size={10} className="spin" /> : <Brain size={10} />} Re-research
                </button>
              </div>
            )}
          </CollapsibleSection>

          {/* === QUALIFICATION SECTION === */}
          <CollapsibleSection
            title="Qualification"
            icon={<Target size={14} />}
            color="#ec4899"
            open={openSections.has("qualification")}
            onToggle={() => toggleSection("qualification")}
            badge={lead.qualified ? "Qualified" : lead.qualificationScore > 0 ? "Reviewed" : undefined}
            badgeColor={lead.qualified ? "#10b981" : "#f59e0b"}
          >
            {lead.qualificationScore === 0 ? (
              <p style={{ fontSize: "0.78rem", color: "var(--text-muted)", textAlign: "center", padding: "0.5rem" }}>
                Run Research first — qualification runs automatically after.
              </p>
            ) : (
              <div style={{ fontSize: "0.75rem" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
                  <div style={{
                    width: 48, height: 48, borderRadius: 12,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontWeight: 800, fontSize: "1.1rem",
                    background: lead.qualificationScore >= 70 ? "#10b98118" : lead.qualificationScore >= 40 ? "#f59e0b18" : "#94a3b818",
                    color: lead.qualificationScore >= 70 ? "#10b981" : lead.qualificationScore >= 40 ? "#f59e0b" : "#94a3b8",
                  }}>
                    {lead.qualificationScore}
                  </div>
                  <div>
                    <div style={{ fontWeight: 700, color: "var(--text-primary)" }}>
                      {lead.qualified ? "Qualified" : "Not Qualified"}
                    </div>
                    <div style={{ fontSize: "0.68rem", color: "var(--text-muted)", marginTop: 2 }}>
                      {lead.qualificationReason}
                    </div>
                  </div>
                </div>
                {services.length > 0 && (
                  <div>
                    <div style={{ fontWeight: 700, fontSize: "0.68rem", color: "var(--text-primary)", marginBottom: 6, textTransform: "uppercase" }}>Recommended Services</div>
                    <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                      {services.map((s: any, i: number) => {
                        const name = typeof s === "string" ? s : s.name;
                        const tier = typeof s === "string" ? "secondary" : s.tier;
                        const reason = typeof s === "string" ? "" : s.reason;
                        const tierColor = tier === "primary" ? "#ef4444" : tier === "secondary" ? "#f59e0b" : "#94a3b8";
                        return (
                          <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 8, padding: "0.35rem 0.5rem", borderRadius: 6, background: "#f8fafc" }}>
                            <span style={{ padding: "1px 5px", borderRadius: 4, fontSize: "0.6rem", fontWeight: 700, color: tierColor, background: `${tierColor}14`, flexShrink: 0, marginTop: 1 }}>
                              {tier === "primary" ? "CRITICAL" : tier === "secondary" ? "HIGH" : "OPTIONAL"}
                            </span>
                            <div>
                              <div style={{ fontWeight: 600, color: "var(--text-primary)", fontSize: "0.73rem" }}>{name}</div>
                              {reason && <div style={{ fontSize: "0.65rem", color: "var(--text-muted)", marginTop: 1 }}>{reason}</div>}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            )}
          </CollapsibleSection>

          {/* === PRE-CALL BRIEF === */}
          <CollapsibleSection
            title="Pre-Call Brief"
            icon={<FileText size={14} />}
            color="#3b82f6"
            open={openSections.has("brief")}
            onToggle={() => toggleSection("brief")}
            badge={brief?.headline ? "Ready" : undefined}
          >
            {!brief?.headline ? (
              <div style={{ textAlign: "center", padding: "0.75rem" }}>
                <button className="btn-primary" onClick={generateBrief} disabled={loadingAction === "brief"} style={{ padding: "0.45rem 1rem", fontSize: "0.78rem", borderRadius: 8, display: "inline-flex", alignItems: "center", gap: 5, opacity: loadingAction === "brief" ? 0.7 : 1 }}>
                  {loadingAction === "brief" ? <><Loader2 size={13} className="spin" /> Generating...</> : <><FileText size={13} /> Generate Brief</>}
                </button>
              </div>
            ) : (
              <div style={{ fontSize: "0.75rem" }}>
                <div style={{ fontWeight: 700, color: "var(--accent-primary)", marginBottom: 8 }}>{brief.headline}</div>
                {renderJsonList("Talking Points", brief.talkingPoints, "#3b82f6")}
                {renderJsonList("Opening Lines", brief.openingLines, "#10b981")}
                {renderJsonList("Qualification Questions", brief.qualificationQuestions, "#f59e0b")}
              </div>
            )}
          </CollapsibleSection>

          {/* === OUTREACH === */}
          <CollapsibleSection
            title="Outreach"
            icon={<Send size={14} />}
            color="#a855f7"
            open={openSections.has("outreach")}
            onToggle={() => toggleSection("outreach")}
            badge={lead._count?.outreaches > 0 ? `${lead._count.outreaches} msgs` : undefined}
          >
            {lead._count?.outreaches > 0 ? (
              <p style={{ fontSize: "0.75rem", color: "var(--text-secondary)", padding: "0.5rem 0" }}>
                {lead._count.outreaches} messages generated. View from the outreach tab or regenerate below.
              </p>
            ) : null}
            <div style={{ textAlign: "center", padding: "0.5rem" }}>
              <button className="btn-primary" onClick={generateOutreach} disabled={loadingAction === "outreach" || !lead.qualified} style={{ padding: "0.45rem 1rem", fontSize: "0.78rem", borderRadius: 8, display: "inline-flex", alignItems: "center", gap: 5, opacity: (loadingAction === "outreach" || !lead.qualified) ? 0.7 : 1 }}>
                {loadingAction === "outreach" ? <><Loader2 size={13} className="spin" /> Generating...</> : <><Send size={13} /> {lead._count?.outreaches > 0 ? "Regenerate" : "Generate"} Messages</>}
              </button>
              {!lead.qualified && <p style={{ fontSize: "0.68rem", color: "var(--text-muted)", marginTop: 6 }}>Lead must be qualified first</p>}
            </div>
          </CollapsibleSection>

          {/* === COACHING === */}
          <CollapsibleSection
            title="Coaching & Call Notes"
            icon={<Headphones size={14} />}
            color="#f59e0b"
            open={openSections.has("coaching")}
            onToggle={() => toggleSection("coaching")}
          >
            {!coaching && !brief ? (
              <p style={{ fontSize: "0.78rem", color: "var(--text-muted)", textAlign: "center", padding: "0.5rem" }}>
                Generate a Pre-Call Brief first to unlock coaching.
              </p>
            ) : !coaching ? (
              <div style={{ textAlign: "center", padding: "0.75rem" }}>
                <button className="btn-primary" onClick={loadCoaching} disabled={loadingAction === "coaching"} style={{ padding: "0.45rem 1rem", fontSize: "0.78rem", borderRadius: 8, display: "inline-flex", alignItems: "center", gap: 5 }}>
                  {loadingAction === "coaching" ? <><Loader2 size={13} className="spin" /> Loading...</> : <><Headphones size={13} /> Load Coaching</>}
                </button>
              </div>
            ) : (
              <div style={{ fontSize: "0.75rem" }}>
                {/* Script/Objections/Pricing tabs */}
                <CoachingTabs coaching={coaching} />

                {/* Outcome */}
                <div style={{ marginTop: 12 }}>
                  <div style={{ fontWeight: 700, fontSize: "0.72rem", color: "var(--text-primary)", marginBottom: 6 }}>Call Outcome</div>
                  <div style={{ display: "flex", gap: 4 }}>
                    {[
                      { v: "OUTREACHED", l: "Outreached", c: "#10b981" },
                      { v: "SCHEDULED", l: "Scheduled Appt", c: "#8b5cf6" },
                      { v: "NOT_INTERESTED", l: "Not Interested", c: "#ef4444" },
                      { v: "CALLBACK", l: "Callback", c: "#f59e0b" },
                    ].map((o) => (
                      <button key={o.v} onClick={() => setCallOutcome(o.v)} style={{
                        padding: "0.3rem 0.6rem", borderRadius: 6, fontSize: "0.68rem", fontWeight: 600, cursor: "pointer",
                        border: callOutcome === o.v ? `2px solid ${o.c}` : "1.5px solid var(--border-color)",
                        background: callOutcome === o.v ? `${o.c}12` : "var(--bg-surface)",
                        color: callOutcome === o.v ? o.c : "var(--text-secondary)",
                      }}>{o.l}</button>
                    ))}
                  </div>
                </div>

                {/* Notes */}
                <div style={{ marginTop: 10 }}>
                  <div style={{ fontWeight: 700, fontSize: "0.72rem", color: "var(--text-primary)", marginBottom: 6 }}>Call Notes</div>
                  <textarea value={callNotes} onChange={(e) => setCallNotes(e.target.value)} placeholder="Enter notes from your call..." style={{ width: "100%", minHeight: 80, padding: "0.5rem", borderRadius: 8, border: "1.5px solid var(--border-color)", fontSize: "0.75rem", fontFamily: "inherit", resize: "vertical", color: "var(--text-primary)" }} />
                </div>

                <div style={{ marginTop: 8, display: "flex", justifyContent: "flex-end" }}>
                  <button className="btn-primary" onClick={saveNotes} disabled={loadingAction === "saving"} style={{ padding: "0.4rem 0.8rem", fontSize: "0.75rem", borderRadius: 8, display: "flex", alignItems: "center", gap: 5 }}>
                    {loadingAction === "saving" ? <Loader2 size={12} className="spin" /> : <Save size={12} />} Save
                  </button>
                </div>
              </div>
            )}
          </CollapsibleSection>

          {/* === CLAIM HISTORY === */}
          {Array.isArray(lead.claims) && lead.claims.length > 0 && (
            <CollapsibleSection
              title="Contact History"
              icon={<History size={14} />}
              color="#64748b"
              open={openSections.has("history")}
              onToggle={() => toggleSection("history")}
              badge={`${lead.claims.length}`}
              badgeColor="#64748b"
            >
              <ClaimHistory claims={lead.claims} />
            </CollapsibleSection>
          )}
        </div>

        <style>{`
          @keyframes slideIn { from { transform: translateX(100%); } to { transform: translateX(0); } }
          .spin { animation: spin 1s linear infinite; }
          @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        `}</style>
      </div>
    </>
  );
}

function ClaimHistory({ claims }: { claims: Array<{
  id: string; claimedAt: string; releasedAt: string | null; releaseReason: string | null;
  projectNameSnapshot: string; claimedByNameSnapshot: string | null; lastActivityAt: string;
}> }) {
  const fmt = (iso: string) => new Date(iso).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  const reasonLabel = (r: string | null) => {
    if (r === "COOLDOWN_EXPIRED") return "inactive 15+ days — released to pool";
    if (r === "MANUAL_RELEASE") return "manually released";
    if (r === "PROJECT_DELETED") return "project deleted";
    return "released";
  };
  return (
    <div style={{ fontSize: "0.74rem", color: "var(--text-secondary)" }}>
      {claims.map((c, i) => {
        const active = c.releasedAt === null;
        return (
          <div key={c.id} style={{
            padding: "0.5rem 0.2rem",
            borderBottom: i < claims.length - 1 ? "1px dashed var(--border-color)" : "none",
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", gap: 8, alignItems: "baseline" }}>
              <div style={{ fontWeight: 700, color: "var(--text-primary)" }}>
                {c.claimedByNameSnapshot || "Unknown agent"}
                <span style={{ fontWeight: 500, color: "var(--text-muted)" }}> · {c.projectNameSnapshot}</span>
              </div>
              {active && (
                <span style={{ fontSize: "0.65rem", fontWeight: 700, color: "#10b981", background: "#10b98118", padding: "2px 6px", borderRadius: 4 }}>
                  ACTIVE
                </span>
              )}
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 4, marginTop: 3, fontSize: "0.68rem", color: "var(--text-muted)" }}>
              <Clock size={10} />
              Pulled {fmt(c.claimedAt)}
              {c.releasedAt ? ` · ${reasonLabel(c.releaseReason)} on ${fmt(c.releasedAt)}` : ""}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// --- Helper Components ---

function CollapsibleSection({ title, icon, color, open, onToggle, badge, badgeColor, children }: {
  title: string; icon: React.ReactNode; color: string; open: boolean;
  onToggle: () => void; badge?: string; badgeColor?: string; children: React.ReactNode;
}) {
  return (
    <div style={{ marginBottom: 8, borderRadius: 10, border: "1px solid var(--border-color)", overflow: "hidden" }}>
      <div onClick={onToggle} style={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "0.6rem 0.75rem", cursor: "pointer", background: open ? `${color}06` : "#f8fafc",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{ color }}>{icon}</span>
          <span style={{ fontWeight: 700, fontSize: "0.78rem", color: "var(--text-primary)" }}>{title}</span>
          {badge && (
            <span style={{
              padding: "1px 6px", borderRadius: 4, fontSize: "0.6rem", fontWeight: 700,
              background: `${badgeColor || color}14`, color: badgeColor || color,
            }}>{badge}</span>
          )}
        </div>
        {open ? <ChevronUp size={13} style={{ color: "var(--text-muted)" }} /> : <ChevronDown size={13} style={{ color: "var(--text-muted)" }} />}
      </div>
      {open && <div style={{ padding: "0.5rem 0.75rem", borderTop: "1px solid var(--border-color)" }}>{children}</div>}
    </div>
  );
}

function CoachingTabs({ coaching }: { coaching: any }) {
  const [tab, setTab] = useState("script");
  const tabs = [
    { id: "script", label: "Script", icon: MessageSquare },
    { id: "objections", label: "Objections", icon: Shield },
    { id: "pricing", label: "Pricing", icon: DollarSign },
    { id: "roi", label: "ROI", icon: TrendingUp },
  ];

  return (
    <div>
      <div style={{ display: "flex", gap: 3, marginBottom: 8 }}>
        {tabs.map((t) => {
          const Icon = t.icon;
          return (
            <button key={t.id} onClick={() => setTab(t.id)} style={{
              display: "flex", alignItems: "center", gap: 3, padding: "0.3rem 0.5rem",
              borderRadius: 6, fontSize: "0.68rem", fontWeight: 600, cursor: "pointer",
              border: tab === t.id ? "1.5px solid var(--accent-primary)" : "1px solid var(--border-color)",
              background: tab === t.id ? "var(--accent-primary)08" : "transparent",
              color: tab === t.id ? "var(--accent-primary)" : "var(--text-muted)",
            }}><Icon size={11} /> {t.label}</button>
          );
        })}
      </div>
      <div style={{ padding: "0.5rem", borderRadius: 8, background: "#f8fafc", fontSize: "0.73rem", lineHeight: 1.6, color: "var(--text-secondary)", whiteSpace: "pre-wrap", maxHeight: 200, overflowY: "auto" }}>
        {tab === "script" && (coaching.callScript || "Generate coaching to see the call script.")}
        {tab === "objections" && (coaching.objectionHandlers || "—")}
        {tab === "pricing" && (coaching.pricingGuidance || "—")}
        {tab === "roi" && (coaching.roiProjections || "—")}
      </div>
    </div>
  );
}

function renderJsonList(title: string, data: string | null, color: string) {
  const items = safeJson(data, null);
  if (!items || items.length === 0) return null;
  return (
    <div style={{ marginBottom: 8 }}>
      <div style={{ fontWeight: 700, fontSize: "0.68rem", color, marginBottom: 3, textTransform: "uppercase" }}>{title}</div>
      <ul style={{ margin: 0, paddingLeft: 14, color: "var(--text-secondary)", fontSize: "0.72rem", lineHeight: 1.6 }}>
        {items.map((item: string, i: number) => <li key={i}>{item}</li>)}
      </ul>
    </div>
  );
}

function safeJson(str: any, fallback: any) {
  if (!str) return fallback;
  if (typeof str !== "string") return str;
  try { return JSON.parse(str); } catch { return fallback; }
}
