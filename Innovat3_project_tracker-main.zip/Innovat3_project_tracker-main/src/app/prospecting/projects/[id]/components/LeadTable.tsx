"use client";

import { Globe, Mail, Phone, Share2, Link2, CheckCircle, Brain, FileText } from "lucide-react";

interface LeadTableProps {
  leads: any[];
  onSelectLead: (id: string) => void;
  selectedLeadId: string | null;
  selectedIds: Set<string>;
  onToggleSelect: (id: string) => void;
  onSelectAll: () => void;
}

export default function LeadTable({ leads, onSelectLead, selectedLeadId, selectedIds, onToggleSelect, onSelectAll }: LeadTableProps) {
  const allSelected = leads.length > 0 && selectedIds.size === leads.length;

  return (
    <div className="card" style={{ overflow: "hidden" }}>
      <div style={{ overflowX: "auto" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.75rem" }}>
          <thead>
            <tr style={{ borderBottom: "1px solid var(--border-color)", background: "#f8fafc" }}>
              <th style={{ padding: "0.5rem 0.4rem 0.5rem 0.65rem", width: 32 }}>
                <input
                  type="checkbox"
                  checked={allSelected}
                  onChange={onSelectAll}
                  style={{ accentColor: "var(--accent-primary)", cursor: "pointer" }}
                />
              </th>
              {["Business", "Phone", "Website", "Social", "Score", "Services", "Status"].map((h) => (
                <th key={h} style={{ padding: "0.5rem 0.65rem", textAlign: "left", fontWeight: 700, color: "var(--text-secondary)", fontSize: "0.65rem", textTransform: "uppercase", letterSpacing: "0.04em" }}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {leads.map((lead: any) => {
              const services = safeJson(lead.recommendedServices, []);
              const topServices = services.filter((s: any) => (typeof s === "string" ? true : s.tier === "primary")).slice(0, 2);
              const isSelected = selectedLeadId === lead.id;
              const isChecked = selectedIds.has(lead.id);
              const inPipeline = ["PROSPECT", "OUTREACHED", "SCHEDULED", "CLOSED", "NOT_INTERESTED"].includes(lead.status);

              return (
                <tr
                  key={lead.id}
                  style={{
                    borderBottom: "1px solid var(--border-color)",
                    cursor: "pointer",
                    transition: "background 0.1s",
                    background: isChecked ? "var(--accent-primary)06" : isSelected ? "#f8fafc" : "transparent",
                    borderLeft: inPipeline ? "3px solid #3b82f6" : lead.qualified ? "3px solid #10b981" : "3px solid transparent",
                  }}
                  onMouseEnter={(e) => { if (!isSelected && !isChecked) e.currentTarget.style.background = "#f8fafc"; }}
                  onMouseLeave={(e) => { if (!isSelected && !isChecked) e.currentTarget.style.background = "transparent"; }}
                >
                  <td style={{ padding: "0.55rem 0.4rem 0.55rem 0.65rem", width: 32 }} onClick={(e) => e.stopPropagation()}>
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => onToggleSelect(lead.id)}
                      style={{ accentColor: "var(--accent-primary)", cursor: "pointer" }}
                    />
                  </td>
                  <td style={{ padding: "0.55rem 0.65rem" }} onClick={() => onSelectLead(lead.id)}>
                    <div style={{ fontWeight: 600, color: "var(--text-primary)", maxWidth: 200, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{lead.name}</div>
                    {lead.address && <div style={{ fontSize: "0.63rem", color: "var(--text-muted)", marginTop: 1, maxWidth: 200, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{lead.address}</div>}
                  </td>
                  <td style={{ padding: "0.55rem 0.65rem" }} onClick={() => onSelectLead(lead.id)}>
                    {lead.phone ? (
                      <span style={{ display: "flex", alignItems: "center", gap: 3, color: "var(--text-secondary)", fontSize: "0.72rem" }}>
                        <Phone size={10} /> {lead.phone}
                      </span>
                    ) : <span style={{ color: "var(--text-muted)" }}>—</span>}
                  </td>
                  <td style={{ padding: "0.55rem 0.65rem" }} onClick={() => onSelectLead(lead.id)}>
                    {lead.website ? (
                      <span style={{ color: "#3b82f6", fontSize: "0.68rem", fontWeight: 600, display: "flex", alignItems: "center", gap: 3 }}>
                        <Globe size={10} /> Has site
                      </span>
                    ) : (
                      <span style={{ color: "#ef4444", fontSize: "0.68rem", fontWeight: 600 }}>No website</span>
                    )}
                  </td>
                  <td style={{ padding: "0.55rem 0.65rem" }} onClick={() => onSelectLead(lead.id)}>
                    <div style={{ display: "flex", gap: 3 }}>
                      {lead.instagramHandle && <Share2 size={12} style={{ color: "#e4405f" }} />}
                      {lead.linkedinUrl && <Link2 size={12} style={{ color: "#0077b5" }} />}
                      {lead.email && lead.email !== "" && <Mail size={12} style={{ color: "#6366f1" }} />}
                      {!lead.instagramHandle && !lead.linkedinUrl && (!lead.email || lead.email === "") && (
                        <span style={{ color: "var(--text-muted)", fontSize: "0.68rem" }}>—</span>
                      )}
                    </div>
                  </td>
                  <td style={{ padding: "0.55rem 0.65rem" }} onClick={() => onSelectLead(lead.id)}>
                    {lead.qualificationScore > 0 ? (
                      <span style={{
                        padding: "2px 6px", borderRadius: 5, fontSize: "0.68rem", fontWeight: 700,
                        background: lead.qualificationScore >= 70 ? "#10b98118" : lead.qualificationScore >= 40 ? "#f59e0b18" : "#94a3b818",
                        color: lead.qualificationScore >= 70 ? "#10b981" : lead.qualificationScore >= 40 ? "#f59e0b" : "#94a3b8",
                      }}>
                        {lead.qualificationScore}
                      </span>
                    ) : <span style={{ color: "var(--text-muted)" }}>—</span>}
                  </td>
                  <td style={{ padding: "0.55rem 0.65rem" }} onClick={() => onSelectLead(lead.id)}>
                    <div style={{ display: "flex", gap: 3, flexWrap: "wrap" }}>
                      {topServices.map((s: any, i: number) => {
                        const name = typeof s === "string" ? s : s.name;
                        return (
                          <span key={i} style={{
                            padding: "1px 5px", borderRadius: 4, fontSize: "0.6rem", fontWeight: 600,
                            background: "#f1f5f9", color: "var(--text-secondary)",
                            maxWidth: 100, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
                          }}>
                            {name}
                          </span>
                        );
                      })}
                      {topServices.length === 0 && <span style={{ color: "var(--text-muted)", fontSize: "0.68rem" }}>—</span>}
                    </div>
                  </td>
                  <td style={{ padding: "0.55rem 0.65rem" }} onClick={() => onSelectLead(lead.id)}>
                    <div style={{ display: "flex", gap: 4, alignItems: "center" }}>
                      {lead.persona && <span title="Researched"><Brain size={12} style={{ color: "#8b5cf6" }} /></span>}
                      {lead.qualified && <span title="Qualified"><CheckCircle size={12} style={{ color: "#10b981" }} /></span>}
                      {lead.preCallBrief?.headline && <span title="Brief ready"><FileText size={12} style={{ color: "#3b82f6" }} /></span>}
                      {inPipeline && (
                        <span style={{ padding: "1px 5px", borderRadius: 4, fontSize: "0.58rem", fontWeight: 700, background: "#3b82f618", color: "#3b82f6" }}>
                          IN PIPELINE
                        </span>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function safeJson(str: any, fallback: any) {
  if (!str) return fallback;
  if (typeof str !== "string") return str;
  try { return JSON.parse(str); } catch { return fallback; }
}
