"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2, Search, AlertCircle, CheckCircle2, MapPin, Award } from "lucide-react";

interface Lead {
  id: string;
  name: string;
  phone: string | null;
  address: string | null;
  summary: string | null;
  licenseIssuedAt: string | Date | null;
  status: string;
  source: string | null;
}

export default function DeepResearchPanel({
  projectId,
  leads,
  onComplete,
}: {
  projectId: string;
  leads: Lead[];
  onComplete?: () => void;
}) {
  const router = useRouter();
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState({ done: 0, total: 0 });
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);

  const allSelected = useMemo(
    () => leads.length > 0 && selected.size === leads.length,
    [leads.length, selected.size]
  );

  const toggleOne = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleAll = () => {
    setSelected(allSelected ? new Set() : new Set(leads.map((l) => l.id)));
  };

  const submit = async () => {
    if (selected.size === 0) return;
    setRunning(true);
    setError(null);
    setResult(null);
    setProgress({ done: 0, total: selected.size });

    try {
      const res = await fetch(`/api/sales-projects/${projectId}/deep-research`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ leadIds: [...selected] }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Deep research failed");
      setResult(data.message ?? `Deep research complete on ${data.processed} leads.`);
      setSelected(new Set());
      onComplete?.();
      router.refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setRunning(false);
    }
  };

  return (
    <div className="card" style={{ padding: "1.25rem" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "0.85rem", flexWrap: "wrap", gap: 8 }}>
        <div>
          <h3 style={{ fontSize: "1rem", fontWeight: 800, color: "var(--text-primary)", marginBottom: 2 }}>
            Send to Deep Research
          </h3>
          <p style={{ fontSize: "0.74rem", color: "var(--text-secondary)" }}>
            Pulled {leads.length} licensed business{leads.length === 1 ? "" : "es"}. Select any number → Google Places enrichment + website check + qualification.
          </p>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <button
            onClick={toggleAll}
            disabled={running || leads.length === 0}
            style={{
              padding: "0.45rem 0.85rem",
              borderRadius: 8,
              border: "1.5px solid var(--border-color)",
              background: "var(--bg-surface)",
              color: "var(--text-primary)",
              fontSize: "0.75rem",
              fontWeight: 700,
              cursor: running ? "not-allowed" : "pointer",
              opacity: running ? 0.6 : 1,
            }}
          >
            {allSelected ? "Deselect all" : `Select all ${leads.length}`}
          </button>
          <button
            onClick={submit}
            disabled={running || selected.size === 0}
            className="btn-primary"
            style={{
              display: "flex", alignItems: "center", gap: 6,
              padding: "0.5rem 1rem",
              borderRadius: 8,
              fontSize: "0.78rem",
              fontWeight: 700,
              opacity: running || selected.size === 0 ? 0.6 : 1,
              cursor: running || selected.size === 0 ? "not-allowed" : "pointer",
            }}
          >
            {running ? <Loader2 size={13} className="spin" /> : <Search size={13} />}
            {running
              ? `Researching ${progress.done}/${progress.total}…`
              : `Send ${selected.size > 0 ? selected.size : ""} to Deep Research`}
          </button>
        </div>
      </div>

      {error && (
        <div style={{
          display: "flex", alignItems: "center", gap: 8,
          padding: "0.6rem 0.85rem", borderRadius: 8, marginBottom: "0.85rem",
          background: "#fef2f2", color: "#991b1b", fontSize: "0.78rem", fontWeight: 600,
          border: "1px solid #fecaca",
        }}>
          <AlertCircle size={14} /> {error}
        </div>
      )}
      {result && (
        <div style={{
          display: "flex", alignItems: "center", gap: 8,
          padding: "0.6rem 0.85rem", borderRadius: 8, marginBottom: "0.85rem",
          background: "#ecfdf5", color: "#065f46", fontSize: "0.78rem", fontWeight: 600,
          border: "1px solid #a7f3d0",
        }}>
          <CheckCircle2 size={14} /> {result}
        </div>
      )}

      <div style={{
        border: "1px solid var(--border-color)", borderRadius: 10, overflow: "hidden",
      }}>
        <div style={{
          display: "grid",
          gridTemplateColumns: "32px 1.5fr 1fr 0.8fr 0.9fr",
          gap: 0,
          padding: "0.55rem 0.75rem",
          background: "#f8fafc",
          borderBottom: "1px solid var(--border-color)",
          fontSize: "0.68rem",
          fontWeight: 700,
          color: "var(--text-secondary)",
          textTransform: "uppercase",
          letterSpacing: "0.04em",
        }}>
          <input
            type="checkbox"
            checked={allSelected}
            onChange={toggleAll}
            disabled={running || leads.length === 0}
            style={{ accentColor: "var(--accent-primary)", cursor: "pointer" }}
            aria-label="Select all"
          />
          <span>Business</span>
          <span>Address</span>
          <span>Phone</span>
          <span>License</span>
        </div>
        <div style={{ maxHeight: 520, overflowY: "auto" }}>
          {leads.length === 0 && (
            <div style={{ padding: "1.5rem", textAlign: "center", color: "var(--text-muted)", fontSize: "0.8rem" }}>
              No licensees in this project.
            </div>
          )}
          {leads.map((lead) => {
            const checked = selected.has(lead.id);
            const issuedAt = lead.licenseIssuedAt ? new Date(lead.licenseIssuedAt) : null;
            const ageDays = issuedAt ? Math.floor((Date.now() - issuedAt.getTime()) / 86400000) : null;
            const newlyLicensed = ageDays !== null && ageDays < 90;
            return (
              <label
                key={lead.id}
                style={{
                  display: "grid",
                  gridTemplateColumns: "32px 1.5fr 1fr 0.8fr 0.9fr",
                  gap: 0,
                  padding: "0.6rem 0.75rem",
                  borderBottom: "1px solid var(--border-color)",
                  cursor: "pointer",
                  fontSize: "0.78rem",
                  background: checked ? "var(--accent-primary)08" : "transparent",
                  alignItems: "center",
                }}
              >
                <input
                  type="checkbox"
                  checked={checked}
                  onChange={() => toggleOne(lead.id)}
                  disabled={running}
                  style={{ accentColor: "var(--accent-primary)", cursor: "pointer" }}
                />
                <div>
                  <div style={{ fontWeight: 700, color: "var(--text-primary)", display: "flex", alignItems: "center", gap: 6 }}>
                    {lead.name}
                    {newlyLicensed && (
                      <span title={`Licensed ${ageDays}d ago`} style={{
                        display: "inline-flex", alignItems: "center", gap: 3,
                        padding: "1px 6px", borderRadius: 999,
                        background: "#fef3c7", color: "#92400e",
                        fontSize: "0.62rem", fontWeight: 800,
                        textTransform: "uppercase", letterSpacing: "0.04em",
                      }}>
                        <Award size={9} /> New
                      </span>
                    )}
                  </div>
                </div>
                <div style={{ color: "var(--text-secondary)", display: "flex", alignItems: "center", gap: 4 }}>
                  {lead.address ? (
                    <>
                      <MapPin size={11} style={{ color: "var(--text-muted)" }} />
                      <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                        {lead.address}
                      </span>
                    </>
                  ) : (
                    <span style={{ color: "var(--text-muted)" }}>—</span>
                  )}
                </div>
                <div style={{ color: "var(--text-secondary)" }}>
                  {lead.phone || <span style={{ color: "var(--text-muted)" }}>—</span>}
                </div>
                <div style={{ color: "var(--text-secondary)", fontSize: "0.72rem", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {issuedAt
                    ? `Issued ${issuedAt.toLocaleDateString("en-US", { month: "short", year: "numeric" })}`
                    : <span style={{ color: "var(--text-muted)" }}>License date —</span>}
                </div>
              </label>
            );
          })}
        </div>
      </div>

      <style>{`
        .spin { animation: spin 1s linear infinite; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}
