"use client";

import { useState } from "react";
import { Loader2, CheckCircle, AlertCircle, Brain, ChevronDown, ChevronUp, RefreshCw } from "lucide-react";

interface ResearchPanelProps {
  project: any;
  onComplete: () => void;
}

export default function ResearchPanel({ project, onComplete }: ResearchPanelProps) {
  const [status, setStatus] = useState<"idle" | "running" | "done" | "error">("idle");
  const [message, setMessage] = useState("");
  const [expanded, setExpanded] = useState<string | null>(null);

  const researched = project.leads.filter((l: any) => l.persona);
  const hasLeads = project.leads.length > 0;

  const startResearch = async () => {
    setStatus("running");
    setMessage("AI is analyzing businesses...");

    try {
      const res = await fetch(`/api/sales-projects/${project.id}/research`, { method: "POST" });
      const data = await res.json();

      if (!res.ok) {
        setStatus("error");
        setMessage(data.error || "Research failed");
        return;
      }

      setStatus("done");
      setMessage(`Generated ${data.researched} business personas`);
      onComplete();
    } catch (e: any) {
      setStatus("error");
      setMessage(e.message);
    }
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <div>
          <h3 style={{ fontSize: "1rem", fontWeight: 700, color: "var(--text-primary)", margin: 0 }}>
            Deep Business Research
          </h3>
          <p style={{ fontSize: "0.78rem", color: "var(--text-secondary)", marginTop: 4 }}>
            AI-powered analysis of digital presence, decision makers, pain points, and opportunities
          </p>
        </div>
        {hasLeads && (
          <button
            className="btn-primary"
            onClick={startResearch}
            disabled={status === "running"}
            style={{ display: "flex", alignItems: "center", gap: 5, padding: "0.5rem 1rem", fontSize: "0.78rem", borderRadius: 10, opacity: status === "running" ? 0.7 : 1 }}
          >
            {status === "running" ? (
              <><Loader2 size={13} style={{ animation: "spin 1s linear infinite" }} /> Researching...</>
            ) : researched.length > 0 ? (
              <><RefreshCw size={13} /> Re-research</>
            ) : (
              <><Brain size={13} /> Start Research</>
            )}
          </button>
        )}
      </div>

      {!hasLeads && (
        <div style={{ textAlign: "center", padding: "2rem", color: "var(--text-muted)", fontSize: "0.82rem" }}>
          Run Lead Discovery first to generate leads for research.
        </div>
      )}

      {status === "running" && (
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0.75rem 1rem", borderRadius: 10, background: "#fef3c7", border: "1px solid #fde68a", marginBottom: 16 }}>
          <Loader2 size={16} style={{ color: "#f59e0b", animation: "spin 1s linear infinite" }} />
          <span style={{ fontSize: "0.8rem", fontWeight: 600, color: "#92400e" }}>{message}</span>
        </div>
      )}

      {status === "done" && (
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0.75rem 1rem", borderRadius: 10, background: "#f0fdf4", border: "1px solid #bbf7d0", marginBottom: 16 }}>
          <CheckCircle size={16} style={{ color: "#10b981" }} />
          <span style={{ fontSize: "0.8rem", fontWeight: 600, color: "#166534" }}>{message}</span>
        </div>
      )}

      {status === "error" && (
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0.75rem 1rem", borderRadius: 10, background: "#fef2f2", border: "1px solid #fecaca", marginBottom: 16 }}>
          <AlertCircle size={16} style={{ color: "#ef4444" }} />
          <span style={{ fontSize: "0.8rem", fontWeight: 600, color: "#991b1b" }}>{message}</span>
        </div>
      )}

      {/* Persona Cards */}
      {researched.length > 0 && (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {researched.map((lead: any) => {
            const p = lead.persona;
            if (!p) return null;
            const isExpanded = expanded === lead.id;
            const painPoints = safeJsonParse(p.painPoints, []);
            const opportunities = safeJsonParse(p.opportunities, []);
            const challenges = safeJsonParse(p.challenges, []);

            return (
              <div key={lead.id} style={{ borderRadius: 10, border: "1px solid var(--border-color)", overflow: "hidden" }}>
                <div
                  onClick={() => setExpanded(isExpanded ? null : lead.id)}
                  style={{
                    display: "flex", justifyContent: "space-between", alignItems: "center",
                    padding: "0.7rem 1rem", cursor: "pointer", background: "#f8fafc",
                  }}
                >
                  <div>
                    <span style={{ fontWeight: 700, fontSize: "0.82rem", color: "var(--text-primary)" }}>{lead.name}</span>
                    {p.decisionMakerTitle && (
                      <span style={{ fontSize: "0.7rem", color: "var(--text-secondary)", marginLeft: 8 }}>
                        DM: {p.decisionMakerTitle}
                      </span>
                    )}
                  </div>
                  {isExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                </div>
                {isExpanded && (
                  <div style={{ padding: "0.75rem 1rem", fontSize: "0.78rem" }}>
                    {p.businessSummary && (
                      <div style={{ marginBottom: 12, color: "var(--text-secondary)", lineHeight: 1.5 }}>
                        {p.businessSummary}
                      </div>
                    )}
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                      {painPoints.length > 0 && (
                        <div>
                          <div style={{ fontWeight: 700, color: "#ef4444", fontSize: "0.72rem", marginBottom: 4 }}>Pain Points</div>
                          <ul style={{ margin: 0, paddingLeft: 16, color: "var(--text-secondary)", fontSize: "0.72rem", lineHeight: 1.6 }}>
                            {painPoints.map((pp: string, i: number) => <li key={i}>{pp}</li>)}
                          </ul>
                        </div>
                      )}
                      {opportunities.length > 0 && (
                        <div>
                          <div style={{ fontWeight: 700, color: "#10b981", fontSize: "0.72rem", marginBottom: 4 }}>Opportunities</div>
                          <ul style={{ margin: 0, paddingLeft: 16, color: "var(--text-secondary)", fontSize: "0.72rem", lineHeight: 1.6 }}>
                            {opportunities.map((op: string, i: number) => <li key={i}>{op}</li>)}
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

function safeJsonParse(str: string | null | undefined, fallback: any) {
  if (!str) return fallback;
  try { return JSON.parse(str); } catch { return fallback; }
}
