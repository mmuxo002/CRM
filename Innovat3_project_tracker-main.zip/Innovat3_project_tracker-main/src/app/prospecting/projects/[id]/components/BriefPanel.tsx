"use client";

import { useState } from "react";
import { Loader2, CheckCircle, AlertCircle, FileText, Phone, ChevronDown, ChevronUp } from "lucide-react";

interface BriefPanelProps {
  project: any;
  selectedLeadId: string | null;
  onSelectLead: (id: string) => void;
  onComplete: () => void;
}

export default function BriefPanel({ project, selectedLeadId, onSelectLead, onComplete }: BriefPanelProps) {
  const [status, setStatus] = useState<"idle" | "running" | "done" | "error">("idle");
  const [message, setMessage] = useState("");
  const [briefs, setBriefs] = useState<Record<string, any>>({});
  const [loadingBrief, setLoadingBrief] = useState<string | null>(null);
  const [expanded, setExpanded] = useState<string | null>(null);

  const qualified = project.leads.filter((l: any) => l.qualified);
  const withBrief = project.leads.filter((l: any) => l.preCallBrief);

  const generateBrief = async (leadId: string) => {
    setLoadingBrief(leadId);
    try {
      const res = await fetch(`/api/sales-projects/${project.id}/brief/${leadId}`, { method: "POST" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to generate brief");
      setBriefs((prev) => ({ ...prev, [leadId]: data.brief }));
      setExpanded(leadId);
      onComplete();
    } catch (e: any) {
      setMessage(e.message);
    } finally {
      setLoadingBrief(null);
    }
  };

  const generateAll = async () => {
    setStatus("running");
    setMessage("Generating pre-call briefs for all qualified leads...");

    let generated = 0;
    for (const lead of qualified) {
      try {
        const res = await fetch(`/api/sales-projects/${project.id}/brief/${lead.id}`, { method: "POST" });
        if (res.ok) generated++;
      } catch {}
    }

    setStatus("done");
    setMessage(`Generated ${generated} pre-call briefs`);
    onComplete();
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <div>
          <h3 style={{ fontSize: "1rem", fontWeight: 700, color: "var(--text-primary)", margin: 0 }}>
            Pre-Call Briefs
          </h3>
          <p style={{ fontSize: "0.78rem", color: "var(--text-secondary)", marginTop: 4 }}>
            Structured intelligence packages for each qualified lead — talking points, openers, and key questions
          </p>
        </div>
        {qualified.length > 0 && (
          <button
            className="btn-primary"
            onClick={generateAll}
            disabled={status === "running"}
            style={{ display: "flex", alignItems: "center", gap: 5, padding: "0.5rem 1rem", fontSize: "0.78rem", borderRadius: 10, opacity: status === "running" ? 0.7 : 1 }}
          >
            {status === "running" ? (
              <><Loader2 size={13} style={{ animation: "spin 1s linear infinite" }} /> Generating...</>
            ) : (
              <><FileText size={13} /> Generate All Briefs</>
            )}
          </button>
        )}
      </div>

      {qualified.length === 0 && (
        <div style={{ textAlign: "center", padding: "2rem", color: "var(--text-muted)", fontSize: "0.82rem" }}>
          Run Auto-Qualification first — briefs are generated for qualified leads only.
        </div>
      )}

      {status === "running" && (
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0.75rem 1rem", borderRadius: 10, background: "#eff6ff", border: "1px solid #bfdbfe", marginBottom: 16 }}>
          <Loader2 size={16} style={{ color: "#3b82f6", animation: "spin 1s linear infinite" }} />
          <span style={{ fontSize: "0.8rem", fontWeight: 600, color: "#1e40af" }}>{message}</span>
        </div>
      )}

      {status === "done" && (
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0.75rem 1rem", borderRadius: 10, background: "#f0fdf4", border: "1px solid #bbf7d0", marginBottom: 16 }}>
          <CheckCircle size={16} style={{ color: "#10b981" }} />
          <span style={{ fontSize: "0.8rem", fontWeight: 600, color: "#166534" }}>{message}</span>
        </div>
      )}

      {/* Lead list with brief generation */}
      {qualified.length > 0 && (
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {qualified.map((lead: any) => {
            const brief = briefs[lead.id] || (lead.preCallBrief?.headline ? lead.preCallBrief : null);
            const isExpanded = expanded === lead.id;
            const isLoading = loadingBrief === lead.id;

            return (
              <div key={lead.id} style={{ borderRadius: 10, border: "1px solid var(--border-color)", overflow: "hidden" }}>
                <div style={{
                  display: "flex", justifyContent: "space-between", alignItems: "center",
                  padding: "0.6rem 0.85rem", background: "#f8fafc",
                }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, flex: 1 }}>
                    <span style={{ fontWeight: 700, fontSize: "0.82rem", color: "var(--text-primary)" }}>{lead.name}</span>
                    <span style={{
                      padding: "1px 6px", borderRadius: 4, fontSize: "0.65rem", fontWeight: 600,
                      background: lead.qualificationScore >= 70 ? "#10b98118" : "#f59e0b18",
                      color: lead.qualificationScore >= 70 ? "#10b981" : "#f59e0b",
                    }}>
                      {lead.qualificationScore}
                    </span>
                  </div>
                  <div style={{ display: "flex", gap: 6 }}>
                    {!brief && (
                      <button
                        onClick={() => generateBrief(lead.id)}
                        disabled={isLoading}
                        style={{
                          display: "flex", alignItems: "center", gap: 4,
                          padding: "0.3rem 0.6rem", borderRadius: 6, border: "1px solid var(--border-color)",
                          background: "var(--bg-surface)", color: "var(--accent-primary)",
                          fontSize: "0.7rem", fontWeight: 600, cursor: "pointer",
                        }}
                      >
                        {isLoading ? <Loader2 size={11} style={{ animation: "spin 1s linear infinite" }} /> : <FileText size={11} />}
                        {isLoading ? "Generating..." : "Generate Brief"}
                      </button>
                    )}
                    {brief && (
                      <button
                        onClick={() => setExpanded(isExpanded ? null : lead.id)}
                        style={{
                          display: "flex", alignItems: "center", gap: 3,
                          padding: "0.3rem 0.6rem", borderRadius: 6, border: "1px solid var(--border-color)",
                          background: "var(--bg-surface)", color: "var(--text-secondary)",
                          fontSize: "0.7rem", fontWeight: 600, cursor: "pointer",
                        }}
                      >
                        {isExpanded ? <ChevronUp size={11} /> : <ChevronDown size={11} />}
                        {isExpanded ? "Collapse" : "View Brief"}
                      </button>
                    )}
                  </div>
                </div>

                {isExpanded && brief && (
                  <div style={{ padding: "0.85rem", fontSize: "0.78rem", lineHeight: 1.6 }}>
                    {brief.headline && (
                      <div style={{ fontSize: "0.9rem", fontWeight: 700, color: "var(--accent-primary)", marginBottom: 10 }}>
                        {brief.headline}
                      </div>
                    )}
                    {renderJsonSection("Talking Points", brief.talkingPoints, "#3b82f6")}
                    {renderJsonSection("Opening Lines", brief.openingLines, "#10b981")}
                    {renderJsonSection("Qualification Questions", brief.qualificationQuestions, "#f59e0b")}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

function renderJsonSection(title: string, data: string | null | undefined, color: string) {
  const items = safeJsonParse(data);
  if (!items || items.length === 0) return null;

  return (
    <div style={{ marginBottom: 10 }}>
      <div style={{ fontWeight: 700, fontSize: "0.72rem", color, marginBottom: 4, textTransform: "uppercase", letterSpacing: "0.04em" }}>
        {title}
      </div>
      <ul style={{ margin: 0, paddingLeft: 16, color: "var(--text-secondary)", fontSize: "0.75rem" }}>
        {items.map((item: string, i: number) => <li key={i}>{item}</li>)}
      </ul>
    </div>
  );
}

function safeJsonParse(str: string | null | undefined) {
  if (!str) return null;
  try { return JSON.parse(str); } catch { return null; }
}
