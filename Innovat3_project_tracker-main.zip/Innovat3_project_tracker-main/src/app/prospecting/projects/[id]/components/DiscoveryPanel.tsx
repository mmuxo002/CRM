"use client";

import { useState, useEffect, useRef } from "react";
import { Search, Loader2, CheckCircle, AlertCircle, MapPin, RefreshCw } from "lucide-react";

interface DiscoveryPanelProps {
  project: any;
  onComplete: () => void;
}

export default function DiscoveryPanel({ project, onComplete }: DiscoveryPanelProps) {
  const [status, setStatus] = useState<"idle" | "running" | "done" | "error">(
    project.leads.length > 0 ? "done" : "idle"
  );
  const [progress, setProgress] = useState(project.leads.length);
  const [message, setMessage] = useState("");
  const [isMock, setIsMock] = useState(
    project.leads.some((l: any) => l.source === "Mock Data")
  );
  const pollRef = useRef<NodeJS.Timeout | null>(null);

  const startDiscovery = async () => {
    setStatus("running");
    setMessage("Searching for businesses...");
    setProgress(0);

    try {
      const res = await fetch(`/api/sales-projects/${project.id}/discover`, {
        method: "POST",
      });
      const data = await res.json();

      if (!res.ok) {
        setStatus("error");
        setMessage(data.error || "Discovery failed");
        return;
      }

      setProgress(data.discovered || 0);
      setMessage(data.message || `Found ${data.discovered} businesses`);
      setIsMock(!!data.isMock);
      setStatus("done");
      onComplete();
    } catch (e: any) {
      setStatus("error");
      setMessage(e.message || "Discovery failed");
    }
  };

  const discoveredLeads = project.leads.filter((l: any) => l.pipelinePhase >= 1);

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <div>
          <h3 style={{ fontSize: "1rem", fontWeight: 700, color: "var(--text-primary)", margin: 0 }}>
            Lead Discovery
          </h3>
          <p style={{ fontSize: "0.78rem", color: "var(--text-secondary)", marginTop: 4 }}>
            Find real businesses using Google Places API — or generate realistic mock data for development
          </p>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          {status === "done" && (
            <button
              className="btn"
              onClick={startDiscovery}
              style={{ display: "flex", alignItems: "center", gap: 5, padding: "0.5rem 0.9rem", fontSize: "0.78rem", borderRadius: 10 }}
            >
              <RefreshCw size={13} /> Re-discover
            </button>
          )}
          {(status === "idle" || status === "error") && (
            <button
              className="btn-primary"
              onClick={startDiscovery}
              style={{ display: "flex", alignItems: "center", gap: 5, padding: "0.5rem 1rem", fontSize: "0.78rem", borderRadius: 10 }}
            >
              <Search size={14} /> Discover Leads
            </button>
          )}
        </div>
      </div>

      {/* Status indicator */}
      {status === "running" && (
        <div style={{
          display: "flex", alignItems: "center", gap: 10,
          padding: "0.75rem 1rem", borderRadius: 10,
          background: "#eff6ff", border: "1px solid #bfdbfe",
          marginBottom: 16,
        }}>
          <Loader2 size={16} style={{ color: "#3b82f6", animation: "spin 1s linear infinite" }} />
          <div>
            <div style={{ fontSize: "0.8rem", fontWeight: 600, color: "#1e40af" }}>{message}</div>
            <div style={{ fontSize: "0.7rem", color: "#3b82f6", marginTop: 2 }}>
              {progress} / {project.targetLeadCount} leads found
            </div>
          </div>
        </div>
      )}

      {status === "done" && (
        <div style={{
          display: "flex", alignItems: "center", gap: 10,
          padding: "0.75rem 1rem", borderRadius: 10,
          background: "#f0fdf4", border: "1px solid #bbf7d0",
          marginBottom: 16,
        }}>
          <CheckCircle size={16} style={{ color: "#10b981" }} />
          <div>
            <div style={{ fontSize: "0.8rem", fontWeight: 600, color: "#166534" }}>
              Discovery Complete — {discoveredLeads.length} businesses found
            </div>
            <div style={{ fontSize: "0.7rem", color: "#15803d", marginTop: 2 }}>
              {message || `Ready for Phase 3: Social Enrichment`}
            </div>
          </div>
        </div>
      )}

      {status === "error" && (
        <div style={{
          display: "flex", alignItems: "center", gap: 10,
          padding: "0.75rem 1rem", borderRadius: 10,
          background: "#fef2f2", border: "1px solid #fecaca",
          marginBottom: 16,
        }}>
          <AlertCircle size={16} style={{ color: "#ef4444" }} />
          <div>
            <div style={{ fontSize: "0.8rem", fontWeight: 600, color: "#991b1b" }}>Discovery Failed</div>
            <div style={{ fontSize: "0.7rem", color: "#dc2626", marginTop: 2 }}>{message}</div>
          </div>
        </div>
      )}

      {/* Mock data warning */}
      {isMock && status === "done" && (
        <div style={{
          display: "flex", alignItems: "flex-start", gap: 10,
          padding: "0.75rem 1rem", borderRadius: 10,
          background: "#fffbeb", border: "1px solid #fde68a",
          marginBottom: 16,
        }}>
          <AlertCircle size={16} style={{ color: "#d97706", flexShrink: 0, marginTop: 1 }} />
          <div>
            <div style={{ fontSize: "0.8rem", fontWeight: 600, color: "#92400e" }}>
              Demo Mode — Sample Data
            </div>
            <div style={{ fontSize: "0.72rem", color: "#a16207", marginTop: 3, lineHeight: 1.5 }}>
              These are generated sample leads with placeholder names and no real phone numbers.
              To discover real businesses with real contact info, add your <strong>GOOGLE_PLACES_API_KEY</strong> to the <code style={{ background: "#fef3c7", padding: "1px 4px", borderRadius: 3, fontSize: "0.68rem" }}>.env</code> file and re-run discovery.
            </div>
          </div>
        </div>
      )}

      {/* Progress bar */}
      {(status === "running" || status === "done") && (
        <div style={{ marginBottom: 16 }}>
          <div style={{ background: "#f1f5f9", borderRadius: 6, height: 8, overflow: "hidden" }}>
            <div style={{
              height: "100%", borderRadius: 6,
              width: `${Math.min((discoveredLeads.length / project.targetLeadCount) * 100, 100)}%`,
              background: status === "done"
                ? "linear-gradient(90deg, #10b981, #34d399)"
                : "linear-gradient(90deg, #3b82f6, #60a5fa)",
              transition: "width 0.5s ease",
            }} />
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.68rem", color: "var(--text-muted)", marginTop: 4 }}>
            <span>{discoveredLeads.length} discovered</span>
            <span>{project.targetLeadCount} target</span>
          </div>
        </div>
      )}

      {/* Preview of discovered leads */}
      {discoveredLeads.length > 0 && (
        <div style={{ fontSize: "0.75rem" }}>
          <div style={{ fontWeight: 700, color: "var(--text-primary)", marginBottom: 8 }}>
            Preview (first 10)
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
            {discoveredLeads.slice(0, 10).map((lead: any) => (
              <div key={lead.id} style={{
                display: "flex", alignItems: "center", gap: 8,
                padding: "0.45rem 0.6rem", borderRadius: 8, background: "#f8fafc",
              }}>
                <MapPin size={12} style={{ color: "var(--text-muted)", flexShrink: 0 }} />
                <span style={{ fontWeight: 600, color: "var(--text-primary)", flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {lead.name}
                </span>
                <span style={{ color: "var(--text-muted)", fontSize: "0.68rem", flexShrink: 0 }}>
                  {lead.phone || "No phone"}
                </span>
                {lead.website ? (
                  <span style={{ color: "#3b82f6", fontSize: "0.65rem", fontWeight: 600 }}>Has website</span>
                ) : (
                  <span style={{ color: "#ef4444", fontSize: "0.65rem", fontWeight: 600 }}>No website</span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      <style>{`
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}
