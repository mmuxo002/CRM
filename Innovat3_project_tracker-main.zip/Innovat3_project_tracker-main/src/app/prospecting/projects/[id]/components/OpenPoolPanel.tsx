"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Loader2, RefreshCw, Users, Globe, Phone, Mail, Star, UserPlus, CheckCircle2,
} from "lucide-react";

interface PoolLead {
  id: string;
  name: string;
  phone: string | null;
  email: string;
  website: string | null;
  address: string | null;
  location: string | null;
  niche: string | null;
  qualified: boolean;
  qualificationScore: number;
  pipelinePhase: number;
  claims: Array<{
    claimedAt: string;
    releasedAt: string | null;
    releaseReason: string | null;
    projectNameSnapshot: string;
    claimedByNameSnapshot: string | null;
  }>;
  _count: { outreaches: number };
  preCallBrief: { id: string } | null;
  persona: { id: string } | null;
}

export default function OpenPoolPanel({ projectId, onClaimed }: { projectId: string; onClaimed: () => void }) {
  const [leads, setLeads] = useState<PoolLead[]>([]);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [claiming, setClaiming] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/sales-projects/${projectId}/open-pool`);
      const data = await res.json();
      setLeads(res.ok ? data.leads : []);
    } finally {
      setLoading(false);
    }
  }, [projectId]);

  useEffect(() => { load(); }, [load]);

  const toggle = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const claimSelected = async () => {
    if (selected.size === 0) return;
    setClaiming(true);
    try {
      const res = await fetch(`/api/sales-projects/${projectId}/open-pool`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ leadIds: [...selected] }),
      });
      const data = await res.json();
      if (res.ok) {
        setSelected(new Set());
        await load();
        onClaimed();
        if (data.skipped > 0) {
          alert(`${data.claimed} claimed. ${data.skipped} were taken by another agent first.`);
        }
      }
    } finally {
      setClaiming(false);
    }
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "0.75rem" }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: "0.95rem", fontWeight: 700, color: "var(--text-primary)" }}>
            <Users size={15} /> Open Pool
          </div>
          <div style={{ fontSize: "0.72rem", color: "var(--text-secondary)", marginTop: 3 }}>
            Previously pulled leads matching your niche + location — no active agent in the last 15 days. Research is intact.
          </div>
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          {selected.size > 0 && (
            <button
              onClick={claimSelected}
              disabled={claiming}
              className="btn-primary"
              style={{
                display: "flex", alignItems: "center", gap: 5,
                padding: "0.45rem 0.85rem", borderRadius: 8,
                fontSize: "0.75rem", fontWeight: 700,
                opacity: claiming ? 0.6 : 1,
              }}
            >
              {claiming ? <Loader2 size={13} className="spin" /> : <UserPlus size={13} />}
              Claim {selected.size} into this project
            </button>
          )}
          <button
            onClick={load}
            disabled={loading}
            style={{
              display: "flex", alignItems: "center", gap: 4, padding: "0.4rem 0.75rem",
              borderRadius: 8, border: "1.5px solid var(--border-color)",
              background: "var(--bg-surface)", color: "var(--text-secondary)",
              fontSize: "0.73rem", fontWeight: 600, cursor: "pointer",
            }}
          >
            {loading ? <Loader2 size={12} className="spin" /> : <RefreshCw size={12} />} Refresh
          </button>
        </div>
      </div>

      {loading ? (
        <div className="card" style={{ padding: "2rem", textAlign: "center", color: "var(--text-secondary)", fontSize: "0.8rem" }}>
          <Loader2 size={18} className="spin" style={{ marginBottom: 8 }} />
          <div>Loading open pool…</div>
        </div>
      ) : leads.length === 0 ? (
        <div className="card" style={{ padding: "2rem", textAlign: "center" }}>
          <Users size={32} style={{ color: "var(--text-muted)", marginBottom: 10 }} />
          <div style={{ fontSize: "0.85rem", fontWeight: 700, color: "var(--text-primary)", marginBottom: 4 }}>
            No open-pool leads yet
          </div>
          <div style={{ fontSize: "0.72rem", color: "var(--text-secondary)" }}>
            When another project releases leads matching your niche + location, they&apos;ll appear here.
          </div>
        </div>
      ) : (
        <div className="card" style={{ padding: 0, overflow: "hidden" }}>
          {leads.map((lead, i) => {
            const lastClaim = lead.claims[0];
            const isSelected = selected.has(lead.id);
            return (
              <div
                key={lead.id}
                onClick={() => toggle(lead.id)}
                style={{
                  display: "grid",
                  gridTemplateColumns: "24px 2fr 1fr 140px 110px",
                  gap: 10,
                  padding: "0.75rem 1rem",
                  alignItems: "center",
                  borderBottom: i < leads.length - 1 ? "1px solid var(--border-color)" : "none",
                  cursor: "pointer",
                  background: isSelected ? "#eff6ff" : "transparent",
                }}
              >
                <input
                  type="checkbox"
                  checked={isSelected}
                  onChange={() => toggle(lead.id)}
                  onClick={(e) => e.stopPropagation()}
                  style={{ cursor: "pointer" }}
                />
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontWeight: 700, fontSize: "0.85rem", color: "var(--text-primary)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                    {lead.name}
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 3, fontSize: "0.7rem", color: "var(--text-secondary)", flexWrap: "wrap" }}>
                    {lead.phone && <span style={{ display: "flex", alignItems: "center", gap: 3 }}><Phone size={10} />{lead.phone}</span>}
                    {lead.email && <span style={{ display: "flex", alignItems: "center", gap: 3 }}><Mail size={10} />{lead.email}</span>}
                    {lead.website && <span style={{ display: "flex", alignItems: "center", gap: 3 }}><Globe size={10} />site</span>}
                  </div>
                </div>
                <div style={{ fontSize: "0.72rem", color: "var(--text-secondary)", minWidth: 0 }}>
                  <div style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                    {lead.address || lead.location || "—"}
                  </div>
                  {lastClaim && (
                    <div style={{ fontSize: "0.66rem", color: "var(--text-muted)", marginTop: 2, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                      Last: {lastClaim.claimedByNameSnapshot || "—"} · {lastClaim.projectNameSnapshot}
                    </div>
                  )}
                </div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 4, fontSize: "0.66rem" }}>
                  {lead.persona && <Badge color="#8b5cf6" label="Researched" />}
                  {lead.qualified && <Badge color="#10b981" label="Qualified" icon={<CheckCircle2 size={9} />} />}
                  {lead._count.outreaches > 0 && <Badge color="#f59e0b" label={`${lead._count.outreaches} msgs`} />}
                  {lead.preCallBrief && <Badge color="#3b82f6" label="Brief" />}
                </div>
                <div style={{ textAlign: "right" }}>
                  {lead.qualified ? (
                    <div style={{ display: "inline-flex", alignItems: "center", gap: 3, fontSize: "0.8rem", fontWeight: 700, color: "#10b981" }}>
                      <Star size={11} /> {lead.qualificationScore}
                    </div>
                  ) : (
                    <div style={{ fontSize: "0.7rem", color: "var(--text-muted)" }}>unscored</div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      <style>{`
        .spin { animation: spin 1s linear infinite; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}

function Badge({ color, label, icon }: { color: string; label: string; icon?: React.ReactNode }) {
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 3,
      padding: "2px 6px", borderRadius: 5,
      background: `${color}18`, color, fontWeight: 600,
    }}>
      {icon}{label}
    </span>
  );
}
