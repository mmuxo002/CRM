"use client";

import { useState } from "react";
import { Loader2, CheckCircle, AlertCircle, Send, Copy, Check, RefreshCw, AtSign, MessageSquare, Mail, Globe, Link2, Share2 } from "lucide-react";

interface OutreachPanelProps {
  project: any;
  onComplete: () => void;
}

const PLATFORM_CONFIG: Record<string, { icon: any; color: string; label: string }> = {
  INSTAGRAM: { icon: Share2, color: "#e4405f", label: "Instagram" },
  LINKEDIN: { icon: Link2, color: "#0077b5", label: "LinkedIn" },
  FACEBOOK: { icon: Globe, color: "#1877f2", label: "Facebook" },
  TWITTER: { icon: AtSign, color: "#1da1f2", label: "X / Twitter" },
  SMS: { icon: MessageSquare, color: "#10b981", label: "SMS" },
  EMAIL: { icon: Mail, color: "#6366f1", label: "Email" },
};

export default function OutreachPanel({ project, onComplete }: OutreachPanelProps) {
  const [status, setStatus] = useState<"idle" | "running" | "done" | "error">("idle");
  const [message, setMessage] = useState("");
  const [activePlatform, setActivePlatform] = useState("INSTAGRAM");
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const qualified = project.leads.filter((l: any) => l.qualified);
  const withOutreach = project.leads.filter((l: any) => l._count.outreaches > 0);

  const startOutreach = async () => {
    setStatus("running");
    setMessage("Generating personalized outreach messages...");

    try {
      const res = await fetch(`/api/sales-projects/${project.id}/outreach`, { method: "POST" });
      const data = await res.json();

      if (!res.ok) {
        setStatus("error");
        setMessage(data.error || "Outreach generation failed");
        return;
      }

      setStatus("done");
      setMessage(`Generated ${data.messagesCreated} messages for ${data.leadsProcessed} leads`);
      onComplete();
    } catch (e: any) {
      setStatus("error");
      setMessage(e.message);
    }
  };

  const copyToClipboard = async (text: string, id: string) => {
    await navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <div>
          <h3 style={{ fontSize: "1rem", fontWeight: 700, color: "var(--text-primary)", margin: 0 }}>
            Outreach Generation
          </h3>
          <p style={{ fontSize: "0.78rem", color: "var(--text-secondary)", marginTop: 4 }}>
            Personalized intro + follow-up messages for Instagram, LinkedIn, Facebook, Twitter, SMS & Email
          </p>
        </div>
        {qualified.length > 0 && (
          <button
            className="btn-primary"
            onClick={startOutreach}
            disabled={status === "running"}
            style={{ display: "flex", alignItems: "center", gap: 5, padding: "0.5rem 1rem", fontSize: "0.78rem", borderRadius: 10, opacity: status === "running" ? 0.7 : 1 }}
          >
            {status === "running" ? (
              <><Loader2 size={13} style={{ animation: "spin 1s linear infinite" }} /> Generating...</>
            ) : withOutreach.length > 0 ? (
              <><RefreshCw size={13} /> Regenerate</>
            ) : (
              <><Send size={13} /> Generate Outreach</>
            )}
          </button>
        )}
      </div>

      {qualified.length === 0 && (
        <div style={{ textAlign: "center", padding: "2rem", color: "var(--text-muted)", fontSize: "0.82rem" }}>
          Run Auto-Qualification (Phase 5) first — outreach is only generated for qualified leads.
        </div>
      )}

      {status === "running" && (
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0.75rem 1rem", borderRadius: 10, background: "#fdf4ff", border: "1px solid #f5d0fe", marginBottom: 16 }}>
          <Loader2 size={16} style={{ color: "#a855f7", animation: "spin 1s linear infinite" }} />
          <span style={{ fontSize: "0.8rem", fontWeight: 600, color: "#7e22ce" }}>{message}</span>
        </div>
      )}

      {status === "done" && (
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0.75rem 1rem", borderRadius: 10, background: "#f0fdf4", border: "1px solid #bbf7d0", marginBottom: 16 }}>
          <CheckCircle size={16} style={{ color: "#10b981" }} />
          <span style={{ fontSize: "0.8rem", fontWeight: 600, color: "#166534" }}>{message}</span>
        </div>
      )}

      {status === "error" && (
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0.75rem 1rem", borderRadius: 10, background: "#fef2f2", border: "1px solid #fecaca", marginBottom: 16 }}>
          <AlertCircle size={16} style={{ color: "#ef4444" }} />
          <span style={{ fontSize: "0.8rem", fontWeight: 600, color: "#991b1b" }}>{message}</span>
        </div>
      )}

      {/* Platform tabs */}
      {withOutreach.length > 0 && (
        <>
          <div style={{ display: "flex", gap: 4, marginBottom: 16, flexWrap: "wrap" }}>
            {Object.entries(PLATFORM_CONFIG).map(([key, cfg]) => {
              const Icon = cfg.icon;
              return (
                <button
                  key={key}
                  onClick={() => setActivePlatform(key)}
                  style={{
                    display: "flex", alignItems: "center", gap: 4,
                    padding: "0.4rem 0.7rem", borderRadius: 8,
                    border: activePlatform === key ? `2px solid ${cfg.color}` : "1.5px solid var(--border-color)",
                    background: activePlatform === key ? `${cfg.color}12` : "var(--bg-surface)",
                    color: activePlatform === key ? cfg.color : "var(--text-secondary)",
                    fontSize: "0.72rem", fontWeight: 600, cursor: "pointer",
                  }}
                >
                  <Icon size={13} /> {cfg.label}
                </button>
              );
            })}
          </div>

          <div style={{ fontSize: "0.78rem", color: "var(--text-muted)", marginBottom: 12 }}>
            Messages will be loaded when outreach is generated. Use the button above to generate messages for all qualified leads.
          </div>
        </>
      )}

      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
