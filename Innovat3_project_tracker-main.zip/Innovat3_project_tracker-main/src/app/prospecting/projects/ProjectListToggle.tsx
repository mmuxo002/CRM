"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { MapPin, Users, Zap, ChevronRight, LayoutGrid, List, Trash2, Loader2 } from "lucide-react";

interface Project {
  id: string;
  name: string;
  niche: string;
  targetLocation: string;
  targetLeadCount: number;
  status: string;
  currentPhase: number;
  createdAt: string;
  creator: { name: string | null } | null;
  _count: { leads: number };
}

interface ProjectListToggleProps {
  projects: Project[];
  qualifiedCounts: number[];
  phaseLabels: Record<number, string>;
  statusColors: Record<string, string>;
  isAdmin: boolean;
}

export function ProjectListToggle({ projects, qualifiedCounts, phaseLabels, statusColors, isAdmin }: ProjectListToggleProps) {
  const router = useRouter();
  const [view, setView] = useState<"cards" | "list">("cards");
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const deleteProject = async (e: React.MouseEvent, project: Project) => {
    e.preventDefault();
    e.stopPropagation();
    const leadSuffix = project._count.leads
      ? `\n\n${project._count.leads} lead${project._count.leads === 1 ? "" : "s"} will be released back to the open pool — their research stays intact.`
      : "";
    if (!confirm(`Delete "${project.name}"?${leadSuffix}\n\nThis cannot be undone.`)) return;
    setDeletingId(project.id);
    try {
      const res = await fetch(`/api/sales-projects/${project.id}`, { method: "DELETE" });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        alert(data.error || "Delete failed");
        return;
      }
      router.refresh();
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div>
      {/* View toggle */}
      <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: "0.75rem" }}>
        <div style={{
          display: "inline-flex", borderRadius: 8, overflow: "hidden",
          border: "1.5px solid var(--border-color)",
        }}>
          <button
            onClick={() => setView("cards")}
            style={{
              display: "flex", alignItems: "center", gap: 4,
              padding: "0.35rem 0.7rem", border: "none",
              background: view === "cards" ? "var(--accent-primary)" : "var(--bg-surface)",
              color: view === "cards" ? "white" : "var(--text-secondary)",
              fontSize: "0.75rem", fontWeight: 600, cursor: "pointer",
            }}
          >
            <LayoutGrid size={13} /> Cards
          </button>
          <button
            onClick={() => setView("list")}
            style={{
              display: "flex", alignItems: "center", gap: 4,
              padding: "0.35rem 0.7rem", border: "none",
              borderLeft: "1.5px solid var(--border-color)",
              background: view === "list" ? "var(--accent-primary)" : "var(--bg-surface)",
              color: view === "list" ? "white" : "var(--text-secondary)",
              fontSize: "0.75rem", fontWeight: 600, cursor: "pointer",
            }}
          >
            <List size={13} /> List
          </button>
        </div>
      </div>

      {view === "cards" ? (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(340px, 1fr))", gap: "1rem" }}>
          {projects.map((project, i) => (
            <Link key={project.id} href={`/prospecting/projects/${project.id}`} style={{ textDecoration: "none" }}>
              <div
                className="card project-card-hover"
                style={{
                  padding: "1.25rem", cursor: "pointer",
                  transition: "box-shadow 0.15s, transform 0.15s",
                  position: "relative", overflow: "hidden",
                }}
              >
                {/* Status bar */}
                <div style={{
                  position: "absolute", top: 0, left: 0, right: 0, height: 3,
                  background: statusColors[project.status] || "#94a3b8",
                }} />

                {isAdmin && (
                  <button
                    onClick={(e) => deleteProject(e, project)}
                    disabled={deletingId === project.id}
                    title="Delete project (admin)"
                    style={{
                      position: "absolute", top: 8, right: 8,
                      width: 26, height: 26, borderRadius: 6,
                      border: "none", background: "transparent",
                      color: "#ef4444", cursor: "pointer",
                      display: "flex", alignItems: "center", justifyContent: "center",
                      opacity: deletingId === project.id ? 0.5 : 0.55,
                    }}
                    onMouseEnter={(e) => { e.currentTarget.style.opacity = "1"; e.currentTarget.style.background = "#fef2f2"; }}
                    onMouseLeave={(e) => { e.currentTarget.style.opacity = deletingId === project.id ? "0.5" : "0.55"; e.currentTarget.style.background = "transparent"; }}
                  >
                    {deletingId === project.id ? <Loader2 size={13} className="spin" /> : <Trash2 size={13} />}
                  </button>
                )}

                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <h3 style={{ fontSize: "0.95rem", fontWeight: 700, color: "var(--text-primary)", margin: 0, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                      {project.name}
                    </h3>
                    <div style={{ display: "flex", alignItems: "center", gap: 12, marginTop: 6, fontSize: "0.72rem", color: "var(--text-secondary)" }}>
                      <span style={{ display: "flex", alignItems: "center", gap: 3 }}>
                        <MapPin size={12} /> {project.targetLocation}
                      </span>
                      <span style={{ display: "flex", alignItems: "center", gap: 3 }}>
                        <Users size={12} /> {project._count.leads}/{project.targetLeadCount} leads
                      </span>
                      {project.creator?.name && (
                        <span style={{ fontSize: "0.68rem", color: "var(--text-muted)" }}>
                          by {project.creator.name}
                        </span>
                      )}
                    </div>
                  </div>
                  <ChevronRight size={16} style={{ color: "var(--text-muted)", flexShrink: 0, marginTop: 2 }} />
                </div>

                {/* Progress bar */}
                <div style={{ background: "#f1f5f9", borderRadius: 4, height: 6, marginBottom: 10, overflow: "hidden" }}>
                  <div style={{
                    height: "100%", borderRadius: 4,
                    width: `${Math.round((project._count.leads / project.targetLeadCount) * 100)}%`,
                    background: `linear-gradient(90deg, ${statusColors[project.status] || "#94a3b8"}, ${statusColors[project.status] || "#94a3b8"}88)`,
                    transition: "width 0.3s",
                  }} />
                </div>

                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{
                    display: "inline-flex", alignItems: "center", gap: 4,
                    fontSize: "0.68rem", fontWeight: 600,
                    padding: "3px 8px", borderRadius: 6,
                    background: `${statusColors[project.status] || "#94a3b8"}18`,
                    color: statusColors[project.status] || "#94a3b8",
                  }}>
                    <Zap size={10} />
                    {phaseLabels[project.currentPhase] || `Phase ${project.currentPhase}`}
                  </span>
                  <span style={{ fontSize: "0.68rem", color: "var(--text-muted)" }}>
                    {qualifiedCounts[i]} qualified
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      ) : (
        /* List view */
        <div className="card" style={{ padding: 0, overflow: "hidden" }}>
          {/* Header row */}
          <div style={{
            display: "grid",
            gridTemplateColumns: isAdmin
              ? "2fr 1fr 1fr 120px 100px 80px 32px 32px"
              : "2fr 1fr 1fr 120px 100px 80px 32px",
            gap: 8,
            padding: "0.65rem 1rem",
            background: "#f8fafc",
            borderBottom: "1px solid var(--border-color)",
            fontSize: "0.68rem",
            fontWeight: 700,
            color: "var(--text-secondary)",
            textTransform: "uppercase",
            letterSpacing: "0.04em",
          }}>
            <span>Project</span>
            <span>Location</span>
            <span>Niche</span>
            <span>Leads</span>
            <span>Phase</span>
            <span>Qualified</span>
            <span />
            {isAdmin && <span />}
          </div>

          {projects.map((project, i) => {
            const pct = Math.round((project._count.leads / project.targetLeadCount) * 100);
            const color = statusColors[project.status] || "#94a3b8";
            return (
              <Link
                key={project.id}
                href={`/prospecting/projects/${project.id}`}
                style={{ textDecoration: "none", display: "block" }}
              >
                <div
                  className="project-list-row"
                  style={{
                    display: "grid",
                    gridTemplateColumns: isAdmin
                      ? "2fr 1fr 1fr 120px 100px 80px 32px 32px"
                      : "2fr 1fr 1fr 120px 100px 80px 32px",
                    gap: 8,
                    padding: "0.75rem 1rem",
                    alignItems: "center",
                    borderBottom: "1px solid var(--border-color)",
                    cursor: "pointer",
                    transition: "background 0.1s",
                  }}
                >
                  {/* Name */}
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontWeight: 700, fontSize: "0.88rem", color: "var(--text-primary)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                      {project.name}
                    </div>
                    <div style={{ fontSize: "0.7rem", color: "var(--text-muted)", marginTop: 2 }}>
                      {project.creator?.name || "—"} · {new Date(project.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                    </div>
                  </div>

                  {/* Location */}
                  <div style={{ display: "flex", alignItems: "center", gap: 4, fontSize: "0.8rem", color: "var(--text-secondary)" }}>
                    <MapPin size={12} style={{ flexShrink: 0 }} />
                    <span style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{project.targetLocation}</span>
                  </div>

                  {/* Niche */}
                  <div style={{ fontSize: "0.8rem", color: "var(--text-secondary)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                    {project.niche}
                  </div>

                  {/* Leads + progress */}
                  <div>
                    <div style={{ fontSize: "0.8rem", fontWeight: 600, color: "var(--text-primary)", marginBottom: 3 }}>
                      {project._count.leads}/{project.targetLeadCount}
                    </div>
                    <div style={{ background: "#f1f5f9", borderRadius: 3, height: 4, overflow: "hidden" }}>
                      <div style={{
                        height: "100%", borderRadius: 3,
                        width: `${pct}%`,
                        background: color,
                      }} />
                    </div>
                  </div>

                  {/* Phase */}
                  <span style={{
                    display: "inline-flex", alignItems: "center", gap: 3,
                    fontSize: "0.68rem", fontWeight: 600,
                    padding: "3px 7px", borderRadius: 5,
                    background: `${color}18`, color,
                    whiteSpace: "nowrap",
                  }}>
                    <Zap size={9} />
                    {phaseLabels[project.currentPhase] || `Phase ${project.currentPhase}`}
                  </span>

                  {/* Qualified */}
                  <div style={{ fontSize: "0.82rem", fontWeight: 600, color: qualifiedCounts[i] > 0 ? "#10b981" : "var(--text-muted)", textAlign: "center" }}>
                    {qualifiedCounts[i]}
                  </div>

                  {/* Arrow */}
                  <ChevronRight size={14} style={{ color: "var(--text-muted)" }} />

                  {isAdmin && (
                    <button
                      onClick={(e) => deleteProject(e, project)}
                      disabled={deletingId === project.id}
                      title="Delete project (admin)"
                      style={{
                        width: 24, height: 24, borderRadius: 5,
                        border: "none", background: "transparent",
                        color: "#ef4444", cursor: "pointer",
                        display: "flex", alignItems: "center", justifyContent: "center",
                        opacity: deletingId === project.id ? 0.5 : 0.6,
                      }}
                      onMouseEnter={(e) => { e.currentTarget.style.opacity = "1"; e.currentTarget.style.background = "#fef2f2"; }}
                      onMouseLeave={(e) => { e.currentTarget.style.opacity = deletingId === project.id ? "0.5" : "0.6"; e.currentTarget.style.background = "transparent"; }}
                    >
                      {deletingId === project.id ? <Loader2 size={12} className="spin" /> : <Trash2 size={12} />}
                    </button>
                  )}
                </div>
              </Link>
            );
          })}
        </div>
      )}

      <style>{`
        .project-card-hover:hover {
          box-shadow: var(--shadow-hover) !important;
          transform: translateY(-2px);
        }
        .project-list-row:hover {
          background: #f8fafc;
        }
        .spin { animation: spin 1s linear infinite; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}
