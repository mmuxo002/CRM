"use client";

// Live countdown landing page. Shows DD:HH:MM:SS to expiration, then swaps
// to an "expired" state. CTA button links to the GHL scheduling link with
// pre-filled query params (handled server-side).

import { useEffect, useState } from "react";

type Props = {
  firstName: string;
  businessName: string;
  expiresAtIso: string;
  schedulingLink: string;
  initialExpired: boolean;
  initialRedeemed: boolean;
};

function diff(toMs: number) {
  const ms = Math.max(0, toMs - Date.now());
  const total = Math.floor(ms / 1000);
  const days = Math.floor(total / 86400);
  const hours = Math.floor((total % 86400) / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const seconds = total % 60;
  return { ms, days, hours, minutes, seconds };
}

export function OfferCountdown({
  firstName, businessName, expiresAtIso, schedulingLink, initialExpired, initialRedeemed,
}: Props) {
  const expiresAt = new Date(expiresAtIso).getTime();
  const [t, setT] = useState(() => diff(expiresAt));
  const expired = initialExpired || t.ms <= 0;
  const redeemed = initialRedeemed;

  useEffect(() => {
    if (initialExpired) return;
    const id = setInterval(() => setT(diff(expiresAt)), 1000);
    return () => clearInterval(id);
  }, [expiresAt, initialExpired]);

  return (
    <main style={{
      minHeight: "100vh",
      background: "radial-gradient(circle at top, #1a1f2e 0%, #0b0e14 60%)",
      color: "white",
      fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      display: "flex", alignItems: "center", justifyContent: "center",
      padding: "32px 20px",
    }}>
      <div style={{ maxWidth: 640, width: "100%" }}>

        {/* Brand mark */}
        <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: "0.2em", color: "#fb923c", textTransform: "uppercase", marginBottom: 16, textAlign: "center" }}>
          INNOVAT3 Solutions
        </div>

        {/* Card */}
        <div style={{
          background: "rgba(255,255,255,0.04)",
          border: "1px solid rgba(255,255,255,0.08)",
          borderRadius: 20,
          padding: "36px 28px",
          backdropFilter: "blur(8px)",
        }}>

          {redeemed ? (
            <RedeemedView firstName={firstName} businessName={businessName} />
          ) : expired ? (
            <ExpiredView firstName={firstName} businessName={businessName} />
          ) : (
            <ActiveView
              firstName={firstName}
              businessName={businessName}
              countdown={t}
              schedulingLink={schedulingLink}
            />
          )}
        </div>

        <div style={{ marginTop: 28, fontSize: 12, color: "rgba(255,255,255,0.45)", textAlign: "center" }}>
          You&rsquo;re seeing this because we sent {businessName} a 24-hour intro offer.
        </div>
      </div>
    </main>
  );
}

function ActiveView({
  firstName, businessName, countdown, schedulingLink,
}: {
  firstName: string; businessName: string;
  countdown: ReturnType<typeof diff>; schedulingLink: string;
}) {
  return (
    <>
      <div style={{ fontSize: 12, fontWeight: 800, color: "#fb923c", textTransform: "uppercase", letterSpacing: "0.16em", marginBottom: 18 }}>
        24-hour offer
      </div>

      <h1 style={{ fontSize: "clamp(28px, 4.4vw, 40px)", lineHeight: 1.15, fontWeight: 800, margin: "0 0 18px" }}>
        Hey {firstName} — your <span style={{ color: "#fb923c" }}>25% off</span> onboarding is live.
      </h1>

      <p style={{ fontSize: 16, lineHeight: 1.6, color: "rgba(255,255,255,0.78)", margin: "0 0 28px" }}>
        Built for {businessName}. We&rsquo;ll knock 25% off the onboarding cost on whatever we put together for you — landing page, full website, CRM setup, the works. <strong style={{ color: "white" }}>Starting at $800 for a single landing page.</strong>
      </p>

      <Countdown countdown={countdown} />

      <a
        href={schedulingLink}
        target="_blank"
        rel="noopener noreferrer"
        style={{
          display: "block",
          textAlign: "center",
          padding: "16px 28px",
          marginTop: 28,
          background: "linear-gradient(135deg, #ea580c, #db2777)",
          color: "white",
          textDecoration: "none",
          borderRadius: 14,
          fontWeight: 800,
          fontSize: 16,
          boxShadow: "0 18px 40px -14px rgba(234,88,12,0.6)",
        }}
      >
        Book my 25% off call →
      </a>

      <div style={{ marginTop: 18, fontSize: 12, color: "rgba(255,255,255,0.5)", textAlign: "center", lineHeight: 1.55 }}>
        30-min call. No commitment. We&rsquo;ll walk through what we&rsquo;d build and lock in your discount.
      </div>
    </>
  );
}

function ExpiredView({ firstName, businessName }: { firstName: string; businessName: string }) {
  return (
    <>
      <div style={{ fontSize: 12, fontWeight: 800, color: "#94a3b8", textTransform: "uppercase", letterSpacing: "0.16em", marginBottom: 18 }}>
        Offer expired
      </div>

      <h1 style={{ fontSize: "clamp(26px, 4vw, 36px)", lineHeight: 1.2, fontWeight: 800, margin: "0 0 16px" }}>
        Sorry {firstName} — the 25% off window closed.
      </h1>

      <p style={{ fontSize: 16, lineHeight: 1.6, color: "rgba(255,255,255,0.75)", margin: "0 0 24px" }}>
        Still want to chat about {businessName}? We can put something together at our standard pricing — starting at $800 for a single landing page.
      </p>

      <a
        href="mailto:hello@innovat3solutions.com?subject=Still%20interested%20in%20chatting"
        style={{
          display: "block",
          textAlign: "center",
          padding: "14px 24px",
          background: "rgba(255,255,255,0.08)",
          color: "white",
          textDecoration: "none",
          borderRadius: 12,
          fontWeight: 700,
          fontSize: 15,
          border: "1px solid rgba(255,255,255,0.14)",
        }}
      >
        Reach out anyway →
      </a>
    </>
  );
}

function RedeemedView({ firstName, businessName }: { firstName: string; businessName: string }) {
  return (
    <>
      <div style={{ fontSize: 12, fontWeight: 800, color: "#22c55e", textTransform: "uppercase", letterSpacing: "0.16em", marginBottom: 18 }}>
        You&rsquo;re booked
      </div>

      <h1 style={{ fontSize: "clamp(26px, 4vw, 36px)", lineHeight: 1.2, fontWeight: 800, margin: "0 0 16px" }}>
        Locked in, {firstName}.
      </h1>

      <p style={{ fontSize: 16, lineHeight: 1.6, color: "rgba(255,255,255,0.78)", margin: "0 0 8px" }}>
        Your 25% off discount is held for {businessName}. Check your inbox for the calendar invite — we&rsquo;ll see you on the call.
      </p>
    </>
  );
}

function Countdown({ countdown }: { countdown: ReturnType<typeof diff> }) {
  const cells = [
    { label: "Days", value: countdown.days },
    { label: "Hours", value: countdown.hours },
    { label: "Mins", value: countdown.minutes },
    { label: "Secs", value: countdown.seconds },
  ];
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10 }}>
      {cells.map((c) => (
        <div key={c.label} style={{
          background: "rgba(0,0,0,0.35)",
          border: "1px solid rgba(251,146,60,0.25)",
          borderRadius: 12,
          padding: "16px 8px",
          textAlign: "center",
        }}>
          <div style={{ fontSize: "clamp(28px, 5vw, 36px)", fontWeight: 800, color: "white", fontVariantNumeric: "tabular-nums", lineHeight: 1 }}>
            {String(c.value).padStart(2, "0")}
          </div>
          <div style={{ marginTop: 6, fontSize: 10, fontWeight: 800, color: "rgba(251,146,60,0.85)", letterSpacing: "0.12em", textTransform: "uppercase" }}>
            {c.label}
          </div>
        </div>
      ))}
    </div>
  );
}
