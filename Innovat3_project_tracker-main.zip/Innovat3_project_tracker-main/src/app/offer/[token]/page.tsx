// Public offer landing page. No auth.
// Records first-open + serves the OfferCountdown client component which ticks
// the timer, swaps to "expired" state when it hits zero, and links to the
// pre-filled GHL scheduling link.

import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { OfferCountdown } from "./OfferCountdown";

export const dynamic = "force-dynamic";

export default async function OfferPage(
  { params }: { params: Promise<{ token: string }> },
) {
  const { token } = await params;

  const offer = await db.introOffer.findUnique({
    where: { token },
    include: { lead: true },
  });
  if (!offer) notFound();

  // Best-effort first-open record. Non-blocking.
  if (!offer.openedAt) {
    void db.introOffer.update({
      where: { id: offer.id },
      data: { openedAt: new Date() },
    }).catch(() => {});
  }

  const expired = offer.expiresAt.getTime() <= Date.now() || offer.status === "expired";
  const redeemed = offer.status === "redeemed" || !!offer.redeemedAt;

  const firstName = (offer.lead.name || "there").split(" ")[0];

  return (
    <OfferCountdown
      firstName={firstName}
      businessName={offer.lead.name}
      expiresAtIso={offer.expiresAt.toISOString()}
      schedulingLink={offer.schedulingLink}
      initialExpired={expired}
      initialRedeemed={redeemed}
    />
  );
}
