import { requireSession } from "@/lib/rbac";
import { db } from "@/lib/db";
import Link from "next/link";
import { redirect } from "next/navigation";
import { visibleDepartments } from "@/lib/departments";
import { Code2, Users, Target, Megaphone, ArrowRight } from "lucide-react";
import { AdminInvoicesSection } from "@/components/admin/AdminInvoices";
import { AdminMarketingSales } from "@/components/admin/AdminMarketingSales";

export const dynamic = "force-dynamic";

export default async function Home() {
  const { user } = await requireSession();
  if (user.role !== "ADMIN") {
    const depts = visibleDepartments(user.role, user.accessDepartments);
    redirect(depts[0]?.root ?? "/login");
  }

  const [
    appsProjects, appsTasksOpen, crmProjects, crmTasksOpen, leads, hotLeads, campaignsPlaceholder,
    allCampaigns,
    totalLeads, newLeads, contactedLeads, meetingLeads, proposalLeads, readyToCallLeads,
    allDeals,
  ] = await Promise.all([
    db.project.count({ where: { teamId: "APPS" } }),
    db.task.count({ where: { teamId: "APPS", status: { not: "DONE" } } }),
    db.project.count({ where: { teamId: "CRM" } }),
    db.task.count({ where: { teamId: "CRM", status: { not: "DONE" } } }),
    db.lead.count(),
    db.lead.count({ where: { score: { gte: 80 } } }),
    Promise.resolve(2),
    db.campaign.findMany({
      include: { tags: { include: { contacts: true } } },
      orderBy: { updatedAt: "desc" },
    }),
    db.lead.count(),
    db.lead.count({ where: { status: "NEW" } }),
    db.lead.count({ where: { status: "CONTACTED" } }),
    db.lead.count({ where: { status: "MEETING" } }),
    db.lead.count({ where: { status: "PROPOSAL" } }),
    db.lead.count({ where: { status: "READY_TO_CALL" } }),
    db.deal.findMany(),
  ]);

  const closedWonDeals = allDeals.filter((d) => d.stage === "CLOSED_WON");
  const closedWonValue = closedWonDeals.reduce((s, d) => s + d.value, 0);

  const campaignStats = allCampaigns.map((c) => {
    let cLeads = 0, cProspects = 0, cClients = 0;
    for (const t of c.tags) for (const contact of t.contacts) {
      if (contact.status === "CLIENT") cClients++;
      else if (contact.status === "PROSPECT") cProspects++;
      else cLeads++;
    }
    const total = cLeads + cProspects + cClients;
    return {
      id: c.id, name: c.name, color: c.coverColor, service: c.service, niche: c.niche,
      leads: cLeads, prospects: cProspects, clients: cClients, total,
      conversion: total > 0 ? Math.round((cClients / total) * 100) : 0,
    };
  }).sort((a, b) => b.total - a.total);

  const funnel = {
    totalLeads, newLeads, contactedLeads, meetingLeads, proposalLeads, readyToCallLeads,
    closedWonDeals: closedWonDeals.length, closedWonValue, totalDeals: allDeals.length,
  };

  const depts = [
    {
      id: "development",
      label: "Development",
      blurb: "Applications & automations built outside the CRM — larger projects.",
      href: "/dev/apps",
      color: "#4318ff",
      icon: Code2,
      stats: [
        { label: "Active projects", value: appsProjects },
        { label: "Open tasks", value: appsTasksOpen },
      ],
    },
    {
      id: "crm",
      label: "CRM",
      blurb: "Client CRM setups, automations, and website/funnel integrations.",
      href: "/dev/crm",
      color: "#7c3aed",
      icon: Users,
      stats: [
        { label: "Client projects", value: crmProjects },
        { label: "Open tasks", value: crmTasksOpen },
      ],
    },
    {
      id: "sales",
      label: "Sales",
      blurb: "Pipeline, hot leads, and quota tracking.",
      href: "/prospecting",
      color: "#f59e0b",
      icon: Target,
      stats: [
        { label: "Total leads", value: leads },
        { label: "Hot (80+)", value: hotLeads },
      ],
    },
    {
      id: "marketing",
      label: "Marketing",
      blurb: "Campaigns, audiences, and top-of-funnel performance.",
      href: "/marketing",
      color: "#ec4899",
      icon: Megaphone,
      stats: [
        { label: "Active campaigns", value: campaignsPlaceholder },
        { label: "MQLs (30d)", value: 540 },
      ],
    },
  ];

  return (
    <div className="animate-slide-up">
      <div className="row-between" style={{ marginBottom: "1.5rem" }}>
        <div>
          <h1 className="page-title">Home</h1>
          <p className="page-subtitle">Welcome back, {user.name}. Summary across all four departments.</p>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: "1rem", marginBottom: "1.5rem" }}>
        {depts.map((d) => (
          <Link key={d.id} href={d.href} className="card" style={{ textDecoration: "none", color: "inherit", display: "flex", flexDirection: "column", gap: "0.9rem", borderTop: `4px solid ${d.color}` }}>
            <div className="row-between">
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <div style={{ width: 36, height: 36, borderRadius: 10, background: `${d.color}18`, color: d.color, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <d.icon size={18} />
                </div>
                <div>
                  <div style={{ fontWeight: 800, fontSize: "1rem" }}>{d.label}</div>
                  <div style={{ fontSize: "0.7rem", color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.05em", fontWeight: 700 }}>Department</div>
                </div>
              </div>
              <ArrowRight size={16} color={d.color} />
            </div>
            <div style={{ fontSize: "0.8rem", color: "var(--text-secondary)", lineHeight: 1.45 }}>{d.blurb}</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.6rem", marginTop: "auto" }}>
              {d.stats.map((s) => (
                <div key={s.label} style={{ background: "var(--bg-base)", padding: "0.6rem 0.75rem", borderRadius: 8 }}>
                  <div style={{ fontSize: "0.65rem", color: "var(--text-muted)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.04em" }}>{s.label}</div>
                  <div style={{ fontSize: "1.3rem", fontWeight: 800, color: d.color }}>{s.value}</div>
                </div>
              ))}
            </div>
          </Link>
        ))}
      </div>

      <div className="card" style={{ padding: "1.25rem", marginBottom: "1.5rem" }}>
        <AdminMarketingSales campaigns={campaignStats} funnel={funnel} />
      </div>

      <div className="card" style={{ padding: "1.25rem" }}>
        <AdminInvoicesSection />
      </div>
    </div>
  );
}
