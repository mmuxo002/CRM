"use client";

import { signIn } from "next-auth/react";
import { Suspense, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Eye, EyeOff, Loader2, LogIn, ShieldCheck } from "lucide-react";

export default function LoginPage() {
  return (
    <Suspense fallback={null}>
      <LoginContent />
    </Suspense>
  );
}

function LoginContent() {
  const router = useRouter();
  const params = useSearchParams();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const res = await signIn("credentials", { email, password, redirect: false });
    setLoading(false);
    if (res?.error) {
      setError("The email or password you entered is incorrect.");
      return;
    }
    router.push(params.get("callbackUrl") || "/");
    router.refresh();
  }

  return (
    <div className="__login-page" style={styles.page}>
      <aside className="__login-brand-panel" style={styles.brandPanel}>
        <div style={styles.brandGlowA} />
        <div style={styles.brandGlowB} />
        <div style={styles.brandInner}>
          <div style={styles.brandHeader}>
            <div style={styles.logoMark}>I3</div>
            <div>
              <div style={styles.wordmark}>INNOVAT3</div>
              <div style={styles.wordmarkSub}>Pulse Tracker</div>
            </div>
          </div>

          <div style={{ marginTop: "auto" }}>
            <h2 style={styles.brandTitle}>
              One workspace for Development, CRM, Sales &amp; Marketing.
            </h2>
            <p style={styles.brandBody}>
              Unified pipelines, client delivery, and campaign insight — secured behind your team's single sign-in.
            </p>

            <div style={styles.featureList}>
              <Feature label="Role-based department access" />
              <Feature label="Admin-controlled team onboarding" />
              <Feature label="End-to-end encrypted credentials" />
            </div>
          </div>

          <div style={styles.brandFooter}>
            © {new Date().getFullYear()} INNOVAT3 Solutions
          </div>
        </div>
      </aside>

      <section className="__login-form-panel" style={styles.formPanel}>
        <div style={styles.formShell}>
          <div className="__login-mobile-logo" style={styles.mobileLogo}>
            <div style={{ ...styles.logoMark, width: 40, height: 40, fontSize: 14 }}>I3</div>
            <div>
              <div style={{ ...styles.wordmark, color: "var(--accent-primary)", fontSize: "1.1rem" }}>INNOVAT3</div>
              <div style={{ fontSize: "0.7rem", color: "var(--text-secondary)", fontWeight: 600, letterSpacing: "0.12em" }}>PULSE TRACKER</div>
            </div>
          </div>

          <div style={{ marginBottom: "2rem" }}>
            <div style={styles.eyebrow}>
              <ShieldCheck size={13} />
              Secure sign-in
            </div>
            <h1 style={styles.title}>Welcome back</h1>
            <p style={styles.subtitle}>Sign in to access your workspace.</p>
          </div>

          <form onSubmit={onSubmit} style={{ display: "flex", flexDirection: "column", gap: "1.1rem" }}>
            <Field label="Work email">
              <input
                type="email"
                required
                autoComplete="email"
                autoFocus
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@innovat3.com"
                style={styles.input}
                onFocus={(e) => (e.currentTarget.style.borderColor = "var(--accent-primary)")}
                onBlur={(e) => (e.currentTarget.style.borderColor = "var(--border-hover)")}
              />
            </Field>

            <Field label="Password">
              <div style={{ position: "relative" }}>
                <input
                  type={showPw ? "text" : "password"}
                  required
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  style={{ ...styles.input, paddingRight: 44 }}
                  onFocus={(e) => (e.currentTarget.style.borderColor = "var(--accent-primary)")}
                  onBlur={(e) => (e.currentTarget.style.borderColor = "var(--border-hover)")}
                />
                <button
                  type="button"
                  onClick={() => setShowPw((v) => !v)}
                  aria-label={showPw ? "Hide password" : "Show password"}
                  style={styles.eyeBtn}
                >
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </Field>

            {error && (
              <div style={styles.errorBox} role="alert">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              style={{ ...styles.submitBtn, opacity: loading ? 0.7 : 1, cursor: loading ? "not-allowed" : "pointer" }}
            >
              {loading ? (
                <>
                  <Loader2 size={16} style={{ animation: "spin 0.8s linear infinite" }} />
                  Signing in…
                </>
              ) : (
                <>
                  <LogIn size={16} />
                  Sign in
                </>
              )}
            </button>
          </form>

          <div style={styles.helperLine}>
            Trouble signing in? <span style={{ fontWeight: 700, color: "var(--text-primary)" }}>Contact your administrator.</span>
          </div>
        </div>
      </section>

      <style jsx global>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
        @media (max-width: 900px) {
          .__login-page { grid-template-columns: 1fr !important; }
          .__login-brand-panel { display: none !important; }
          .__login-form-panel { padding: 1.5rem !important; }
          .__login-mobile-logo { display: flex !important; }
        }
      `}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      <span style={styles.fieldLabel}>{label}</span>
      {children}
    </label>
  );
}

function Feature({ label }: { label: string }) {
  return (
    <div style={styles.featureRow}>
      <span style={styles.featureDot} />
      {label}
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  page: {
    minHeight: "100vh",
    width: "100%",
    display: "grid",
    gridTemplateColumns: "minmax(0, 1.1fr) minmax(0, 1fr)",
    background: "var(--bg-base)",
  },
  brandPanel: {
    position: "relative",
    overflow: "hidden",
    background:
      "linear-gradient(145deg, #2a0fa8 0%, #4318ff 45%, #7c3aed 80%, #ec4899 100%)",
    color: "white",
    padding: "3rem",
    display: "flex",
    flexDirection: "column",
  },
  brandGlowA: {
    position: "absolute",
    top: -120,
    right: -120,
    width: 420,
    height: 420,
    borderRadius: "50%",
    background: "radial-gradient(circle, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0) 70%)",
    pointerEvents: "none",
  },
  brandGlowB: {
    position: "absolute",
    bottom: -180,
    left: -140,
    width: 480,
    height: 480,
    borderRadius: "50%",
    background: "radial-gradient(circle, rgba(236,72,153,0.35) 0%, rgba(236,72,153,0) 70%)",
    pointerEvents: "none",
  },
  brandInner: {
    position: "relative",
    zIndex: 1,
    display: "flex",
    flexDirection: "column",
    flex: 1,
    maxWidth: 520,
  },
  brandHeader: {
    display: "flex",
    alignItems: "center",
    gap: "0.9rem",
  },
  logoMark: {
    width: 48,
    height: 48,
    borderRadius: 12,
    background: "rgba(255,255,255,0.16)",
    backdropFilter: "blur(8px)",
    border: "1px solid rgba(255,255,255,0.25)",
    color: "white",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontWeight: 900,
    fontSize: 16,
    letterSpacing: "0.02em",
  },
  wordmark: {
    fontSize: "1.25rem",
    fontWeight: 900,
    letterSpacing: "0.04em",
    lineHeight: 1,
  },
  wordmarkSub: {
    fontSize: "0.72rem",
    opacity: 0.8,
    letterSpacing: "0.12em",
    marginTop: 4,
    fontWeight: 600,
  },
  brandTitle: {
    fontSize: "2.15rem",
    fontWeight: 800,
    lineHeight: 1.15,
    marginBottom: "1rem",
    letterSpacing: "-0.02em",
  },
  brandBody: {
    fontSize: "0.95rem",
    lineHeight: 1.6,
    opacity: 0.86,
    marginBottom: "2rem",
    maxWidth: 460,
  },
  featureList: {
    display: "flex",
    flexDirection: "column",
    gap: "0.75rem",
  },
  featureRow: {
    display: "flex",
    alignItems: "center",
    gap: 10,
    fontSize: "0.88rem",
    fontWeight: 500,
    opacity: 0.95,
  },
  featureDot: {
    width: 6,
    height: 6,
    borderRadius: "50%",
    background: "white",
    boxShadow: "0 0 0 4px rgba(255,255,255,0.15)",
    flexShrink: 0,
  },
  brandFooter: {
    marginTop: "2.5rem",
    fontSize: "0.72rem",
    opacity: 0.65,
    letterSpacing: "0.04em",
  },
  formPanel: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: "3rem 2rem",
    background: "var(--bg-surface)",
  },
  formShell: {
    width: "100%",
    maxWidth: 420,
    display: "flex",
    flexDirection: "column",
  },
  mobileLogo: {
    display: "none",
    alignItems: "center",
    gap: "0.7rem",
    marginBottom: "2rem",
  },
  eyebrow: {
    display: "inline-flex",
    alignItems: "center",
    gap: 6,
    fontSize: "0.7rem",
    fontWeight: 700,
    textTransform: "uppercase",
    letterSpacing: "0.08em",
    color: "var(--accent-primary)",
    background: "var(--accent-glow)",
    padding: "0.35rem 0.7rem",
    borderRadius: 999,
    marginBottom: "1rem",
  },
  title: {
    fontSize: "1.85rem",
    fontWeight: 800,
    color: "var(--text-primary)",
    letterSpacing: "-0.01em",
    marginBottom: "0.5rem",
  },
  subtitle: {
    fontSize: "0.92rem",
    color: "var(--text-secondary)",
    lineHeight: 1.5,
  },
  fieldLabel: {
    fontSize: "0.78rem",
    fontWeight: 700,
    color: "var(--text-primary)",
    letterSpacing: "0.01em",
  },
  input: {
    width: "100%",
    padding: "0.85rem 1rem",
    borderRadius: 12,
    border: "1.5px solid var(--border-hover)",
    fontSize: "0.92rem",
    color: "var(--text-primary)",
    background: "var(--bg-surface)",
    outline: "none",
    transition: "border-color 0.15s ease, box-shadow 0.15s ease",
    fontFamily: "var(--font-sans)",
  },
  eyeBtn: {
    position: "absolute",
    top: "50%",
    right: 12,
    transform: "translateY(-50%)",
    background: "transparent",
    border: "none",
    color: "var(--text-secondary)",
    cursor: "pointer",
    padding: 4,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 6,
  },
  errorBox: {
    background: "#fef2f2",
    border: "1px solid #fecaca",
    color: "#b91c1c",
    fontSize: "0.82rem",
    padding: "0.7rem 0.9rem",
    borderRadius: 10,
    fontWeight: 600,
  },
  submitBtn: {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    padding: "0.9rem 1rem",
    borderRadius: 12,
    background: "var(--accent-primary)",
    color: "white",
    border: "none",
    fontSize: "0.92rem",
    fontWeight: 700,
    marginTop: "0.35rem",
    boxShadow: "0 10px 25px -10px rgba(67,24,255,0.55)",
    transition: "transform 0.12s ease, background 0.12s ease",
    fontFamily: "var(--font-sans)",
  },
  helperLine: {
    marginTop: "1.75rem",
    fontSize: "0.82rem",
    color: "var(--text-secondary)",
    textAlign: "center",
    paddingTop: "1.25rem",
    borderTop: "1px solid var(--border-color)",
  },
};
