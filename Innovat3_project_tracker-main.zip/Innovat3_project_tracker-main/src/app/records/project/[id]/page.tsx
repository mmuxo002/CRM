import { requireSession } from "@/lib/rbac";
import { db } from "@/lib/db";
import { notFound } from "next/navigation";
import Link from "next/link";
import { Building2, CheckCircle2, DollarSign, Star, Wrench, Calendar as CalIcon, FileText } from "lucide-react";
import {
  EditableSummaryTile,
  ServiceEditor,
  OnboardedEditor,
  MrrEditor,
  TagsEditor,
  ClientEditor,
  PrimaryContactEditor,
  TasksWithModal,
  InternalKanban,
  FilesFoldersEditor,
} from "@/components/records/ProjectRecordEditors";
import { ProjectNotesChat } from "@/components/records/ProjectNotes";
import { ProjectActivityLog } from "@/components/records/ProjectActivityLog";

export const dynamic = "force-dynamic";

type Tab = "overview" | "notes" | "activity";
const TABS: { label: string; value: Tab }[] = [
  { label: "Overview", value: "overview" },
  { label: "Notes",    value: "notes" },
  { label: "Activity", value: "activity" },
];

const SERVICE_COLOR: Record<string, string> = {
  "GHL Automation": "#7c3aed",
  "Voice AI Agent": "#ec4899",
  "CRM Setup": "#a855f7",
  "Website Build": "#4318ff",
  "Mobile App": "#06b6d4",
};

export default async function ProjectOverviewPage({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ task?: string; tab?: string }> }) {
  const { user } = await requireSession();
  const { id } = await params;
  const sp = await searchParams;
  const autoOpenTask = sp.task;
  const activeTab: Tab = (["overview", "notes", "activity"].includes(sp.tab ?? "") ? sp.tab as Tab : "overview");

  const project = await db.project.findUnique({
    where: { id },
    include: {
      owner: true,
      company: { include: { contacts: true } },
      tasks: { include: { assignee: true }, orderBy: [{ status: "asc" }, { dueDate: "asc" }] },
      tags: true,
      folders: true,
      files: true,
      activities: { include: { actor: true }, orderBy: { createdAt: "desc" }, take: 6 },
    },
  });
  if (!project) notFound();

  if (user.role !== "ADMIN" && project.teamId !== "GLOBAL") {
    const userTeam = user.role === "APPS_DEV" ? "APPS" : user.role === "CRM_DEV" ? "CRM" : "SALES";
    if (project.teamId !== userTeam) {
      return <div className="card" style={{ padding: "2rem", margin: "2rem" }}><h2>Access denied</h2><p>You do not have permission to view this record.</p></div>;
    }
  }

  const users = await db.user.findMany({ where: { isActive: true }, select: { id: true, name: true, image: true }, orderBy: { name: "asc" } });

  const openTasks = project.tasks.filter((t) => t.status !== "DONE");
  const serviceColor = project.serviceType ? SERVICE_COLOR[project.serviceType] || "#4318ff" : "#4318ff";
  const accent = project.teamId === "CRM" ? "#7c3aed" : project.teamId === "APPS" ? "#4318ff" : "#f59e0b";

  const tasksForClient = project.tasks.map((t) => ({
    id: t.id,
    title: t.title,
    description: t.description,
    status: t.status,
    priority: t.priority,
    dueDate: t.dueDate?.toISOString() ?? null,
    platformTag: t.platformTag,
    assignee: t.assignee ? { id: t.assignee.id, name: t.assignee.name, image: t.assignee.image } : null,
  }));

  const baseUrl = `/records/project/${project.id}`;

  return (
    <div className="animate-slide-up">
      <div className="row-between" style={{ marginBottom: "1rem" }}>
        <div className="flex-gap" style={{ fontSize: "0.85rem", color: "var(--text-secondary)" }}>
          <Link href={project.teamId === "CRM" ? "/dev/crm" : project.teamId === "APPS" ? "/dev/apps" : "/"}>{project.teamId} Projects</Link>
          <span>/</span>
          <span style={{ color: "var(--text-primary)", fontWeight: 700 }}>{project.name}</span>
        </div>
        <div className="flex-gap">
          <span className={`badge ${project.onboarded ? "badge-green" : "badge-orange"}`}>{project.onboarded ? <><CheckCircle2 size={12} style={{ display: "inline", marginRight: 2 }} /> Onboarded</> : "Not Onboarded"}</span>
          {project.mrr > 0 && <span className="badge badge-green"><DollarSign size={12} style={{ display: "inline" }} /> ${project.mrr.toLocaleString()}/mo</span>}
          <span className="badge badge-blue">{project.stage.replace("_", " ")}</span>
          <button className="btn btn-ghost"><Star size={14} /> Favourite</button>
        </div>
      </div>

      <div className="card" style={{ padding: "1.25rem 1.5rem", marginBottom: "1rem", display: "grid", gridTemplateColumns: "1fr auto", gap: "1.5rem", alignItems: "center" }}>
        <div style={{ display: "flex", gap: "1rem", alignItems: "center" }}>
          <div style={{ width: 56, height: 56, borderRadius: 14, background: `linear-gradient(135deg, ${accent}, ${serviceColor})`, color: "white", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, fontSize: "1.1rem" }}>
            {project.name.slice(0, 2).toUpperCase()}
          </div>
          <div>
            <div style={{ fontSize: "1.25rem", fontWeight: 800 }}>{project.name}</div>
            <div style={{ fontSize: "0.85rem", color: "var(--text-secondary)", display: "flex", alignItems: "center", gap: 6, marginTop: 2 }}>
              {project.company?.name && <><Building2 size={12} /> {project.company.name}</>}
              {project.serviceType && <><span style={{ margin: "0 4px" }}>·</span><Wrench size={12} /> {project.serviceType}</>}
              {project.dueDate && <><span style={{ margin: "0 4px" }}>·</span><CalIcon size={12} /> Due {new Date(project.dueDate).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</>}
            </div>
            {project.description && <div style={{ fontSize: "0.85rem", color: "var(--text-primary)", marginTop: 8, lineHeight: 1.5, maxWidth: 640 }}>{project.description}</div>}
          </div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontSize: "0.7rem", textTransform: "uppercase", color: "var(--text-muted)", letterSpacing: "0.05em", fontWeight: 700 }}>Progress</div>
          <div style={{ fontSize: "2rem", fontWeight: 900, color: accent }}>{project.progress}%</div>
          <div style={{ width: 140, height: 6, background: "var(--bg-base)", borderRadius: 999, overflow: "hidden" }}>
            <div style={{ height: "100%", width: `${project.progress}%`, background: `linear-gradient(90deg, ${accent}, ${serviceColor})` }} />
          </div>
        </div>
      </div>

      <div className="record-tabs" style={{ marginBottom: "1rem" }}>
        {TABS.map((t) => (
          <Link
            key={t.value}
            href={t.value === "overview" ? baseUrl : `${baseUrl}?tab=${t.value}`}
            className={`record-tab ${activeTab === t.value ? "active" : ""}`}
            style={{ color: "inherit", textDecoration: "none" }}
          >
            {t.label}
          </Link>
        ))}
      </div>

      {activeTab === "overview" && (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: "1.5rem" }}>
          <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "0.75rem" }}>
              <EditableSummaryTile label="Service" icon={<Wrench size={16} />} color={serviceColor}>
                <ServiceEditor projectId={project.id} initial={project.serviceType} />
              </EditableSummaryTile>
              <EditableSummaryTile label="Onboarded" icon={<CheckCircle2 size={16} />} color={project.onboardedAt ? "#10b981" : "#f59e0b"}>
                <OnboardedEditor projectId={project.id} initial={project.onboardedAt?.toISOString() ?? null} />
              </EditableSummaryTile>
              <EditableSummaryTile label="Monthly Revenue" icon={<DollarSign size={16} />} color="#10b981">
                <MrrEditor projectId={project.id} initial={project.mrr} />
              </EditableSummaryTile>
              <EditableSummaryTile label="Open Tasks" icon={<FileText size={16} />} color={accent}>
                <span>{openTasks.length}</span>
              </EditableSummaryTile>
            </div>

            <div className="card">
              <div className="row-between" style={{ marginBottom: "0.75rem" }}>
                <h2 style={{ fontSize: "1rem", fontWeight: 800 }}>Tasks ({project.tasks.length})</h2>
                <span style={{ fontSize: "0.75rem", color: "var(--text-muted)" }}>Click a task to edit details.</span>
              </div>
              <TasksWithModal projectId={project.id} initial={tasksForClient} users={users} autoOpenId={autoOpenTask} />
            </div>

            <div className="card">
              <h2 style={{ fontSize: "1rem", fontWeight: 800, marginBottom: "0.75rem" }}>Recent Activity</h2>
              {project.activities.length === 0 && <div style={{ color: "var(--text-muted)", fontSize: "0.85rem" }}>No activity yet.</div>}
              {project.activities.map((a) => (
                <div key={a.id} className="activity-item">
                  {a.actor?.image ? <img src={a.actor.image} alt="" /> : <div style={{ width: 36, height: 36, borderRadius: "50%", background: "#e2e8f0" }} />}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontWeight: 700, fontSize: "0.85rem" }}>{a.actor?.name || "System"}</div>
                    <div style={{ fontSize: "0.8rem", color: "var(--text-secondary)" }}>{a.title}</div>
                    {a.body && <div style={{ fontSize: "0.75rem", color: "var(--text-muted)", marginTop: 4 }}>{a.body}</div>}
                  </div>
                </div>
              ))}
            </div>

            <div className="card">
              <div className="row-between" style={{ marginBottom: "0.75rem" }}>
                <h2 style={{ fontSize: "1rem", fontWeight: 800 }}>Project Board</h2>
                <span style={{ fontSize: "0.75rem", color: "var(--text-muted)" }}>Drag tasks to update status. Click a card to edit.</span>
              </div>
              <InternalKanban projectId={project.id} initial={tasksForClient} users={users} autoOpenId={autoOpenTask} />
            </div>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
            <div className="card">
              <h4 style={{ fontSize: "0.7rem", textTransform: "uppercase", color: "var(--text-secondary)", letterSpacing: "0.05em", fontWeight: 700, marginBottom: "0.75rem" }}>Project Owner</h4>
              {project.owner ? (
                <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
                  {project.owner.image ? <img src={project.owner.image} style={{ width: 40, height: 40, borderRadius: "50%" }} alt="" /> : <div style={{ width: 40, height: 40, borderRadius: "50%", background: "#e2e8f0" }} />}
                  <div>
                    <div style={{ fontWeight: 700, fontSize: "0.88rem" }}>{project.owner.name}</div>
                    <div style={{ fontSize: "0.72rem", color: "var(--text-muted)" }}>{project.owner.title || project.owner.role}</div>
                  </div>
                </div>
              ) : <div style={{ fontSize: "0.85rem", color: "var(--text-muted)" }}>Unassigned</div>}
            </div>

            {project.company && (
              <div className="card">
                <h4 style={{ fontSize: "0.7rem", textTransform: "uppercase", color: "var(--text-secondary)", letterSpacing: "0.05em", fontWeight: 700, marginBottom: "0.75rem" }}>Client</h4>
                <ClientEditor company={{ id: project.company.id, name: project.company.name, industry: project.company.industry, website: project.company.website, phone: project.company.phone, headquarters: project.company.headquarters }} />
              </div>
            )}

            <div className="card">
              <h4 style={{ fontSize: "0.7rem", textTransform: "uppercase", color: "var(--text-secondary)", letterSpacing: "0.05em", fontWeight: 700, marginBottom: "0.75rem" }}>Primary Contact</h4>
              <PrimaryContactEditor
                companyId={project.companyId}
                contacts={(project.company?.contacts || []).map((c) => ({ id: c.id, name: c.name, email: c.email, title: c.title, phone: c.phone, avatarUrl: c.avatarUrl, isPrimary: c.isPrimary }))}
              />
            </div>

            <div className="card">
              <h4 style={{ fontSize: "0.7rem", textTransform: "uppercase", color: "var(--text-secondary)", letterSpacing: "0.05em", fontWeight: 700, marginBottom: "0.75rem" }}>Tags</h4>
              <TagsEditor projectId={project.id} initial={project.tags.map((t) => ({ id: t.id, label: t.label, color: t.color }))} />
            </div>

            <div className="card">
              <h4 style={{ fontSize: "0.7rem", textTransform: "uppercase", color: "var(--text-secondary)", letterSpacing: "0.05em", fontWeight: 700, marginBottom: "0.75rem" }}>Files & Folders</h4>
              <FilesFoldersEditor
                projectId={project.id}
                initialFolders={project.folders.map((f) => ({ id: f.id, name: f.name, color: f.color }))}
                initialFiles={project.files.map((f) => ({ id: f.id, name: f.name, format: f.format, url: f.url, isLink: f.isLink, folderId: f.folderId }))}
              />
            </div>
          </div>
        </div>
      )}

      {activeTab === "notes" && (
        <div className="card" style={{ padding: "1rem 1.25rem" }}>
          <h2 style={{ fontSize: "1rem", fontWeight: 800, marginBottom: "0.5rem" }}>Notes & Communication</h2>
          <p style={{ fontSize: "0.75rem", color: "var(--text-muted)", marginBottom: "0.75rem" }}>Project notes and task comments in one thread. Task notes are labeled with their source task.</p>
          <ProjectNotesChat projectId={project.id} />
        </div>
      )}

      {activeTab === "activity" && (
        <div className="card" style={{ padding: "1rem 1.25rem" }}>
          <h2 style={{ fontSize: "1rem", fontWeight: 800, marginBottom: "0.5rem" }}>Activity Log</h2>
          <p style={{ fontSize: "0.75rem", color: "var(--text-muted)", marginBottom: "0.75rem" }}>Full history of changes, assignments, and updates for this project.</p>
          <ProjectActivityLog projectId={project.id} />
        </div>
      )}
    </div>
  );
}
